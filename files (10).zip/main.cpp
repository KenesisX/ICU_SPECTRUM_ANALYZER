// ICU ESP32 node: joins WiFi, keeps a WebSocket to the platform,
// reports status, and accepts a small set of commands.
#include <Arduino.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include "secrets.h"

static WebSocketsClient ws;
static const int LED_PIN = 2;          // onboard LED on most ESP32 dev boards
static unsigned long lastReport = 0;

static void sendJson(JsonDocument& doc) {
    String out;
    serializeJson(doc, out);
    ws.sendTXT(out);
}

static void handleCommand(const char* payload, size_t len) {
    JsonDocument doc;
    if (deserializeJson(doc, payload, len)) return;   // ignore malformed input

    const char* cmd = doc["command"] | "";
    bool known = true;
    if (strcmp(cmd, "led_on") == 0)       digitalWrite(LED_PIN, HIGH);
    else if (strcmp(cmd, "led_off") == 0) digitalWrite(LED_PIN, LOW);
    else if (strcmp(cmd, "reboot") == 0)  { /* ack first, restart below */ }
    else known = false;

    if (known) {
        JsonDocument ack;
        ack["type"] = "ack";
        ack["command"] = cmd;
        sendJson(ack);
    }
    if (strcmp(cmd, "reboot") == 0) {
        delay(200);            // let the ack leave the radio before restarting
        ESP.restart();
    }
}

static void onEvent(WStype_t type, uint8_t* payload, size_t length) {
    switch (type) {
        case WStype_CONNECTED: {
            JsonDocument hello;
            hello["type"] = "device_info";
            hello["mac"] = WiFi.macAddress();
            hello["version"] = "2.0.0";
            sendJson(hello);
            break;
        }
        case WStype_TEXT:
            handleCommand((const char*)payload, length);
            break;
        default:
            break;
    }
}

static void connectWifi() {
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.print("WiFi connecting");
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print('.');
    }
    Serial.printf("\nWiFi up, IP %s\n", WiFi.localIP().toString().c_str());
}

void setup() {
    Serial.begin(115200);
    pinMode(LED_PIN, OUTPUT);
    connectWifi();
    ws.begin(SERVER_HOST, SERVER_PORT, SERVER_PATH);
    ws.onEvent(onEvent);
    ws.setReconnectInterval(5000);
}

void loop() {
    ws.loop();

    // Status report every 10 s while connected.
    if (ws.isConnected() && millis() - lastReport > 10000) {
        lastReport = millis();
        JsonDocument status;
        status["type"] = "status";
        status["rssi"] = WiFi.RSSI();
        status["uptime_s"] = millis() / 1000;
        status["temp_c"] = temperatureRead();   // internal die temperature, approximate
        sendJson(status);
    }
}
