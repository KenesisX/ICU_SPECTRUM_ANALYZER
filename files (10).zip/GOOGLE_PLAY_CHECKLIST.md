# Google Play submission checklist

Everything here needs your account, your keys, or a real device/build — none of it can be done from
a sandbox. Order matters where noted.

## One-time setup
- [ ] Google Play Console developer account ($25 one-time) — https://play.google.com/console
- [ ] Generate your upload keystore (see `android/README.md`) and store it somewhere safe outside
      the repo. Losing it means you can't update the app under the same listing again.
- [ ] Add the signing secrets to your GitHub repo (`ICU_KEYSTORE_B64`, `ICU_KEYSTORE_PASS`,
      `ICU_KEY_ALIAS`, `ICU_KEY_PASS`) — see `.github/workflows/build.yml`.

## Before the first submission
- [ ] Check Play's current target API level requirement in Play Console (changes roughly yearly) —
      `android/app/build.gradle.kts` is currently `targetSdk = 34`; bump it if Play Console flags it
      as outdated, and bump `compileSdk` to match.
- [ ] Decide on `wss://` (TLS) vs `ws://` for your deployed server, and update
      `android:usesCleartextTraffic` in `AndroidManifest.xml` to match — see `STORE_LISTING.md` for why.
- [ ] Replace the placeholder launcher icon with real branding if you want one, or keep the vector
      placeholder — it's valid, just plain.
- [ ] Host `PRIVACY_POLICY.md` somewhere public (GitHub Pages works) and fill in the date/contact.
      Play requires a live privacy policy URL for every app.
- [ ] Create the graphic assets listed at the bottom of `STORE_LISTING.md`.

## Build and run it for real at least once
- [ ] Run the GitHub Actions workflow (or build locally) to produce a signed `.aab`.
- [ ] Install the `.apk` from the same run on a real phone and actually use all three tabs
      (Sensors, Control, Signal) against a running copy of the API. This has not been done —
      only the server side has been tested end to end.

## In Play Console
- [ ] Create the app, pick category, set up the store listing using `STORE_LISTING.md` as a draft
- [ ] Upload privacy policy URL
- [ ] Fill in content rating questionnaire
- [ ] Fill in Data safety form (see `STORE_LISTING.md`)
- [ ] Upload the signed `.aab`
- [ ] Upload screenshots, icon, feature graphic
- [ ] Submit to internal testing track first, not straight to production — this app has not been
      through Play's review before and has not been tested on physical devices
- [ ] After internal testing confirms it works, promote to production

## After submission
- [ ] Review typically takes 24–72 hours for a first submission (longer than updates)
- [ ] If rejected, read the specific policy cited — most likely candidates given this app are
      Data Safety accuracy or the Deceptive Behavior policy if the listing text drifts from the
      neutral draft in `STORE_LISTING.md`
