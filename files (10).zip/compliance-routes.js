// ================================================================
// COMPLIANCE RULES ENGINE & AUDIT LOGGING
// Module 3: Compliance Rules Engine
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// COMPLIANCE RULES CRUD
// ================================================================

router.post('/rules', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const {
      name,
      framework, // HIPAA, PCI-DSS, NIST, ISO27001, SOC2, GDPR
      description,
      requirements,
      severity,
      enforcement,
    } = req.body;

    const result = await db.query(
      `INSERT INTO compliance_rules 
       (name, framework, description, requirements, severity, enforcement, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        name,
        framework,
        description,
        JSON.stringify(requirements),
        severity,
        enforcement,
        req.user.id,
      ],
    );

    logger.info('Compliance rule created', { ruleId: result.rows[0].id, framework });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create compliance rule error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/rules', authMiddleware, async (req, res) => {
  try {
    const { framework, limit = 100 } = req.query;

    let query = 'SELECT * FROM compliance_rules WHERE 1=1';
    const params = [];

    if (framework) {
      query += ' AND framework = $1';
      params.push(framework);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get compliance rules error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.put('/rules/:rule_id', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { name, description, requirements, severity, enforcement } = req.body;

    const result = await db.query(
      `UPDATE compliance_rules 
       SET name = COALESCE($1, name),
           description = COALESCE($2, description),
           requirements = COALESCE($3, requirements),
           severity = COALESCE($4, severity),
           enforcement = COALESCE($5, enforcement),
           updated_at = NOW()
       WHERE id = $6
       RETURNING *`,
      [
        name,
        description,
        requirements ? JSON.stringify(requirements) : null,
        severity,
        enforcement,
        req.params.rule_id,
      ],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Rule not found' });
    }

    logger.info('Compliance rule updated', { ruleId: req.params.rule_id });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Update compliance rule error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// COMPLIANCE AUDIT LOGGING
// ================================================================

router.get('/audit-log', authMiddleware, async (req, res) => {
  try {
    const {
      user_id,
      action,
      resource_type,
      limit = 1000,
      offset = 0,
    } = req.query;

    let query = 'SELECT * FROM audit_log WHERE 1=1';
    const params = [];

    if (user_id) {
      query += ' AND user_id = $1';
      params.push(user_id);
    }

    if (action) {
      query += ` AND action = $${params.length + 1}`;
      params.push(action);
    }

    if (resource_type) {
      query += ` AND resource_type = $${params.length + 1}`;
      params.push(resource_type);
    }

    query += ` ORDER BY timestamp DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get audit log error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// COMPLIANCE CHECKS
// ================================================================

router.post('/checks', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const {
      engagement_id,
      rule_id,
      check_status,
      notes,
      remediation_steps,
    } = req.body;

    const result = await db.query(
      `INSERT INTO compliance_checks 
       (engagement_id, rule_id, check_status, notes, remediation_steps, checked_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        engagement_id,
        rule_id,
        check_status,
        notes,
        JSON.stringify(remediation_steps),
        req.user.id,
      ],
    );

    logger.info('Compliance check created', { checkId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create compliance check error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/checks/engagement/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT cc.*, cr.name as rule_name, cr.framework
       FROM compliance_checks cc
       LEFT JOIN compliance_rules cr ON cc.rule_id = cr.id
       WHERE cc.engagement_id = $1
       ORDER BY cc.created_at DESC`,
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get compliance checks error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// COMPLIANCE REPORT GENERATION
// ================================================================

router.get('/report/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const { framework } = req.query;

    // Get all checks for engagement
    const checksResult = await db.query(
      `SELECT cc.*, cr.name, cr.framework, cr.severity
       FROM compliance_checks cc
       LEFT JOIN compliance_rules cr ON cc.rule_id = cr.id
       WHERE cc.engagement_id = $1
       ${framework ? 'AND cr.framework = $2' : ''}
       ORDER BY cr.framework, cr.severity DESC`,
      framework ? [req.params.engagement_id, framework] : [req.params.engagement_id],
    );

    // Get engagement details
    const engResult = await db.query(
      'SELECT name, client FROM engagements WHERE id = $1',
      [req.params.engagement_id],
    );

    if (engResult.rows.length === 0) {
      return res.status(404).json({ error: 'Engagement not found' });
    }

    // Calculate compliance score
    const checks = checksResult.rows;
    const passed = checks.filter((c) => c.check_status === 'pass').length;
    const total = checks.length;
    const complianceScore = total > 0 ? ((passed / total) * 100).toFixed(2) : 0;

    // Group by framework
    const byFramework = {};
    checks.forEach((check) => {
      if (!byFramework[check.framework]) {
        byFramework[check.framework] = [];
      }
      byFramework[check.framework].push(check);
    });

    const report = {
      engagement: engResult.rows[0],
      generated_at: new Date(),
      compliance_score: complianceScore,
      total_checks: total,
      passed_checks: passed,
      failed_checks: total - passed,
      by_framework: byFramework,
    };

    // Log report generation
    await db.query(
      `INSERT INTO audit_log (user_id, action, resource_type, resource_id, details)
       VALUES ($1, $2, $3, $4, $5)`,
      [req.user.id, 'compliance_report_generated', 'engagement', req.params.engagement_id, JSON.stringify({ score: complianceScore })],
    );

    res.json(report);
  } catch (error) {
    logger.error('Generate compliance report error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// POLICY & SCOPE ENFORCEMENT
// ================================================================

router.post('/scope-enforcement', authMiddleware, async (req, res) => {
  try {
    const { ip, service, port, is_in_scope } = req.body;

    const result = await db.query(
      `INSERT INTO scope_tracking (ip, service, port, is_in_scope, discovered_by)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (ip, port) DO UPDATE 
       SET is_in_scope = EXCLUDED.is_in_scope, updated_at = NOW()
       RETURNING *`,
      [ip, service, port, is_in_scope, req.user.id],
    );

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Scope enforcement error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
