#!/usr/bin/env python3
# ================================================================
# SIGNAL DECOMPOSITION & INTERACTIVE WAVEFORM EDITOR
# Break down signals, analyze components, drag-and-drop editing
# ================================================================

import numpy as np
import scipy.signal as signal
import scipy.fftpack as fftpack
from scipy.fft import fftfreq
from scipy.signal import morlet2, cwt
import pywt  # Wavelet transforms
from typing import Tuple, List, Dict, Optional
import json
import logging

logger = logging.getLogger(__name__)

# ================================================================
# SIGNAL DECOMPOSITION ENGINE
# Break signals into frequency, time-frequency, and wavelet domains
# ================================================================

class SignalDecomposer:
    """
    Multi-domain signal analysis:
    - Time domain (raw samples)
    - Frequency domain (FFT)
    - Time-frequency domain (STFT, spectrogram)
    - Wavelet domain (CWT, DWT)
    """
    
    def __init__(self, sample_rate: float = 1e6):
        self.sample_rate = sample_rate
        logger.info(f'SignalDecomposer initialized at {sample_rate/1e6:.1f} MS/s')
    
    # ================================================================
    # FREQUENCY DOMAIN ANALYSIS
    # ================================================================
    
    def analyze_frequency_domain(self, signal_data: np.ndarray) -> Dict:
        """
        FFT analysis - get magnitude and phase spectrum
        Returns frequency bins, magnitudes, phases
        """
        
        # Zero-pad to next power of 2 for efficiency
        n = len(signal_data)
        n_fft = 2 ** int(np.ceil(np.log2(n)))
        
        # Compute FFT
        fft_result = np.fft.fft(signal_data, n=n_fft)
        frequencies = fftfreq(n_fft, 1/self.sample_rate)
        
        # Only positive frequencies
        positive_freq_idx = frequencies >= 0
        frequencies_pos = frequencies[positive_freq_idx]
        magnitude = np.abs(fft_result[positive_freq_idx])
        phase = np.angle(fft_result[positive_freq_idx])
        
        # Normalize magnitude
        magnitude_db = 20 * np.log10(magnitude + 1e-10)
        
        # Find peaks (dominant frequencies)
        peaks, properties = signal.find_peaks(magnitude_db, height=-40, distance=10)
        dominant_freqs = frequencies_pos[peaks]
        dominant_mags = magnitude_db[peaks]
        
        return {
            'type': 'frequency_domain',
            'frequencies': frequencies_pos.tolist(),
            'magnitude_db': magnitude_db.tolist(),
            'magnitude_linear': magnitude.tolist(),
            'phase': phase.tolist(),
            'dominant_frequencies': dominant_freqs.tolist()[:10],  # Top 10
            'dominant_magnitudes': dominant_mags.tolist()[:10],
            'num_bins': len(frequencies_pos),
            'frequency_resolution': float((self.sample_rate / n_fft)),
        }
    
    # ================================================================
    # TIME-FREQUENCY DOMAIN ANALYSIS (STFT)
    # ================================================================
    
    def analyze_time_frequency_domain(
        self,
        signal_data: np.ndarray,
        window_size: int = 256,
        overlap: float = 0.75
    ) -> Dict:
        """
        STFT (Short-Time Fourier Transform) for time-frequency analysis
        Returns spectrogram: time vs frequency vs magnitude
        """
        
        # Window function
        window = signal.windows.hann(window_size)
        
        # Compute STFT
        f, t, Sxx = signal.spectrogram(
            signal_data,
            fs=self.sample_rate,
            window=window,
            noverlap=int(window_size * overlap),
            nperseg=window_size,
            scaling='spectrum'
        )
        
        # Convert to dB
        Sxx_db = 10 * np.log10(Sxx + 1e-10)
        
        return {
            'type': 'time_frequency_domain',
            'time_bins': t.tolist(),
            'frequency_bins': f.tolist(),
            'spectrogram_db': Sxx_db.tolist(),
            'num_time_bins': len(t),
            'num_frequency_bins': len(f),
            'time_resolution': float(np.mean(np.diff(t))),
            'frequency_resolution': float(np.mean(np.diff(f))),
        }
    
    # ================================================================
    # WAVELET DOMAIN ANALYSIS (CWT)
    # ================================================================
    
    def analyze_wavelet_domain(
        self,
        signal_data: np.ndarray,
        wavelet: str = 'morlet',
        scales: Optional[List[int]] = None
    ) -> Dict:
        """
        Continuous Wavelet Transform (CWT) for multi-resolution analysis
        Better time-frequency localization than STFT
        """
        
        if scales is None:
            # Generate scales from lowest to highest frequency
            scales = np.arange(1, min(len(signal_data) // 2, 256))
        
        # Compute CWT
        coefficients = cwt(signal_data, morlet2, scales)
        
        # Convert to power
        power = np.abs(coefficients) ** 2
        power_db = 10 * np.log10(power + 1e-10)
        
        # Get time array
        t = np.arange(len(signal_data)) / self.sample_rate
        
        # Convert scales to frequency
        frequencies = self.sample_rate / (2 * scales)
        
        return {
            'type': 'wavelet_domain',
            'time_array': t.tolist(),
            'scale_freqs': frequencies.tolist(),
            'wavelet': wavelet,
            'coefficients_magnitude': np.abs(coefficients).tolist(),
            'power_db': power_db.tolist(),
            'num_scales': len(scales),
            'num_time_samples': len(signal_data),
        }
    
    # ================================================================
    # AMPLITUDE ENVELOPE EXTRACTION
    # ================================================================
    
    def extract_envelope(self, signal_data: np.ndarray) -> Dict:
        """
        Extract amplitude envelope using analytic signal (Hilbert transform)
        Returns: time, envelope, instantaneous_phase, instantaneous_frequency
        """
        
        # Analytic signal
        analytic = signal.hilbert(signal_data)
        
        # Envelope (magnitude of analytic signal)
        envelope = np.abs(analytic)
        
        # Instantaneous phase
        inst_phase = np.unwrap(np.angle(analytic))
        
        # Instantaneous frequency (derivative of phase / 2π)
        inst_freq = np.diff(inst_phase) / (2 * np.pi) * self.sample_rate
        inst_freq = np.append(inst_freq, inst_freq[-1])  # Pad last sample
        
        t = np.arange(len(signal_data)) / self.sample_rate
        
        return {
            'type': 'envelope',
            'time': t.tolist(),
            'original_signal': signal_data.tolist(),
            'envelope': envelope.tolist(),
            'instantaneous_phase': inst_phase.tolist(),
            'instantaneous_frequency': inst_freq.tolist(),
            'peak_envelope': float(np.max(envelope)),
            'mean_envelope': float(np.mean(envelope)),
        }
    
    # ================================================================
    # PEAK & TROUGH DETECTION
    # ================================================================
    
    def detect_peaks_and_troughs(
        self,
        signal_data: np.ndarray,
        prominence: float = 0.1
    ) -> Dict:
        """
        Detect peaks (crests) and troughs in signal
        Returns: indices, values, for both peaks and troughs
        """
        
        # Detect peaks
        peaks, peak_props = signal.find_peaks(
            signal_data,
            height=-np.inf,
            prominence=prominence * np.max(np.abs(signal_data))
        )
        
        # Detect troughs (negative peaks)
        troughs, trough_props = signal.find_peaks(
            -signal_data,
            height=-np.inf,
            prominence=prominence * np.max(np.abs(signal_data))
        )
        
        t = np.arange(len(signal_data)) / self.sample_rate
        
        return {
            'type': 'peaks_troughs',
            'peaks': {
                'indices': peaks.tolist(),
                'times': t[peaks].tolist(),
                'values': signal_data[peaks].tolist(),
                'count': len(peaks),
            },
            'troughs': {
                'indices': troughs.tolist(),
                'times': t[troughs].tolist(),
                'values': signal_data[troughs].tolist(),
                'count': len(troughs),
            },
            'zero_crossings': self._find_zero_crossings(signal_data).tolist(),
        }
    
    def _find_zero_crossings(self, signal_data: np.ndarray) -> List[int]:
        """Find indices where signal crosses zero"""
        return np.where(np.diff(np.sign(signal_data)))[0].tolist()

# ================================================================
# INTERACTIVE WAVEFORM EDITOR
# Drag-and-drop peak/trough manipulation
# ================================================================

class InteractiveWaveformEditor:
    """
    Edit signals by:
    - Dragging peaks up/down
    - Dragging troughs up/down
    - Shifting frequency components
    - Modifying phase
    - Changing wavelengths
    """
    
    def __init__(self, sample_rate: float = 1e6):
        self.sample_rate = sample_rate
        self.edit_history = []
        logger.info('InteractiveWaveformEditor initialized')
    
    # ================================================================
    # PEAK/TROUGH MANIPULATION
    # ================================================================
    
    def edit_peak(
        self,
        signal_data: np.ndarray,
        peak_index: int,
        new_value: float,
        smoothing_range: int = 5
    ) -> np.ndarray:
        """
        Drag a peak to a new amplitude value
        Smoothly interpolate to preserve signal continuity
        """
        
        edited = signal_data.copy()
        
        # Direct modification
        edited[peak_index] = new_value
        
        # Smooth transition to neighbors
        for i in range(1, smoothing_range + 1):
            if peak_index - i >= 0:
                blend = (smoothing_range - i) / smoothing_range
                edited[peak_index - i] = blend * new_value + (1 - blend) * signal_data[peak_index - i]
            
            if peak_index + i < len(edited):
                blend = (smoothing_range - i) / smoothing_range
                edited[peak_index + i] = blend * new_value + (1 - blend) * signal_data[peak_index + i]
        
        logger.info(f'Peak at index {peak_index} modified to {new_value:.4f}')
        return edited
    
    def edit_trough(
        self,
        signal_data: np.ndarray,
        trough_index: int,
        new_value: float,
        smoothing_range: int = 5
    ) -> np.ndarray:
        """Drag a trough to a new amplitude value"""
        return self.edit_peak(signal_data, trough_index, new_value, smoothing_range)
    
    # ================================================================
    # FREQUENCY SHIFTING
    # ================================================================
    
    def shift_frequency(
        self,
        signal_data: np.ndarray,
        frequency_shift: float
    ) -> np.ndarray:
        """
        Shift all frequency components by frequency_shift
        Useful for changing carrier frequency
        """
        
        # Create modulation signal
        t = np.arange(len(signal_data)) / self.sample_rate
        modulation = np.exp(2j * np.pi * frequency_shift * t)
        
        # Apply modulation
        shifted = signal_data * modulation
        
        logger.info(f'Frequency shifted by {frequency_shift/1e6:.2f} MHz')
        return shifted
    
    # ================================================================
    # WAVELENGTH ADJUSTMENT
    # ================================================================
    
    def adjust_wavelength(
        self,
        signal_data: np.ndarray,
        stretch_factor: float
    ) -> np.ndarray:
        """
        Stretch or compress wavelength (change period)
        stretch_factor > 1 = longer wavelength (lower frequency)
        stretch_factor < 1 = shorter wavelength (higher frequency)
        """
        
        # Interpolation-based stretching
        original_indices = np.arange(len(signal_data))
        new_indices = original_indices / stretch_factor
        
        # Clip to valid range
        new_indices = np.clip(new_indices, 0, len(signal_data) - 1)
        
        # Interpolate
        stretched = np.interp(original_indices, new_indices, signal_data)
        
        logger.info(f'Wavelength adjusted by factor {stretch_factor:.2f}')
        return stretched
    
    # ================================================================
    # PHASE MODIFICATION
    # ================================================================
    
    def adjust_phase(
        self,
        signal_data: np.ndarray,
        phase_shift_radians: float
    ) -> np.ndarray:
        """
        Rotate phase of complex signal (or IQ data)
        """
        
        # If real signal, convert to analytic
        if np.iscomplexobj(signal_data):
            rotated = signal_data * np.exp(1j * phase_shift_radians)
        else:
            analytic = signal.hilbert(signal_data)
            rotated = analytic * np.exp(1j * phase_shift_radians)
            rotated = np.real(rotated)
        
        logger.info(f'Phase shifted by {np.degrees(phase_shift_radians):.1f} degrees')
        return rotated
    
    # ================================================================
    # HARMONIC FILTERING & REMOVAL
    # ================================================================
    
    def remove_harmonic(
        self,
        signal_data: np.ndarray,
        target_freq: float,
        bandwidth: float = 10000,  # Hz
        filter_order: int = 5
    ) -> np.ndarray:
        """
        Remove specific frequency component (harmonic)
        using notch filter
        """
        
        # Design notch filter
        quality_factor = target_freq / bandwidth
        
        # Butterworth notch
        w0 = 2 * target_freq / self.sample_rate
        b, a = signal.iirnotch(w0, quality_factor, fs=self.sample_rate)
        
        # Apply filter
        filtered = signal.filtfilt(b, a, signal_data)
        
        logger.info(f'Harmonic at {target_freq/1e6:.2f} MHz removed')
        return filtered
    
    def enhance_harmonic(
        self,
        signal_data: np.ndarray,
        target_freq: float,
        bandwidth: float = 50000,
        filter_order: int = 5
    ) -> np.ndarray:
        """
        Enhance specific frequency component using bandpass filter
        """
        
        # Design bandpass filter
        low_freq = target_freq - bandwidth / 2
        high_freq = target_freq + bandwidth / 2
        
        sos = signal.butter(filter_order, [low_freq, high_freq], 'band', fs=self.sample_rate, output='sos')
        filtered = signal.sosfiltfilt(sos, signal_data)
        
        logger.info(f'Harmonic at {target_freq/1e6:.2f} MHz enhanced')
        return filtered
    
    # ================================================================
    # COMPOSITE EDITING
    # ================================================================
    
    def apply_edits_batch(
        self,
        signal_data: np.ndarray,
        edits: List[Dict]
    ) -> np.ndarray:
        """
        Apply multiple edits in sequence
        edits = [
            {'type': 'peak', 'index': 50, 'new_value': 0.5},
            {'type': 'trough', 'index': 75, 'new_value': -0.3},
            {'type': 'frequency_shift', 'amount': 1e6},
            {'type': 'phase_shift', 'radians': 0.785},
        ]
        """
        
        edited = signal_data.copy()
        
        for edit in edits:
            edit_type = edit.get('type')
            
            if edit_type == 'peak':
                edited = self.edit_peak(edited, edit['index'], edit['new_value'])
            
            elif edit_type == 'trough':
                edited = self.edit_trough(edited, edit['index'], edit['new_value'])
            
            elif edit_type == 'frequency_shift':
                edited = self.shift_frequency(edited, edit['amount'])
            
            elif edit_type == 'wavelength':
                edited = self.adjust_wavelength(edited, edit['factor'])
            
            elif edit_type == 'phase_shift':
                edited = self.adjust_phase(edited, edit['radians'])
            
            elif edit_type == 'remove_harmonic':
                edited = self.remove_harmonic(edited, edit['frequency'], edit.get('bandwidth', 10000))
            
            elif edit_type == 'enhance_harmonic':
                edited = self.enhance_harmonic(edited, edit['frequency'], edit.get('bandwidth', 50000))
        
        self.edit_history.append({'edits': edits, 'timestamp': np.datetime64('now')})
        logger.info(f'Applied {len(edits)} edits')
        
        return edited

# ================================================================
# SIGNAL CAPTURE & REPLAY
# ================================================================

class SignalCaptureReplay:
    """
    Capture signal once, replay it infinitely with modifications
    """
    
    def __init__(self, sample_rate: float = 1e6):
        self.sample_rate = sample_rate
        self.captured_signals = {}
        logger.info('SignalCaptureReplay initialized')
    
    def capture_signal(
        self,
        signal_data: np.ndarray,
        signal_id: str,
        metadata: Optional[Dict] = None
    ) -> Dict:
        """Store captured signal"""
        
        self.captured_signals[signal_id] = {
            'data': signal_data,
            'metadata': metadata or {},
            'length_seconds': len(signal_data) / self.sample_rate,
            'num_samples': len(signal_data),
            'timestamp': np.datetime64('now'),
        }
        
        logger.info(f'Signal captured: {signal_id} ({len(signal_data)} samples)')
        
        return {
            'signal_id': signal_id,
            'num_samples': len(signal_data),
            'duration_seconds': len(signal_data) / self.sample_rate,
        }
    
    def replay_signal(
        self,
        signal_id: str,
        repetitions: int = 1,
        modifications: Optional[List[Dict]] = None
    ) -> np.ndarray:
        """Replay captured signal, optionally with modifications"""
        
        if signal_id not in self.captured_signals:
            raise ValueError(f'Signal {signal_id} not found')
        
        original = self.captured_signals[signal_id]['data']
        
        # Apply modifications if provided
        if modifications:
            editor = InteractiveWaveformEditor(self.sample_rate)
            modified = editor.apply_edits_batch(original, modifications)
        else:
            modified = original
        
        # Repeat signal
        replayed = np.tile(modified, repetitions)
        
        logger.info(f'Signal replayed: {signal_id} x{repetitions}')
        
        return replayed
    
    def list_captured_signals(self) -> List[Dict]:
        """List all captured signals"""
        return [
            {
                'signal_id': sig_id,
                'duration_seconds': data['length_seconds'],
                'num_samples': data['num_samples'],
            }
            for sig_id, data in self.captured_signals.items()
        ]

# ================================================================
# MAIN API FUNCTIONS
# ================================================================

async def decompose_signal(
    signal_data: np.ndarray,
    analysis_types: List[str],
    sample_rate: float = 1e6
) -> Dict:
    """
    Decompose signal into multiple domains
    analysis_types: ['frequency', 'time_frequency', 'wavelet', 'envelope', 'peaks']
    """
    
    decomposer = SignalDecomposer(sample_rate)
    results = {}
    
    if 'frequency' in analysis_types:
        results['frequency_domain'] = decomposer.analyze_frequency_domain(signal_data)
    
    if 'time_frequency' in analysis_types:
        results['time_frequency_domain'] = decomposer.analyze_time_frequency_domain(signal_data)
    
    if 'wavelet' in analysis_types:
        results['wavelet_domain'] = decomposer.analyze_wavelet_domain(signal_data)
    
    if 'envelope' in analysis_types:
        results['envelope'] = decomposer.extract_envelope(signal_data)
    
    if 'peaks' in analysis_types:
        results['peaks_troughs'] = decomposer.detect_peaks_and_troughs(signal_data)
    
    return results

if __name__ == '__main__':
    # Example: Decompose a test signal
    sample_rate = 1e6
    t = np.arange(10000) / sample_rate
    test_signal = (
        0.5 * np.sin(2 * np.pi * 1e5 * t) +  # 100 kHz component
        0.3 * np.sin(2 * np.pi * 2.5e5 * t) +  # 250 kHz component
        0.1 * np.random.randn(len(t))  # Noise
    )
    
    decomposer = SignalDecomposer(sample_rate)
    
    # Analyze
    print("=== Frequency Domain ===")
    freq_result = decomposer.analyze_frequency_domain(test_signal)
    print(f"Dominant frequencies: {freq_result['dominant_frequencies'][:5]}")
    
    # Edit
    editor = InteractiveWaveformEditor(sample_rate)
    edited = editor.shift_frequency(test_signal, 1e5)  # Shift by 100 kHz
    print("\n=== Frequency Shift Applied ===")
    print("Signal shifted by 100 kHz")
