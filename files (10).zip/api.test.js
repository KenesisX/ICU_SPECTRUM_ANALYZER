'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const net = require('node:net');
const crypto = require('node:crypto');
const { createApp } = require('../src/app');
const { hashPassword } = require('../src/auth');
const { acceptKey } = require('../src/ws');
const signal = require('../src/signal');

const CONFIG = {
  adminUsername: 'admin',
  adminPasswordHash: hashPassword('correct-horse-battery'),
  tokenSecret: 'x'.repeat(40),
  deviceToken: 'd'.repeat(30),
};

let server, port, base, token;

before(async () => {
  ({ server } = createApp(CONFIG));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  port = server.address().port;
  base = `http://127.0.0.1:${port}`;
});
after(() => new Promise((r) => { server.close(r); server.closeAllConnections(); }));

// ---------- minimal WebSocket test client (RFC 6455) ----------
function maskedFrame(text) {
  const payload = Buffer.from(text, 'utf8');
  const mask = crypto.randomBytes(4);
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x81, 0x80 | len]);
  } else {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 0x80 | 126;
    header.writeUInt16BE(len, 2);
  }
  const body = Buffer.alloc(len);
  for (let i = 0; i < len; i++) body[i] = payload[i] ^ mask[i % 4];
  return Buffer.concat([header, mask, body]);
}

function wsConnect(path) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(port, '127.0.0.1');
    const key = crypto.randomBytes(16).toString('base64');
    let buf = Buffer.alloc(0);
    let upgraded = false;
    const inbox = [];
    const waiters = [];

    function deliver(text) {
      if (waiters.length) waiters.shift()(text);
      else inbox.push(text);
    }

    sock.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      if (!upgraded) {
        const idx = buf.indexOf('\r\n\r\n');
        if (idx < 0) return;
        const head = buf.subarray(0, idx).toString();
        buf = buf.subarray(idx + 4);
        const status = Number(head.split(' ')[1]);
        const accept = /Sec-WebSocket-Accept: (.+)/.exec(head)?.[1]?.trim();
        if (status !== 101) return resolve({ status, close: () => sock.destroy() });
        upgraded = true;
        assert.equal(accept, acceptKey(key), 'server accept key must match RFC 6455');
        resolve({
          status,
          send: (t) => sock.write(maskedFrame(t)),
          next: (timeoutMs = 2000) =>
            new Promise((res, rej) => {
              if (inbox.length) return res(JSON.parse(inbox.shift()));
              const timer = setTimeout(() => rej(new Error('timed out waiting for message')), timeoutMs);
              waiters.push((t) => { clearTimeout(timer); res(JSON.parse(t)); });
            }),
          close: () => sock.destroy(),
        });
      }
      while (upgraded && buf.length >= 2) {
        let len = buf[1] & 0x7f;
        let off = 2;
        if (len === 126) {
          if (buf.length < 4) return;
          len = buf.readUInt16BE(2);
          off = 4;
        }
        if (buf.length < off + len) return;
        const payload = buf.subarray(off, off + len).toString('utf8');
        buf = buf.subarray(off + len);
        deliver(payload);
      }
    });
    sock.on('error', reject);
    sock.write(
      `GET ${path} HTTP/1.1\r\nHost: 127.0.0.1\r\nUpgrade: websocket\r\n` +
        `Connection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`
    );
  });
}

async function http(method, path, { body, auth } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(auth ? { Authorization: `Bearer ${auth}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: await res.json() };
}

const sine = (freq, fs, n, amp = 1) =>
  Array.from({ length: n }, (_, i) => amp * Math.sin((2 * Math.PI * freq * i) / fs));

// ---------- HTTP: health, auth ----------
test('health endpoint responds without auth', async () => {
  const r = await http('GET', '/health');
  assert.equal(r.status, 200);
});

test('login rejects wrong password and unknown user', async () => {
  assert.equal((await http('POST', '/api/v1/auth/login', { body: { username: 'admin', password: 'nope' } })).status, 401);
  assert.equal((await http('POST', '/api/v1/auth/login', { body: { username: 'root', password: 'correct-horse-battery' } })).status, 401);
});

test('login issues a token that unlocks protected routes', async () => {
  const r = await http('POST', '/api/v1/auth/login', { body: { username: 'admin', password: 'correct-horse-battery' } });
  assert.equal(r.status, 200);
  token = r.body.token;
  assert.ok(token.includes('.'));
  const devices = await http('GET', '/api/v1/devices', { auth: token });
  assert.equal(devices.status, 200);
  assert.deepEqual(devices.body.devices, []);
});

test('protected routes reject missing and forged tokens', async () => {
  assert.equal((await http('GET', '/api/v1/devices')).status, 401);
  assert.equal((await http('GET', '/api/v1/devices', { auth: token + 'x' })).status, 401);
  assert.equal((await http('GET', '/api/v1/devices', { auth: 'a.b' })).status, 401);
});

test('invalid JSON body is a 400, not a crash', async () => {
  const res = await fetch(base + '/api/v1/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{not json',
  });
  assert.equal(res.status, 400);
});

test('unknown route is a 404', async () => {
  assert.equal((await http('GET', '/api/v1/nope', { auth: token })).status, 404);
});

// ---------- signal analysis ----------
test('analyze finds a pure 1 kHz tone at the right frequency', async () => {
  // fs=8000, N=1024 gives 7.8125 Hz bins; 1000 Hz lands exactly on bin 128.
  const r = await http('POST', '/api/v1/signal/analyze', {
    auth: token, body: { samples: sine(1000, 8000, 1024), sample_rate: 8000 },
  });
  assert.equal(r.status, 200);
  assert.ok(Math.abs(r.body.dominant_frequencies[0].frequency_hz - 1000) < 1e-6);
  assert.ok(Math.abs(r.body.dominant_frequencies[0].amplitude - 1) < 1e-6);
  assert.ok(Math.abs(r.body.rms - Math.sqrt(0.5)) < 0.01);
});

test('analyze rejects bad input with 400', async () => {
  const bad = [
    { samples: [1, 2, 3] },                       // too short
    { samples: [1, 2, 3, 4, 5, 6, 7, 'x'] },      // non-numeric
    { samples: sine(1, 8, 16), sample_rate: -1 }, // bad rate
    {},                                           // missing
  ];
  for (const body of bad) {
    const r = await http('POST', '/api/v1/signal/analyze', { auth: token, body });
    assert.equal(r.status, 400, JSON.stringify(body).slice(0, 60));
  }
});

test('notch removes a chosen tone and keeps the others', () => {
  const fs = 8000, n = 1024;
  const x = sine(1000, fs, n).map((v, i) => v + sine(2000, fs, n)[i]);
  const y = signal.edit(x, [{ type: 'notch', frequency: 2000, bandwidth: 100 }], fs);
  const freqs = signal.analyze(y, fs).dominant_frequencies.map((d) => d.frequency_hz);
  assert.ok(freqs.some((f) => Math.abs(f - 1000) < 1e-6), 'kept 1 kHz');
  assert.ok(!freqs.some((f) => Math.abs(f - 2000) < 50), 'removed 2 kHz');
});

test('lowpass keeps a low tone and drops a high one', () => {
  const fs = 8000, n = 1024;
  const x = sine(1000, fs, n).map((v, i) => v + sine(3000, fs, n)[i]);
  const y = signal.edit(x, [{ type: 'lowpass', cutoff: 1500 }], fs);
  const top = signal.analyze(y, fs).dominant_frequencies[0];
  assert.ok(Math.abs(top.frequency_hz - 1000) < 1e-6);
  assert.ok(top.amplitude > 0.99);
});

test('gain and normalize work in the time domain', () => {
  const x = sine(500, 8000, 256, 0.5);
  const half = signal.edit(x, [{ type: 'gain', factor: 0.5 }], 8000);
  assert.ok(Math.abs(half[10] - x[10] * 0.5) < 1e-12);
  const norm = signal.edit(x, [{ type: 'normalize' }], 8000);
  assert.ok(Math.abs(Math.max(...norm.map(Math.abs)) - 1) < 1e-12);
});

test('edit rejects unknown ops and too many ops', () => {
  assert.throws(() => signal.edit(sine(1, 8, 16), [{ type: 'transmit' }]), /unknown op/);
  assert.throws(() => signal.edit(sine(1, 8, 16), Array(17).fill({ type: 'gain', factor: 1 })), /at most/);
});

test('edit endpoint returns samples and a fresh analysis', async () => {
  const r = await http('POST', '/api/v1/signal/edit', {
    auth: token,
    body: { samples: sine(1000, 8000, 1024), sample_rate: 8000, ops: [{ type: 'gain', factor: 2 }] },
  });
  assert.equal(r.status, 200);
  assert.equal(r.body.samples.length, 1024);
  assert.ok(Math.abs(r.body.analysis.peak - 2) < 1e-6);
});

// ---------- WebSocket: devices and Android clients ----------
test('ESP32 with a wrong device token is refused', async () => {
  const dev = await wsConnect('/ws/esp32?token=wrong');
  assert.equal(dev.status, 401);
});

test('Android client with a bad token is refused', async () => {
  const app = await wsConnect('/ws/android?token=bogus');
  assert.equal(app.status, 401);
});

test('device registers, Android sees it, commands flow both ways', async () => {
  const app = await wsConnect(`/ws/android?token=${token}`);
  assert.equal(app.status, 101);

  const dev = await wsConnect(`/ws/esp32?token=${'d'.repeat(30)}`);
  assert.equal(dev.status, 101);
  dev.send(JSON.stringify({ type: 'device_info', mac: 'AA:BB:CC:DD:EE:01', version: '2.0.0' }));

  const up = await app.next();
  assert.equal(up.type, 'device_update');
  assert.equal(up.device_id, 'AA:BB:CC:DD:EE:01');
  assert.equal(up.online, true);

  dev.send(JSON.stringify({ type: 'status', rssi: -51, uptime_s: 42 }));
  const st = await app.next();
  assert.equal(st.status.rssi, -51);

  app.send(JSON.stringify({ action: 'command', device_id: 'AA:BB:CC:DD:EE:01', command: 'led_on' }));
  const result = await app.next();
  assert.equal(result.type, 'command_result');
  assert.equal(result.ok, true);
  const cmd = await dev.next();
  assert.deepEqual(cmd, { command: 'led_on' });

  dev.send(JSON.stringify({ type: 'ack', command: 'led_on' }));
  const ack = await app.next();
  assert.equal(ack.type, 'ack');
  assert.equal(ack.command, 'led_on');

  app.send(JSON.stringify({ action: 'list_devices' }));
  const list = await app.next();
  assert.equal(list.devices[0].online, true);

  dev.close();
  const gone = await app.next();
  assert.equal(gone.online, false);
  app.close();
});

test('commands outside the allow-list are refused', async () => {
  const app = await wsConnect(`/ws/android?token=${token}`);
  const dev = await wsConnect(`/ws/esp32?token=${'d'.repeat(30)}`);
  dev.send(JSON.stringify({ type: 'device_info', mac: 'AA:BB:CC:DD:EE:02' }));
  await app.next();
  app.send(JSON.stringify({ action: 'command', device_id: 'AA:BB:CC:DD:EE:02', command: 'format_disk' }));
  const r = await app.next();
  assert.equal(r.ok, false);
  assert.equal(r.error, 'command not allowed');
  dev.close();
  app.close();
});

test('REST command to an offline device returns 409', async () => {
  const r = await http('POST', '/api/v1/devices/NO-SUCH-DEVICE/command', { auth: token, body: { command: 'led_on' } });
  assert.equal(r.status, 409);
});

test('REST command to a connected device returns 202', async () => {
  const dev = await wsConnect(`/ws/esp32?token=${'d'.repeat(30)}`);
  dev.send(JSON.stringify({ type: 'device_info', mac: 'AA:BB:CC:DD:EE:03' }));
  await new Promise((r) => setTimeout(r, 50));
  const r = await http('POST', '/api/v1/devices/AA%3ABB%3ACC%3ADD%3AEE%3A03/command', {
    auth: token, body: { command: 'led_off' },
  });
  assert.equal(r.status, 202);
  assert.deepEqual(await dev.next(), { command: 'led_off' });
  dev.close();
});
