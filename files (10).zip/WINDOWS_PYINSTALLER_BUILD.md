# 🪟 STRIKEBACK WINDOWS BUILD — PyInstaller (Simpler Single .EXE)

Build a **single Windows .exe** that doesn't require Node.js or npm.

**Easiest approach for distributing the app.**

---

## Quick Build (5 Minutes)

### Prerequisites
1. **Python 3.8+** installed on Windows
   - Download: https://www.python.org/downloads/
   - ✅ Check "Add Python to PATH" during install

2. **PyInstaller**
   ```cmd
   pip install pyinstaller
   ```

### Build Steps

1. **Place these files in a folder** (e.g., `C:\strikeback-app\`):
   - `strikeback_unified_command_center.html`
   - `strikeback_launcher.py`

2. **Open Command Prompt in that folder:**
   ```cmd
   cd C:\strikeback-app
   ```

3. **Build the .exe:**
   ```cmd
   pyinstaller --onefile --icon=icon.ico --name="STRIKEBACK Command Center" strikeback_launcher.py
   ```

4. **Done!** Your `.exe` is in `dist/` folder:
   ```
   C:\strikeback-app\dist\STRIKEBACK Command Center.exe
   ```

### That's it!
- **Single file** (~50 MB)
- **No dependencies** needed on target machine
- **Double-click to run**
- Opens app in default browser automatically

---

## Advanced Build with Icon

### Create a Custom Icon

1. **Create 256x256 PNG image** of your STRIKEBACK logo
2. **Convert to ICO** using online tool:
   - https://icoconvert.com/
   - Save as `icon.ico` in your build folder

3. **Build with icon:**
   ```cmd
   pyinstaller --onefile --icon=icon.ico --name="STRIKEBACK Command Center" strikeback_launcher.py
   ```

The `.exe` will display your custom icon.

---

## Build Script (Automated)

Create `build.bat` in your folder:

```batch
@echo off
echo [+] STRIKEBACK Command Center - Windows Build
echo [+] Using PyInstaller

pip install pyinstaller --quiet

echo [+] Building executable...
pyinstaller --onefile ^
  --icon=icon.ico ^
  --name="STRIKEBACK Command Center" ^
  --window ^
  --add-data "strikeback_unified_command_center.html;." ^
  strikeback_launcher.py

echo [+] Build complete!
echo [+] Your .exe is in: %cd%\dist\
pause
```

Run:
```cmd
build.bat
```

---

## What Users Get

Download: `STRIKEBACK Command Center.exe` (50 MB)

```
[Double-click .exe]
    ↓
[Console window opens briefly]
    ↓
[Browser launches automatically]
    ↓
[Full app loads]
```

Done! No installation, no dependencies, works offline.

---

## Advanced: Hide Console Window

Modify `strikeback_launcher.py` at the top:

```python
import ctypes

# Hide console window on Windows
if sys.platform == 'win32':
    import win32gui
    import win32con
    win = ctypes.windll.kernel32.GetConsoleWindow()
    ctypes.windll.user32.ShowWindow(win, 0)
```

Then install required package:
```cmd
pip install pypiwin32
```

Rebuild:
```cmd
pyinstaller --onefile --windowed --icon=icon.ico strikeback_launcher.py
```

---

## Multi-File Distribution (Advanced)

If you want to distribute without bundling the HTML:

1. **Create installer with PyInstaller + NSIS:**

```cmd
pip install pyinstaller nsis
```

2. **Create `.spec` file:**
```cmd
pyi-makespec --onefile --icon=icon.ico strikeback_launcher.py
```

3. **Customize spec file** to include resources

4. **Build:**
```cmd
pyinstaller strikeback_launcher.spec
```

---

## Comparison: PyInstaller vs Electron

| Feature | PyInstaller | Electron |
|---------|-------------|----------|
| File Size | 50 MB | 150 MB |
| Dependencies | None | None |
| Build Time | < 1 min | 3 min |
| Ease | ★★★★★ | ★★★ |
| Customization | Limited | High |
| Performance | Fast | Good |

**Recommendation: Use PyInstaller** for simple distribution.

---

## Distribution Methods

### Method 1: Direct Download
- Share `.exe` on your website
- Users download and run
- Works with cloud storage (Dropbox, Google Drive, etc.)

### Method 2: Self-Extracting Archive
```cmd
pip install py2exe
# Creates self-extracting .exe
```

### Method 3: Windows Store
- Package as MSIX
- Distribute through Microsoft Store
- Requires code signing

---

## File Checklist

Before building:
- ✅ Python 3.8+ installed (`python --version`)
- ✅ PyInstaller installed (`pip list | find "pyinstaller"`)
- ✅ `strikeback_launcher.py` in folder
- ✅ `strikeback_unified_command_center.html` in same folder
- ✅ `icon.ico` (optional)

---

## Troubleshooting

### "pyinstaller is not recognized"
```cmd
pip install pyinstaller
```
Restart Command Prompt.

### "Python is not recognized"
- Python not installed or not in PATH
- Download from https://python.org
- Check "Add to PATH" during install
- Restart computer

### Build hangs or takes 10+ minutes
- PyInstaller is unpacking dependencies
- This is normal for first build
- Wait for it to finish

### .exe won't start
1. Run from Command Prompt to see error:
   ```cmd
   "STRIKEBACK Command Center.exe"
   ```

2. Check if HTML file is in `dist/` folder (it should be auto-copied)

3. If missing, copy manually to `dist/` folder

### Browser doesn't open automatically
- Manually open: http://127.0.0.1:8888
- Or add `--open` flag to launcher script

---

## Signing & Distribution (Enterprise)

For corporate deployments, code sign your .exe:

```cmd
pip install signtool
signtool sign /f certificate.pfx /p password /t http://timestamp.server STRIKEBACK.exe
```

This prevents Windows Defender warnings for unknown publishers.

---

## One-Command Build

Save this as `quick-build.bat`:

```batch
@echo off
setlocal enabledelayedexpansion

if not exist "strikeback_unified_command_center.html" (
    echo [!] Error: strikeback_unified_command_center.html not found
    pause
    exit /b 1
)

pip install pyinstaller --quiet 2>nul

echo [+] Building STRIKEBACK Command Center...
pyinstaller --onefile ^
  --windowed ^
  --icon=icon.ico ^
  --name="STRIKEBACK Command Center" ^
  strikeback_launcher.py

if %errorlevel% equ 0 (
    echo [✓] Success! Your .exe is in: dist\STRIKEBACK Command Center.exe
) else (
    echo [!] Build failed. Check errors above.
)

pause
```

Run:
```cmd
quick-build.bat
```

---

## Next Steps

1. **Build the .exe** using PyInstaller
2. **Test locally** by double-clicking the executable
3. **Distribute** the single `.exe` file to users
4. **Users run** without installation, dependencies, or setup

Done! Your app is now a standalone Windows application. 🚀
