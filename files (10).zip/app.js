'use strict';
const http = require('http');
const { hashPassword, verifyPassword, createTokenService } = require('./auth');
const ws = require('./ws');
const signal = require('./signal');
const { createRegistry } = require('./devices');

const JSON_LIMIT = 2 * 1024 * 1024;

// config: { adminUsername, adminPasswordHash, tokenSecret, deviceToken }
function createApp(config) {
  for (const key of ['adminUsername', 'adminPasswordHash', 'tokenSecret', 'deviceToken']) {
    if (!config[key]) throw new Error(`missing config: ${key}`);
  }
  const tokens = createTokenService(config.tokenSecret);
  const registry = createRegistry();
  const androidClients = new Set();

  function broadcast(obj) {
    const text = JSON.stringify(obj);
    for (const c of androidClients) c.send(text);
  }

  function readJson(req) {
    return new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > JSON_LIMIT) {
          reject(Object.assign(new Error('payload too large'), { status: 413 }));
          req.destroy();
          return;
        }
        chunks.push(c);
      });
      req.on('end', () => {
        if (!chunks.length) return resolve({});
        try {
          resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
        } catch {
          reject(Object.assign(new Error('invalid JSON'), { status: 400 }));
        }
      });
      req.on('error', reject);
    });
  }

  function send(res, status, body) {
    const text = JSON.stringify(body);
    res.writeHead(status, {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(text),
      'Cache-Control': 'no-store',
    });
    res.end(text);
  }

  function requireUser(req) {
    const auth = req.headers.authorization || '';
    const user = tokens.verify(auth.startsWith('Bearer ') ? auth.slice(7) : null);
    return user;
  }

  async function handle(req, res) {
    const url = new URL(req.url, 'http://localhost');
    const path = url.pathname;
    const method = req.method;

    if (method === 'GET' && path === '/health') {
      return send(res, 200, { status: 'ok' });
    }

    if (method === 'POST' && path === '/api/v1/auth/login') {
      const body = await readJson(req);
      const okUser = body.username === config.adminUsername;
      // Always run the hash check so timing doesn't reveal which half failed.
      const okPass = verifyPassword(body.password || '', config.adminPasswordHash);
      if (!okUser || !okPass) return send(res, 401, { error: 'invalid credentials' });
      return send(res, 200, { token: tokens.issue(body.username) });
    }

    // Everything below requires a valid user token.
    const user = requireUser(req);
    if (!user) return send(res, 401, { error: 'unauthorized' });

    if (method === 'GET' && path === '/api/v1/devices') {
      return send(res, 200, { devices: registry.list() });
    }

    const cmdMatch = path.match(/^\/api\/v1\/devices\/([^/]+)\/command$/);
    if (method === 'POST' && cmdMatch) {
      const body = await readJson(req);
      const result = registry.sendCommand(decodeURIComponent(cmdMatch[1]), body.command);
      return send(res, result.ok ? 202 : 409, result);
    }

    if (method === 'POST' && path === '/api/v1/signal/analyze') {
      const body = await readJson(req);
      return send(res, 200, signal.analyze(body.samples, body.sample_rate));
    }

    if (method === 'POST' && path === '/api/v1/signal/edit') {
      const body = await readJson(req);
      const edited = signal.edit(body.samples, body.ops, body.sample_rate);
      return send(res, 200, { samples: edited, analysis: signal.analyze(edited, body.sample_rate) });
    }

    return send(res, 404, { error: 'not found' });
  }

  const server = http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      const status = err.status || (err instanceof RangeError || err instanceof TypeError ? 400 : 500);
      if (status === 500) console.error('[api]', err);
      if (!res.headersSent) send(res, status, { error: status === 500 ? 'internal error' : err.message });
    });
  });

  server.on('upgrade', (req, socket) => {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');

    if (url.pathname === '/ws/esp32') {
      if (token !== config.deviceToken) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        return socket.destroy();
      }
      let deviceId = null;
      ws.upgrade(req, socket, {
        onMessage(text, client) {
          let msg;
          try { msg = JSON.parse(text); } catch { return; }
          if (msg.type === 'device_info' && typeof msg.mac === 'string') {
            deviceId = msg.mac;
            registry.attach(deviceId, client);
            broadcast({ type: 'device_update', device_id: deviceId, online: true, status: msg });
          } else if (deviceId && msg.type === 'status') {
            const d = registry.update(deviceId, msg);
            broadcast({ type: 'device_update', device_id: deviceId, online: d.online, status: msg });
          } else if (deviceId && msg.type === 'ack') {
            registry.recordAck(deviceId, msg.command);
            broadcast({ type: 'ack', device_id: deviceId, command: msg.command });
          }
        },
        onClose(client) {
          registry.detach(client);
          if (deviceId) broadcast({ type: 'device_update', device_id: deviceId, online: false });
        },
      });
      return;
    }

    if (url.pathname === '/ws/android') {
      if (!tokens.verify(token)) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        return socket.destroy();
      }
      const client = ws.upgrade(req, socket, {
        onMessage(text, client) {
          let msg;
          try { msg = JSON.parse(text); } catch { return client.send(JSON.stringify({ type: 'error', error: 'invalid JSON' })); }
          if (msg.action === 'list_devices') {
            return client.send(JSON.stringify({ type: 'devices', devices: registry.list() }));
          }
          if (msg.action === 'command') {
            const result = registry.sendCommand(msg.device_id, msg.command);
            return client.send(JSON.stringify({ type: 'command_result', device_id: msg.device_id, command: msg.command, ...result }));
          }
          client.send(JSON.stringify({ type: 'error', error: 'unknown action' }));
        },
        onClose(client) {
          androidClients.delete(client);
        },
      });
      if (client) androidClients.add(client);
      return;
    }

    socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
    socket.destroy();
  });

  return { server, registry, tokens };
}

module.exports = { createApp, hashPassword };
