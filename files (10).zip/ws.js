'use strict';
// Minimal RFC 6455 server: handshake, text frames, ping/pong, close.
// Client->server frames must be masked (enforced). Fragments are reassembled.
const crypto = require('crypto');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 64 * 1024;

function acceptKey(key) {
  return crypto.createHash('sha1').update(key + GUID).digest('base64');
}

function encodeFrame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x80 | opcode, len]);
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

// Attach a WebSocket to a raw upgraded socket. Calls onMessage(text, client).
function attach(socket, { onMessage, onClose }) {
  let buf = Buffer.alloc(0);
  let fragments = [];
  let fragmentOpcode = null;
  let closed = false;

  const client = {
    send(text) {
      if (!closed) socket.write(encodeFrame(0x1, Buffer.from(text, 'utf8')));
    },
    close(code = 1000) {
      if (closed) return;
      closed = true;
      const body = Buffer.alloc(2);
      body.writeUInt16BE(code, 0);
      socket.end(encodeFrame(0x8, body));
    },
  };

  function fail() {
    client.close(1002);
  }

  function finish() {
    if (!closed) {
      closed = true;
      if (onClose) onClose(client);
    }
  }

  socket.on('data', (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const fin = (buf[0] & 0x80) !== 0;
      const opcode = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f;
      let offset = 2;

      if (!masked) return fail();
      if (len === 126) {
        if (buf.length < 4) return;
        len = buf.readUInt16BE(2);
        offset = 4;
      } else if (len === 127) {
        if (buf.length < 10) return;
        const big = buf.readBigUInt64BE(2);
        if (big > BigInt(MAX_PAYLOAD)) return fail();
        len = Number(big);
        offset = 10;
      }
      if (len > MAX_PAYLOAD) return fail();
      if (buf.length < offset + 4 + len) return;

      const mask = buf.subarray(offset, offset + 4);
      const payload = Buffer.alloc(len);
      for (let i = 0; i < len; i++) payload[i] = buf[offset + 4 + i] ^ mask[i % 4];
      buf = buf.subarray(offset + 4 + len);

      if (opcode === 0x8) return client.close(1000);
      if (opcode === 0x9) {
        socket.write(encodeFrame(0xa, payload));
        continue;
      }
      if (opcode === 0xa) continue;

      if (opcode === 0x1 || opcode === 0x2) {
        if (fragmentOpcode !== null) return fail();
        fragmentOpcode = opcode;
        fragments = [payload];
      } else if (opcode === 0x0) {
        if (fragmentOpcode === null) return fail();
        fragments.push(payload);
      } else {
        return fail();
      }

      const total = fragments.reduce((n, f) => n + f.length, 0);
      if (total > MAX_PAYLOAD) return fail();

      if (fin) {
        const message = Buffer.concat(fragments).toString('utf8');
        fragments = [];
        fragmentOpcode = null;
        onMessage(message, client);
      }
    }
  });

  // Peer sent FIN: treat as closed and end our side so the socket fully closes.
  socket.on('end', () => {
    finish();
    socket.end();
  });
  socket.on('close', finish);
  socket.on('error', () => {
    finish();
    socket.destroy();
  });
  return client;
}

// Complete the HTTP upgrade handshake, then attach. Returns the client or null.
function upgrade(req, socket, handlers) {
  const key = req.headers['sec-websocket-key'];
  const version = req.headers['sec-websocket-version'];
  if (!key || version !== '13') {
    socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
    socket.destroy();
    return null;
  }
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
      'Upgrade: websocket\r\n' +
      'Connection: Upgrade\r\n' +
      `Sec-WebSocket-Accept: ${acceptKey(key)}\r\n\r\n`
  );
  return attach(socket, handlers);
}

module.exports = { upgrade, encodeFrame, acceptKey, MAX_PAYLOAD };
