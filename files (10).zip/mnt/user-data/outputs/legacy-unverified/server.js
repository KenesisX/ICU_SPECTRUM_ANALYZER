// ================================================================
// STRIKEBACK 2.0 API SERVER
// Main entry point - HTTP + WebSocket server
// ================================================================

require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const logger = require('./utils/logger');
const db = require('./config/database');
const redis = require('./config/redis');

const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

// ================================================================
// MIDDLEWARE
// ================================================================

// Security headers
app.use(helmet());

// Compression
app.use(compression());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
});
app.use(limiter);

// CORS
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
}));

// Body parsing
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`, {
    ip: req.ip,
    userAgent: req.get('user-agent'),
  });
  next();
});

// ================================================================
// ROUTES
// ================================================================

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '2.0.0',
  });
});

// API routes
app.use('/api/v1/auth', require('./routes/auth'));
app.use('/api/v1/engagements', require('./routes/engagements'));
app.use('/api/v1/operations', require('./routes/operations'));
app.use('/api/v1/findings', require('./routes/findings'));
app.use('/api/v1/osint', require('./routes/osint'));
app.use('/api/v1/sdr', require('./routes/sdr'));
app.use('/api/v1/network', require('./routes/network'));
app.use('/api/v1/reports', require('./routes/reports'));
app.use('/api/v1/compliance', require('./routes/compliance'));
app.use('/api/v1/hardware', require('./routes/hardware'));
app.use('/api/v1/scripts', require('./routes/scripting'));
app.use('/api/v1/admin', require('./routes/admin'));

// ================================================================
// WEBSOCKET HANDLERS
// ================================================================

io.on('connection', (socket) => {
  logger.info(`User connected: ${socket.id}`);

  // Subscribe to streams
  socket.on('subscribe', (params) => {
    const { stream, ...options } = params;
    logger.debug(`Subscribe to stream: ${stream}`, { socketId: socket.id });
    
    socket.join(`stream:${stream}`);
    socket.emit('subscribed', { stream });
  });

  // Unsubscribe from streams
  socket.on('unsubscribe', (params) => {
    const { stream } = params;
    socket.leave(`stream:${stream}`);
    socket.emit('unsubscribed', { stream });
  });

  // Heartbeat
  socket.on('ping', () => {
    socket.emit('pong', { timestamp: Date.now() });
  });

  // Disconnect
  socket.on('disconnect', () => {
    logger.info(`User disconnected: ${socket.id}`);
  });

  // Error handling
  socket.on('error', (error) => {
    logger.error('WebSocket error', { error, socketId: socket.id });
  });
});

// ================================================================
// ERROR HANDLING
// ================================================================

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not found',
    message: `Endpoint ${req.method} ${req.path} not found`,
    timestamp: new Date().toISOString(),
  });
});

// Global error handler
app.use((err, req, res, next) => {
  logger.error('Global error handler', {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
  });

  const statusCode = err.statusCode || 500;
  const message = process.env.NODE_ENV === 'production'
    ? 'Internal server error'
    : err.message;

  res.status(statusCode).json({
    error: err.name || 'Error',
    message,
    timestamp: new Date().toISOString(),
  });
});

// ================================================================
// STARTUP
// ================================================================

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    // Test database connection
    await db.query('SELECT NOW()');
    logger.info('✓ Database connected');

    // Test Redis connection
    await redis.ping();
    logger.info('✓ Redis connected');

    // Start HTTP server
    httpServer.listen(PORT, () => {
      logger.info(`
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║     🚀 STRIKEBACK 2.0 API SERVER ONLINE                ║
║                                                          ║
║     HTTP + WebSocket: http://localhost:${PORT}
║     Environment: ${process.env.NODE_ENV || 'development'}
║     Version: 2.0.0                                      ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
      `);
    });
  } catch (error) {
    logger.error('Failed to start server', { error: error.message });
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  httpServer.close(() => {
    db.end();
    redis.disconnect();
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  httpServer.close(() => {
    db.end();
    redis.disconnect();
    process.exit(0);
  });
});

// Start
startServer();

module.exports = { app, httpServer, io };
