# Legacy / unverified

Everything in this folder is output from earlier sessions that was never compiled, run, or tested —
architecture docs, mock HTML dashboards, and backend route files written before the project was
rebuilt from scratch. Some of it describes features (23 "modules," ML signal classification, drone
integration, dark web monitoring, etc.) that were never implemented in working form — the descriptions
were produced, not the verified software.

It is kept here instead of deleted so no prior work is lost, but it is **not** part of the tested ICU
stack and should not be uploaded to Play Store, represented as working, or relied on without rebuilding
and testing it the same way `api/`, `android/`, `esp32/`, `pi-image/`, and `windows-launcher/` were.

If you want any specific piece of this rebuilt properly (tested, not just written), ask for it
specifically rather than assuming it already works.
