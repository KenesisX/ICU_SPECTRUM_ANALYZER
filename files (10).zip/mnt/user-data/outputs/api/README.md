# ICU API

Node 18+ (tested on Node 22). No npm dependencies: `npm install` is not needed.

## Run

    cp .env.example .env     # then fill in the four values
    export $(grep -v '^#' .env | xargs)
    node server.js           # http://localhost:5000

The server refuses to start if a secret is missing or too short. There are no default passwords.

## Test

    npm test

Starts the real server on a random port and checks auth, WebSocket framing, device
registration, the command allow-list, and signal analysis/editing.

## Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | /health | none | liveness |
| POST | /api/v1/auth/login | none | `{username,password}` -> `{token}` (12 h) |
| GET | /api/v1/devices | user | list ESP32 nodes and last status |
| POST | /api/v1/devices/:id/command | user | `{command}` -> 202 sent, 409 offline, 400 refused |
| POST | /api/v1/signal/analyze | user | `{samples,sample_rate}` -> RMS, peak, trough, extrema, dominant frequencies |
| POST | /api/v1/signal/edit | user | `{samples,sample_rate,ops}` -> edited samples + analysis |

Edit ops: `gain` (factor 0..10), `normalize`, `remove_dc`, `notch` (frequency, bandwidth),
`lowpass` (cutoff), `highpass` (cutoff). Up to 16 ops, up to 65,536 samples.

## WebSockets

- `/ws/esp32?token=<ICU_DEVICE_TOKEN>`: device sends `device_info` (with `mac`), `status`, `ack`.
  Server sends `{"command": "led_on" | "led_off" | "reboot"}`.
- `/ws/android?token=<user token>`: client sends `{action:"list_devices"}` or
  `{action:"command", device_id, command}`. Server pushes `device_update`, `ack`, `command_result`, `devices`.

## Not included

Transmit, replay, and frequency-shift-for-transmit are deliberately absent. Analysis and offline edits
are here. Any transmit path needs a licensed-band and authorization gate, designed separately.
