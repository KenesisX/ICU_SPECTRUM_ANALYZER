# Raspberry Pi image

pi-gen is the official tool for building Raspberry Pi OS images.

1. Clone https://github.com/RPi-Distro/pi-gen (bookworm branch).
2. Copy `config` and the `stage-icu/` folder into the pi-gen root.
3. Copy the API in: `mkdir -p stage-icu/02-app/files/app && cp -r ../api/. stage-icu/02-app/files/app/`
4. Set `FIRST_USER_PASS` in `config` to a real value.
5. Run `sudo ./build-docker.sh` (needs Docker). The image lands in `deploy/`.
6. Flash it with Raspberry Pi Imager ("Use custom") or `dd`.

On first boot, create the API's secrets file (the image does not contain one):

    sudo -u icu tee /opt/icu/.env <<'X'
    ICU_ADMIN_PASSWORD=<12+ chars>
    ICU_SECRET=<32+ chars>
    ICU_DEVICE_TOKEN=<24+ chars>
    X
    sudo systemctl restart icu-api

The FastAPI service (`backend_main.py`) is a separate component with its own dependencies. The image installs its service file but does not install its Python packages.
