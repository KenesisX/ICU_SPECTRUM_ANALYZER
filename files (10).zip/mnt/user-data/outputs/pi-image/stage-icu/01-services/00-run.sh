#!/bin/bash -e
install -m 644 files/icu-api.service     "${ROOTFS_DIR}/etc/systemd/system/"
install -m 644 files/icu-backend.service "${ROOTFS_DIR}/etc/systemd/system/"
on_chroot <<CHROOT
systemctl enable icu-api.service icu-backend.service
systemctl enable redis-server postgresql
ufw default deny incoming
ufw allow 22/tcp
ufw allow 5000/tcp
ufw --force enable
CHROOT
