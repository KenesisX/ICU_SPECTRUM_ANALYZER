# Windows .exe

PyInstaller only produces Windows executables on Windows. CI builds it on `windows-latest`.
Local build on Windows:

    py -m pip install pyinstaller
    pyinstaller --noconfirm ICU.spec
    # -> dist\ICU.exe

Requirements on the target machine: Node.js 18+ on PATH, and an `.env` file next to the exe
containing the API secrets (copy `api/.env.example`).
