# ICU Android

Build (needs JDK 17 and Android SDK; Android Studio does this for you):

    ./gradlew assembleRelease     # -> app/build/outputs/apk/release/app-release.apk
    ./gradlew bundleRelease       # -> app/build/outputs/bundle/release/app-release.aab

Unsigned unless you set these env vars:

    ICU_KEYSTORE=/path/to/upload.jks
    ICU_KEYSTORE_PASS=...
    ICU_KEY_ALIAS=...
    ICU_KEY_PASS=...

Create the upload key yourself (keep it private):

    keytool -genkeypair -v -keystore upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload

For the Play Store, enable Play App Signing and upload the .aab to Play Console.
Note: the app connects over plain ws:// on the LAN, so it is for local/lab use.
