-- ============================================================
-- STRIKEBACK 2.0 ENTERPRISE — PostgreSQL Schema
-- ============================================================
-- Full relational database design for all 23 features
-- ============================================================

-- ============================================================
-- ENABLE EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For full-text search

-- ============================================================
-- 1. AUTHENTICATION & USER MANAGEMENT
-- ============================================================

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL,  -- admin, lead, operator, analyst, guest
  status VARCHAR(50) DEFAULT 'active',  -- active, disabled, locked
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE TABLE user_roles (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  permissions JSONB NOT NULL,  -- JSON array of permission strings
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  resource_type VARCHAR(100) NOT NULL,
  resource_id VARCHAR(255),
  ip_address INET,
  status VARCHAR(50),
  details JSONB DEFAULT '{}',
  timestamp TIMESTAMP DEFAULT NOW(),
  encrypted_content BYTEA
);

CREATE INDEX audit_log_user_idx ON audit_log(user_id);
CREATE INDEX audit_log_timestamp_idx ON audit_log(timestamp DESC);
CREATE INDEX audit_log_resource_idx ON audit_log(resource_type, resource_id);

-- ============================================================
-- 2. ENGAGEMENTS & OPERATIONS
-- ============================================================

CREATE TABLE engagements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  client VARCHAR(255),
  scope JSONB NOT NULL,  -- { allowed_ips, domains, networks, etc }
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status VARCHAR(50) DEFAULT 'active',  -- active, paused, completed, archived
  authorization_doc_url VARCHAR(512),
  team_lead_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX engagements_status_idx ON engagements(status);

CREATE TABLE operations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  engagement_id UUID NOT NULL REFERENCES engagements(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL,  -- recon, pentest, physical, signal, etc
  description TEXT,
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  status VARCHAR(50) DEFAULT 'in_progress',  -- in_progress, completed, paused
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX operations_engagement_idx ON operations(engagement_id);
CREATE INDEX operations_status_idx ON operations(status);

CREATE TABLE findings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  severity VARCHAR(50) NOT NULL,  -- critical, high, medium, low
  cvss_score DECIMAL(3,1),
  status VARCHAR(50) DEFAULT 'open',  -- open, resolved, wont_fix
  evidence_ids UUID[] DEFAULT '{}',
  remediation TEXT,
  discovered_at TIMESTAMP DEFAULT NOW(),
  verified_at TIMESTAMP,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX findings_operation_idx ON findings(operation_id);
CREATE INDEX findings_severity_idx ON findings(severity);
CREATE INDEX findings_status_idx ON findings(status);

-- ============================================================
-- 3. SDR & SIGNAL PROCESSING
-- ============================================================

CREATE TABLE sdr_captures (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  device_type VARCHAR(100) NOT NULL,  -- RTL-SDR, HackRF, Pluto, etc
  device_serial VARCHAR(255),
  frequency_start BIGINT NOT NULL,  -- Hz
  frequency_end BIGINT NOT NULL,
  sample_rate BIGINT NOT NULL,  -- Hz
  bandwidth BIGINT NOT NULL,
  duration_seconds INT NOT NULL,
  file_path VARCHAR(512),
  file_size_bytes BIGINT,
  file_hash VARCHAR(128),
  gain INT DEFAULT 0,
  metadata JSONB DEFAULT '{}',
  captured_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX sdr_captures_operation_idx ON sdr_captures(operation_id);
CREATE INDEX sdr_captures_frequency_idx ON sdr_captures(frequency_start, frequency_end);

CREATE TABLE rf_signals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sdr_capture_id UUID NOT NULL REFERENCES sdr_captures(id) ON DELETE CASCADE,
  frequency BIGINT NOT NULL,  -- Hz
  modulation VARCHAR(50),  -- AM, FM, QPSK, PSK, FSK, etc
  bandwidth BIGINT,
  rssi DECIMAL(5,1),  -- dBm
  snr DECIMAL(5,1),  -- dB
  confidence DECIMAL(3,2) DEFAULT 0.00,
  signal_type VARCHAR(100),  -- WiFi, Bluetooth, ADS-B, AIS, etc
  decoded_data BYTEA,
  detected_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX rf_signals_capture_idx ON rf_signals(sdr_capture_id);
CREATE INDEX rf_signals_frequency_idx ON rf_signals(frequency);
CREATE INDEX rf_signals_signal_type_idx ON rf_signals(signal_type);

CREATE TABLE signal_decodings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  rf_signal_id UUID NOT NULL REFERENCES rf_signals(id) ON DELETE CASCADE,
  decoder_type VARCHAR(100) NOT NULL,
  decoder_version VARCHAR(50),
  decoded_data TEXT NOT NULL,
  raw_bytes BYTEA,
  decoded_at TIMESTAMP DEFAULT NOW(),
  confidence DECIMAL(3,2),
  metadata JSONB DEFAULT '{}'
);

-- ============================================================
-- 4. NETWORK & ASSETS
-- ============================================================

CREATE TABLE network_devices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  ip_address INET NOT NULL,
  hostname VARCHAR(255),
  mac_address MACADDR,
  os VARCHAR(255),
  os_version VARCHAR(50),
  device_type VARCHAR(100),  -- Server, Workstation, IoT, etc
  vendor VARCHAR(255),
  open_ports INT[] DEFAULT '{}',
  services JSONB DEFAULT '{}',  -- { port: service_name, ... }
  vulnerabilities UUID[] DEFAULT '{}',
  last_seen TIMESTAMP,
  discovered_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX network_devices_operation_idx ON network_devices(operation_id);
CREATE INDEX network_devices_ip_idx ON network_devices(ip_address);

CREATE TABLE network_topology (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  source_device_id UUID REFERENCES network_devices(id) ON DELETE CASCADE,
  dest_device_id UUID REFERENCES network_devices(id) ON DELETE CASCADE,
  relationship VARCHAR(100),  -- routes_to, managed_by, same_vlan, etc
  vlan INT,
  protocol VARCHAR(50),
  discovered_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX network_topology_operation_idx ON network_topology(operation_id);

CREATE TABLE vulnerabilities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  device_id UUID NOT NULL REFERENCES network_devices(id) ON DELETE CASCADE,
  cve_id VARCHAR(50),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  severity VARCHAR(50),
  cvss_score DECIMAL(3,1),
  exploitable BOOLEAN DEFAULT FALSE,
  remediation TEXT,
  discovered_at TIMESTAMP DEFAULT NOW(),
  verified_at TIMESTAMP,
  metadata JSONB DEFAULT '{}'
);

-- ============================================================
-- 5. OSINT & THREAT INTELLIGENCE
-- ============================================================

CREATE TABLE osint_results (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  source VARCHAR(50) NOT NULL,  -- shodan, censys, virustotal, otx, etc
  query VARCHAR(512) NOT NULL,
  result_data JSONB NOT NULL,
  raw_response TEXT,
  status VARCHAR(50),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX osint_results_operation_idx ON osint_results(operation_id);
CREATE INDEX osint_results_source_idx ON osint_results(source);

CREATE TABLE threats (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  source VARCHAR(100) NOT NULL,  -- AlienVault OTX, etc
  indicator_type VARCHAR(50) NOT NULL,  -- ip, domain, hash, email, etc
  indicator_value VARCHAR(512) NOT NULL,
  severity VARCHAR(50),
  confidence DECIMAL(3,2),
  context_data JSONB DEFAULT '{}',
  discovered_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX threats_operation_idx ON threats(operation_id);
CREATE INDEX threats_indicator_idx ON threats(indicator_type, indicator_value);

CREATE TABLE leaked_credentials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username VARCHAR(255),
  email VARCHAR(255),
  password_hash VARCHAR(255),
  source VARCHAR(100),
  breach_name VARCHAR(255),
  date_found TIMESTAMP,
  severity VARCHAR(50) DEFAULT 'high',
  metadata JSONB DEFAULT '{}',
  discovered_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX leaked_credentials_email_idx ON leaked_credentials(email);

-- ============================================================
-- 6. LOCATION TRACKING & GIS
-- ============================================================

CREATE TABLE gps_points (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  location GEOGRAPHY(POINT, 4326) NOT NULL,  -- PostGIS point
  latitude DECIMAL(10, 6) NOT NULL,
  longitude DECIMAL(10, 6) NOT NULL,
  altitude DECIMAL(10, 2),
  accuracy_meters DECIMAL(6, 1),
  signal_strength INT,  -- dBm
  timestamp TIMESTAMP DEFAULT NOW()
);

CREATE INDEX gps_points_operation_idx ON gps_points(operation_id);
CREATE INDEX gps_points_location_idx ON gps_points USING GIST (location);

CREATE TABLE aircraft_positions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  icao_code VARCHAR(10) UNIQUE,
  callsign VARCHAR(50),
  location GEOGRAPHY(POINT, 4326),
  latitude DECIMAL(10, 6),
  longitude DECIMAL(10, 6),
  altitude_feet INT,
  speed_knots INT,
  course_degrees INT,
  last_updated TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX aircraft_positions_location_idx ON aircraft_positions USING GIST (location);

CREATE TABLE vessel_positions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  mmsi VARCHAR(20) UNIQUE,
  name VARCHAR(255),
  location GEOGRAPHY(POINT, 4326),
  latitude DECIMAL(10, 6),
  longitude DECIMAL(10, 6),
  course_degrees INT,
  speed_knots DECIMAL(5, 1),
  call_sign VARCHAR(50),
  ship_type VARCHAR(100),
  last_updated TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX vessel_positions_location_idx ON vessel_positions USING GIST (location);

-- ============================================================
-- 7. PHYSICAL SECURITY
-- ============================================================

CREATE TABLE locks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  lock_type VARCHAR(100) NOT NULL,  -- pin_tumbler, wafer, smart, biometric, etc
  manufacturer VARCHAR(255),
  model VARCHAR(255),
  vulnerabilities TEXT[] DEFAULT '{}',
  bypass_methods TEXT[],
  defeat_time_minutes INT,
  difficulty_rating INT,  -- 1-5
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE ir_sensors (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID REFERENCES operations(id) ON DELETE CASCADE,
  sensor_type VARCHAR(100) NOT NULL,
  location GEOGRAPHY(POINT, 4326),
  range_meters INT,
  field_of_view_degrees INT,
  blind_spots TEXT,
  power_type VARCHAR(50),  -- battery, mains, etc
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE access_doors (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID REFERENCES operations(id) ON DELETE CASCADE,
  location VARCHAR(255) NOT NULL,
  access_type VARCHAR(50),  -- keypad, card, biometric, etc
  reader_model VARCHAR(255),
  timing_data JSONB DEFAULT '{}',  -- unlock times, codes, etc
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- 8. REPORTING & COMPLIANCE
-- ============================================================

CREATE TABLE report_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  sections JSONB NOT NULL,  -- Ordered array of section definitions
  formatting JSONB DEFAULT '{}',  -- CSS, fonts, colors, etc
  rules_engine_id UUID,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  engagement_id UUID NOT NULL REFERENCES engagements(id) ON DELETE CASCADE,
  template_id UUID REFERENCES report_templates(id),
  title VARCHAR(255) NOT NULL,
  report_type VARCHAR(50),  -- executive, technical, findings, etc
  content JSONB NOT NULL,
  file_path VARCHAR(512),
  file_format VARCHAR(50),  -- pdf, docx, html, xlsx
  generated_at TIMESTAMP DEFAULT NOW(),
  generated_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX reports_engagement_idx ON reports(engagement_id);

CREATE TABLE compliance_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  engagement_id UUID NOT NULL REFERENCES engagements(id) ON DELETE CASCADE,
  rule_name VARCHAR(255) NOT NULL,
  rule_text TEXT NOT NULL,
  rule_type VARCHAR(50),  -- scope, authorization, time_based, etc
  severity VARCHAR(50) DEFAULT 'high',
  status VARCHAR(50) DEFAULT 'active',
  enforcement_mode VARCHAR(50) DEFAULT 'block',  -- block, warn, log
  conditions JSONB NOT NULL,  -- Rule conditions in JSON
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- 9. TEAM COLLABORATION
-- ============================================================

CREATE TABLE team_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES users(id),
  recipient_ids UUID[] NOT NULL,
  content TEXT NOT NULL,
  encrypted_content BYTEA,  -- AES-256-GCM encrypted
  thread_id UUID,
  is_encrypted BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW(),
  read_at TIMESTAMP
);

CREATE INDEX team_messages_sender_idx ON team_messages(sender_id);
CREATE INDEX team_messages_thread_idx ON team_messages(thread_id);

CREATE TABLE shared_evidence (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evidence_id VARCHAR(255) NOT NULL,
  shared_by UUID NOT NULL REFERENCES users(id),
  shared_with UUID[] NOT NULL,
  access_level VARCHAR(50),  -- view, edit, admin
  shared_at TIMESTAMP DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE TABLE comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  finding_id UUID NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES users(id),
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  edited_by UUID REFERENCES users(id),
  resolved BOOLEAN DEFAULT FALSE
);

CREATE INDEX comments_finding_idx ON comments(finding_id);

-- ============================================================
-- 10. AUTOMATION & SCRIPTING
-- ============================================================

CREATE TABLE scripts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  language VARCHAR(50) NOT NULL,  -- python, lua, javascript
  name VARCHAR(255) NOT NULL,
  code TEXT NOT NULL,
  description TEXT,
  category VARCHAR(100),
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  is_public BOOLEAN DEFAULT FALSE,
  version INT DEFAULT 1
);

CREATE TABLE scheduled_tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  script_id UUID NOT NULL REFERENCES scripts(id) ON DELETE CASCADE,
  cron_expression VARCHAR(50) NOT NULL,
  last_run TIMESTAMP,
  next_run TIMESTAMP,
  status VARCHAR(50) DEFAULT 'scheduled',  -- scheduled, running, paused
  execution_timeout_seconds INT DEFAULT 3600,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE script_executions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  script_id UUID NOT NULL REFERENCES scripts(id),
  scheduled_task_id UUID REFERENCES scheduled_tasks(id) ON DELETE SET NULL,
  status VARCHAR(50),  -- running, success, failed, timeout
  exit_code INT,
  stdout TEXT,
  stderr TEXT,
  started_at TIMESTAMP DEFAULT NOW(),
  ended_at TIMESTAMP,
  duration_seconds INT,
  executed_by UUID NOT NULL REFERENCES users(id)
);

-- ============================================================
-- 11. HARDWARE & DEVICES
-- ============================================================

CREATE TABLE hardware_devices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID REFERENCES operations(id) ON DELETE CASCADE,
  device_type VARCHAR(100) NOT NULL,  -- RTL-SDR, HackRF, ESP32, etc
  manufacturer VARCHAR(255),
  model VARCHAR(255),
  serial_number VARCHAR(255) UNIQUE,
  firmware_version VARCHAR(50),
  status VARCHAR(50) DEFAULT 'connected',
  last_sync TIMESTAMP,
  battery_level INT,  -- Percentage
  location VARCHAR(255),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE device_config (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  hardware_device_id UUID NOT NULL REFERENCES hardware_devices(id) ON DELETE CASCADE,
  config_json JSONB NOT NULL,
  applied_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  version INT DEFAULT 1
);

CREATE TABLE device_telemetry (
  id BIGSERIAL PRIMARY KEY,
  hardware_device_id UUID NOT NULL REFERENCES hardware_devices(id) ON DELETE CASCADE,
  timestamp TIMESTAMP DEFAULT NOW(),
  metric_name VARCHAR(100) NOT NULL,
  metric_value DECIMAL(10, 2),
  unit VARCHAR(50),
  raw_data JSONB DEFAULT '{}'
);

CREATE INDEX device_telemetry_device_idx ON device_telemetry(hardware_device_id);
CREATE INDEX device_telemetry_timestamp_idx ON device_telemetry(timestamp DESC);

-- ============================================================
-- 12. TIME-SERIES DATA
-- ============================================================

CREATE TABLE signal_timeseries (
  time TIMESTAMP NOT NULL,
  frequency BIGINT NOT NULL,
  rssi DECIMAL(5, 1),
  modulation VARCHAR(50),
  signal_id UUID REFERENCES rf_signals(id),
  sdr_capture_id UUID NOT NULL REFERENCES sdr_captures(id) ON DELETE CASCADE
) PARTITION BY RANGE (time);

CREATE INDEX signal_timeseries_capture_idx ON signal_timeseries(sdr_capture_id, time DESC);

CREATE TABLE network_traffic_timeseries (
  time TIMESTAMP NOT NULL,
  source_ip INET,
  dest_ip INET,
  bytes_in BIGINT,
  bytes_out BIGINT,
  protocol VARCHAR(50),
  operation_id UUID NOT NULL
);

CREATE INDEX network_traffic_timeseries_time_idx ON network_traffic_timeseries(time DESC);

CREATE TABLE threat_indicators_timeseries (
  time TIMESTAMP NOT NULL,
  indicator_type VARCHAR(50),
  count INT,
  severity VARCHAR(50),
  operation_id UUID
);

-- ============================================================
-- 13. FREQUENCY DATABASE
-- ============================================================

CREATE TABLE frequency_allocations (
  id SERIAL PRIMARY KEY,
  frequency_hz BIGINT NOT NULL UNIQUE,
  frequency_mhz DECIMAL(12, 3),
  frequency_ghz DECIMAL(12, 3),
  band_name VARCHAR(100),
  primary_use VARCHAR(255),
  region VARCHAR(50),  -- US, EU, etc
  notes TEXT,
  modulation_types VARCHAR(255)[] DEFAULT '{}',
  common_devices VARCHAR(255)[] DEFAULT '{}',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX frequency_allocations_frequency_idx ON frequency_allocations(frequency_hz);
CREATE INDEX frequency_allocations_band_idx ON frequency_allocations(band_name);

-- ============================================================
-- 14. VIEWS FOR ANALYTICS
-- ============================================================

CREATE VIEW active_findings AS
SELECT
  f.id,
  f.title,
  f.severity,
  f.status,
  o.name as operation_name,
  e.name as engagement_name
FROM findings f
JOIN operations o ON f.operation_id = o.id
JOIN engagements e ON o.engagement_id = e.id
WHERE f.status = 'open'
ORDER BY
  CASE f.severity
    WHEN 'critical' THEN 1
    WHEN 'high' THEN 2
    WHEN 'medium' THEN 3
    WHEN 'low' THEN 4
  END,
  f.created_at DESC;

CREATE VIEW signal_summary AS
SELECT
  date_trunc('hour', detected_at) as hour,
  signal_type,
  COUNT(*) as signal_count,
  AVG(CAST(rssi AS FLOAT)) as avg_rssi,
  MAX(CAST(rssi AS FLOAT)) as max_rssi
FROM rf_signals
GROUP BY hour, signal_type
ORDER BY hour DESC;

CREATE VIEW scope_compliance_check AS
SELECT
  f.id,
  f.title,
  n.ip_address,
  e.scope,
  CASE
    WHEN (e.scope::text LIKE '%' || n.ip_address::text || '%')
         THEN 'IN_SCOPE'
    ELSE 'OUT_OF_SCOPE'
  END as compliance_status
FROM findings f
JOIN operations o ON f.operation_id = o.id
JOIN engagements e ON o.engagement_id = e.id
JOIN network_devices n ON o.id = n.operation_id;

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================

CREATE INDEX users_role_idx ON users(role);
CREATE INDEX engagements_team_lead_idx ON engagements(team_lead_idx);
CREATE INDEX operations_created_by_idx ON operations(created_by);
CREATE INDEX sdr_captures_created_at_idx ON sdr_captures(created_at DESC);
CREATE INDEX findings_created_at_idx ON findings(created_at DESC);

-- ============================================================
-- GRANT PERMISSIONS (customize as needed)
-- ============================================================

-- GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO api_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO api_user;

-- ============================================================
-- SEED DATA (optional)
-- ============================================================

INSERT INTO user_roles (name, permissions) VALUES
  ('admin', '["all"]'::jsonb),
  ('lead', '["engagement_management", "team_oversight", "report_generation"]'::jsonb),
  ('operator', '["operation_execution", "findings_entry", "evidence_capture"]'::jsonb),
  ('analyst', '["read_all", "analysis", "reporting"]'::jsonb),
  ('guest', '["read_only"]'::jsonb);

-- Create default frequency allocations
INSERT INTO frequency_allocations (frequency_hz, frequency_mhz, band_name, primary_use, notes, common_devices)
VALUES
  (433920000, 433.92, 'ISM Band', 'Smart Meters, IoT, Garage Openers', 'Unlicensed, 25mW typical', ARRAY['SDR', 'IoT Devices']),
  (1090000000, 1090.0, 'ADS-B', 'Aircraft Tracking', '1090 MHz Mode-S', ARRAY['RTL-SDR', 'HackRF']),
  (2400000000, 2400.0, 'ISM 2.4GHz', 'WiFi, Bluetooth, Zigbee, NRF24', 'Crowded band', ARRAY['WiFi AP', 'BT Devices', 'Zigbee']),
  (162550000, 162.55, 'NOAA Weather', 'Weather Alerts', 'Public broadcasts', ARRAY['RTL-SDR']);

-- ============================================================
-- END OF SCHEMA
-- ============================================================
