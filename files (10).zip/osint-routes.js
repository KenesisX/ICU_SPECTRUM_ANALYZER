// ================================================================
// OSINT HUB - SHODAN, VIRUSTOTAL, CENSYS, OTX INTEGRATION
// Module 5: OSINT Integration Hub
// ================================================================

const express = require('express');
const axios = require('axios');
const db = require('../config/database');
const cache = require('../config/redis-config');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// Threat Intel APIs
const SHODAN_API = process.env.SHODAN_API_KEY;
const VT_API = process.env.VIRUSTOTAL_API_KEY;
const CENSYS_API = process.env.CENSYS_API_ID;
const CENSYS_SECRET = process.env.CENSYS_API_SECRET;
const OTX_API = process.env.OTX_API_KEY;

// ================================================================
// SHODAN INTEGRATION
// ================================================================

router.post('/shodan/search', authMiddleware, async (req, res) => {
  try {
    const { query } = req.body;

    // Check cache
    const cached = await cache.get(`shodan:${query}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const response = await axios.get('https://api.shodan.io/shodan/host/search', {
      params: { query, key: SHODAN_API },
    });

    // Cache for 24 hours
    await cache.set(`shodan:${query}`, JSON.stringify(response.data), 86400);

    // Log search
    await db.query(
      `INSERT INTO osint_searches (user_id, source, query, result_count)
       VALUES ($1, $2, $3, $4)`,
      [req.user.id, 'shodan', query, response.data.total],
    );

    res.json(response.data);
  } catch (error) {
    logger.error('Shodan search error', { error: error.message });
    res.status(500).json({ error: 'Shodan search failed' });
  }
});

router.post('/shodan/host/:ip', authMiddleware, async (req, res) => {
  try {
    const { ip } = req.params;

    const cached = await cache.get(`shodan:host:${ip}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const response = await axios.get(`https://api.shodan.io/shodan/host/${ip}`, {
      params: { key: SHODAN_API },
    });

    await cache.set(`shodan:host:${ip}`, JSON.stringify(response.data), 86400);

    res.json(response.data);
  } catch (error) {
    logger.error('Shodan host lookup error', { error: error.message });
    res.status(500).json({ error: 'Host lookup failed' });
  }
});

// ================================================================
// VIRUSTOTAL INTEGRATION
// ================================================================

router.post('/vt/file', authMiddleware, async (req, res) => {
  try {
    const { hash } = req.body; // MD5, SHA-1, or SHA-256

    const cached = await cache.get(`vt:file:${hash}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const response = await axios.get(`https://www.virustotal.com/api/v3/files/${hash}`, {
      headers: { 'x-apikey': VT_API },
    });

    await cache.set(`vt:file:${hash}`, JSON.stringify(response.data), 86400);

    res.json(response.data.data);
  } catch (error) {
    logger.error('VirusTotal file lookup error', { error: error.message });
    res.status(500).json({ error: 'File lookup failed' });
  }
});

router.post('/vt/url', authMiddleware, async (req, res) => {
  try {
    const { url } = req.body;

    // Hash the URL for caching
    const urlHash = require('crypto').createHash('md5').update(url).digest('hex');
    const cached = await cache.get(`vt:url:${urlHash}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const response = await axios.post('https://www.virustotal.com/api/v3/urls', 
      new URLSearchParams({ url }),
      { headers: { 'x-apikey': VT_API } },
    );

    await cache.set(`vt:url:${urlHash}`, JSON.stringify(response.data), 86400);

    res.json(response.data.data);
  } catch (error) {
    logger.error('VirusTotal URL scan error', { error: error.message });
    res.status(500).json({ error: 'URL scan failed' });
  }
});

router.post('/vt/ip', authMiddleware, async (req, res) => {
  try {
    const { ip } = req.body;

    const cached = await cache.get(`vt:ip:${ip}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const response = await axios.get(`https://www.virustotal.com/api/v3/ip_addresses/${ip}`, {
      headers: { 'x-apikey': VT_API },
    });

    await cache.set(`vt:ip:${ip}`, JSON.stringify(response.data), 86400);

    res.json(response.data.data);
  } catch (error) {
    logger.error('VirusTotal IP lookup error', { error: error.message });
    res.status(500).json({ error: 'IP lookup failed' });
  }
});

// ================================================================
// CENSYS INTEGRATION
// ================================================================

router.post('/censys/hosts', authMiddleware, async (req, res) => {
  try {
    const { query } = req.body;

    const cached = await cache.get(`censys:hosts:${query}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const auth = Buffer.from(`${CENSYS_API}:${CENSYS_SECRET}`).toString('base64');

    const response = await axios.post('https://censys.io/api/v2/hosts/search',
      { q: query },
      { headers: { Authorization: `Basic ${auth}` } },
    );

    await cache.set(`censys:hosts:${query}`, JSON.stringify(response.data), 86400);

    res.json(response.data);
  } catch (error) {
    logger.error('Censys hosts search error', { error: error.message });
    res.status(500).json({ error: 'Censys search failed' });
  }
});

router.post('/censys/certs', authMiddleware, async (req, res) => {
  try {
    const { query } = req.body;

    const auth = Buffer.from(`${CENSYS_API}:${CENSYS_SECRET}`).toString('base64');

    const response = await axios.post('https://censys.io/api/v2/certificates/search',
      { q: query },
      { headers: { Authorization: `Basic ${auth}` } },
    );

    res.json(response.data);
  } catch (error) {
    logger.error('Censys certs search error', { error: error.message });
    res.status(500).json({ error: 'Certificate search failed' });
  }
});

// ================================================================
// OTX (Open Threat Exchange) INTEGRATION
// ================================================================

router.post('/otx/indicators', authMiddleware, async (req, res) => {
  try {
    const { indicator } = req.body;

    const cached = await cache.get(`otx:${indicator}`);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const response = await axios.get(
      `https://otx.alienvault.com/api/v1/indicators/ip/${indicator}`,
      { headers: { 'X-OTX-API-KEY': OTX_API } },
    );

    await cache.set(`otx:${indicator}`, JSON.stringify(response.data), 86400);

    res.json(response.data);
  } catch (error) {
    logger.error('OTX lookup error', { error: error.message });
    res.status(500).json({ error: 'OTX lookup failed' });
  }
});

// ================================================================
// INTELLIGENCE STORAGE & ANALYSIS
// ================================================================

router.post('/intelligence/create', authMiddleware, async (req, res) => {
  try {
    const { title, type, source, data, threat_level, tags } = req.body;

    const result = await db.query(
      `INSERT INTO intelligence_reports (user_id, title, type, source, data, threat_level, tags)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [req.user.id, title, type, source, JSON.stringify(data), threat_level, JSON.stringify(tags)],
    );

    logger.info('Intelligence report created', { reportId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create intelligence report error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/intelligence', authMiddleware, async (req, res) => {
  try {
    const { threat_level, type, limit = 50 } = req.query;

    let query = 'SELECT * FROM intelligence_reports WHERE 1=1';
    const params = [];

    if (threat_level) {
      query += ' AND threat_level = $1';
      params.push(threat_level);
    }

    if (type) {
      query += ` AND type = $${params.length + 1}`;
      params.push(type);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get intelligence reports error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
