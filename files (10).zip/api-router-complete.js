// ================================================================
// MAIN API ROUTER - STRIKEBACK 2.0 COMPLETE
// Integrates all 23 modules into unified REST API
// ================================================================

const express = require('express');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// ================================================================
// MODULE IMPORTS
// ================================================================

// Core Modules (1-4)
const engagementsRouter = require('../routes/engagements');
const teamsRouter = require('../routes/teams');
const complianceRouter = require('../routes/compliance');
// Command Palette is UI-only (handled in frontend)

// Recon Modules (5-8)
const osintRouter = require('../routes/osint');
const networkGisRouter = require('../routes/network-gis');
// Frequency Almanac and Runbooks are integrated within SDR/Search

// SDR Modules (9-12)
const sdrTimestreamRouter = require('../routes/sdr-timeseries');

// Pentesting Modules (13-16)
const findingsRouter = require('../routes/findings');
const physicalSocialRouter = require('../routes/physical-social');
// Vulnerability & Exploit DB included in findings

// Automation Modules (17-19)
const scriptingAutomationRouter = require('../routes/scripting-automation');

// Specialist Modules (20-23)
const runbooksDarkwebRouter = require('../routes/runbooks-darkweb-search');

// ================================================================
// API V1 ROUTER SETUP
// ================================================================

// Core
router.use('/engagements', engagementsRouter);
router.use('/teams', teamsRouter);
router.use('/compliance', complianceRouter);

// Recon
router.use('/osint', osintRouter);
router.use('/network', networkGisRouter);

// SDR
router.use('/sdr', sdrTimestreamRouter);

// Pentesting
router.use('/findings', findingsRouter);
router.use('/security', physicalSocialRouter);

// Automation
router.use('/scripts', scriptingAutomationRouter);

// Specialist
router.use('/knowledge', runbooksDarkwebRouter);

// ================================================================
// DASHBOARD & ANALYTICS ENDPOINTS
// ================================================================

const db = require('../config/database');
const logger = require('../utils/logger');

// GET /api/v1/dashboard - Overview metrics
router.get('/dashboard', authMiddleware, async (req, res) => {
  try {
    // Get engagement stats
    const engStatsResult = await db.query(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
      FROM engagements
    `);

    // Get finding stats
    const findingStatsResult = await db.query(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical,
        SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high,
        SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open
      FROM findings
    `);

    // Get team stats
    const teamStatsResult = await db.query('SELECT COUNT(*) as total FROM teams');

    // Recent activity
    const activityResult = await db.query(`
      SELECT action, resource_type, COUNT(*) as count
      FROM audit_log
      WHERE timestamp > NOW() - INTERVAL '24 hours'
      GROUP BY action, resource_type
      ORDER BY count DESC
      LIMIT 10
    `);

    res.json({
      engagements: engStatsResult.rows[0],
      findings: findingStatsResult.rows[0],
      teams: teamStatsResult.rows[0],
      recent_activity: activityResult.rows,
      timestamp: new Date(),
    });
  } catch (error) {
    logger.error('Dashboard error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/v1/stats/timeline - Activity timeline for dashboard charts
router.get('/stats/timeline', authMiddleware, async (req, res) => {
  try {
    const { days = 30 } = req.query;

    const result = await db.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as findings_created,
        SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical_found
      FROM findings
      WHERE created_at > NOW() - INTERVAL '${days} days'
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    `);

    res.json(result.rows);
  } catch (error) {
    logger.error('Timeline stats error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/v1/status - System health check
router.get('/status', async (req, res) => {
  try {
    const dbCheck = await db.query('SELECT NOW()');
    const status = dbCheck.rows.length > 0 ? 'healthy' : 'unhealthy';

    res.json({
      status,
      database: status,
      version: '2.0.0',
      timestamp: new Date(),
    });
  } catch (error) {
    logger.error('Status check failed', { error: error.message });
    res.status(500).json({
      status: 'unhealthy',
      database: 'down',
      error: error.message,
    });
  }
});

// ================================================================
// BULK OPERATIONS
// ================================================================

// POST /api/v1/bulk/findings - Import multiple findings
router.post('/bulk/findings', authMiddleware, async (req, res) => {
  try {
    const { engagement_id, findings } = req.body;

    if (!Array.isArray(findings) || findings.length === 0) {
      return res.status(400).json({ error: 'Invalid findings array' });
    }

    const results = [];

    for (const finding of findings) {
      const result = await db.query(
        `INSERT INTO findings 
         (engagement_id, reported_by, title, description, severity, status)
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING *`,
        [
          engagement_id,
          req.user.id,
          finding.title,
          finding.description,
          finding.severity,
          'open',
        ],
      );
      results.push(result.rows[0]);
    }

    logger.info('Bulk findings imported', { count: results.length, engagementId: engagement_id });

    res.status(201).json({
      imported: results.length,
      results,
    });
  } catch (error) {
    logger.error('Bulk import error', { error: error.message });
    res.status(500).json({ error: 'Bulk import failed' });
  }
});

// ================================================================
// EXPORT & REPORTING
// ================================================================

// GET /api/v1/export/:engagement_id - Export engagement data
router.get('/export/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const { format = 'json' } = req.query;

    // Get all data for engagement
    const engResult = await db.query(
      'SELECT * FROM engagements WHERE id = $1',
      [req.params.engagement_id],
    );

    if (engResult.rows.length === 0) {
      return res.status(404).json({ error: 'Engagement not found' });
    }

    const findingsResult = await db.query(
      'SELECT * FROM findings WHERE engagement_id = $1',
      [req.params.engagement_id],
    );

    const nodesResult = await db.query(
      'SELECT * FROM network_nodes WHERE engagement_id = $1',
      [req.params.engagement_id],
    );

    const exportData = {
      engagement: engResult.rows[0],
      findings: findingsResult.rows,
      network_nodes: nodesResult.rows,
      exported_at: new Date(),
    };

    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="engagement_${req.params.engagement_id}.json"`);
      res.json(exportData);
    } else {
      // CSV format
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="engagement_${req.params.engagement_id}.csv"`);
      // Simplified CSV export
      const csv = `Title,Severity,Status\n${exportData.findings.map(
        (f) => `"${f.title}","${f.severity}","${f.status}"`,
      ).join('\n')}`;
      res.send(csv);
    }

    logger.info('Data exported', { engagementId: req.params.engagement_id, format });
  } catch (error) {
    logger.error('Export error', { error: error.message });
    res.status(500).json({ error: 'Export failed' });
  }
});

// ================================================================
// ACTIVITY LOG & AUDIT
// ================================================================

// GET /api/v1/audit - Audit log for compliance
router.get('/audit', authMiddleware, async (req, res) => {
  try {
    const { user_id, action, limit = 1000 } = req.query;

    let query = 'SELECT * FROM audit_log WHERE 1=1';
    const params = [];

    if (user_id) {
      query += ' AND user_id = $1';
      params.push(user_id);
    }

    if (action) {
      query += ` AND action = $${params.length + 1}`;
      params.push(action);
    }

    query += ` ORDER BY timestamp DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Audit log error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
