'use strict';
// Signal analysis and editing on real-valued sample arrays.
// Pure functions: no I/O, no randomness, safe to unit test.

const MAX_SAMPLES = 1 << 16;
const MAX_OPS = 16;

function nextPow2(n) {
  let p = 1;
  while (p < n) p <<= 1;
  return p;
}

// In-place iterative radix-2 Cooley-Tukey FFT. Length must be a power of two.
function fft(re, im, inverse = false) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const half = len >> 1;
    const sign = inverse ? 1 : -1;
    for (let k = 0; k < half; k++) {
      const wr = Math.cos((2 * Math.PI * k) / len);
      const wi = sign * Math.sin((2 * Math.PI * k) / len);
      for (let i = 0; i < n; i += len) {
        const a = i + k;
        const b = a + half;
        const vr = re[b] * wr - im[b] * wi;
        const vi = re[b] * wi + im[b] * wr;
        re[b] = re[a] - vr;
        im[b] = im[a] - vi;
        re[a] += vr;
        im[a] += vi;
      }
    }
  }
  if (inverse) {
    for (let i = 0; i < n; i++) {
      re[i] /= n;
      im[i] /= n;
    }
  }
}

function validateSamples(samples) {
  if (!Array.isArray(samples)) throw new TypeError('samples must be an array of numbers');
  if (samples.length < 8) throw new RangeError('need at least 8 samples');
  if (samples.length > MAX_SAMPLES) throw new RangeError(`at most ${MAX_SAMPLES} samples`);
  for (const s of samples) {
    if (typeof s !== 'number' || !Number.isFinite(s)) {
      throw new TypeError('samples must be finite numbers');
    }
  }
}

function validateSampleRate(sampleRate) {
  if (typeof sampleRate !== 'number' || !(sampleRate > 0) || !Number.isFinite(sampleRate)) {
    throw new RangeError('sample_rate must be a positive number');
  }
}

function analyze(samples, sampleRate = 1e6) {
  validateSamples(samples);
  validateSampleRate(sampleRate);
  const n = samples.length;

  let sum = 0, min = Infinity, max = -Infinity, sq = 0;
  for (const s of samples) {
    sum += s;
    sq += s * s;
    if (s < min) min = s;
    if (s > max) max = s;
  }
  const mean = sum / n;
  const rms = Math.sqrt(sq / n);

  let zeroCrossings = 0;
  for (let i = 1; i < n; i++) {
    if ((samples[i - 1] - mean) * (samples[i] - mean) < 0) zeroCrossings++;
  }

  // Spectrum of the mean-removed signal, zero-padded to a power of two.
  const N = nextPow2(n);
  const re = new Float64Array(N);
  const im = new Float64Array(N);
  for (let i = 0; i < n; i++) re[i] = samples[i] - mean;
  fft(re, im);

  const bins = [];
  for (let k = 1; k <= N / 2; k++) {
    const amp = (2 * Math.hypot(re[k], im[k])) / n;
    bins.push({ bin: k, frequency_hz: (k * sampleRate) / N, amplitude: amp });
  }
  // Local maxima in the spectrum, strongest first.
  const dominant = bins
    .filter((b, i) => {
      const prev = i > 0 ? bins[i - 1].amplitude : -Infinity;
      const next = i < bins.length - 1 ? bins[i + 1].amplitude : -Infinity;
      return b.amplitude >= prev && b.amplitude >= next && b.amplitude > 0;
    })
    .sort((a, b) => b.amplitude - a.amplitude)
    .slice(0, 5)
    .map(({ frequency_hz, amplitude }) => ({ frequency_hz, amplitude }));

  // Local extrema in the time domain.
  let peakCount = 0, troughCount = 0;
  for (let i = 1; i < n - 1; i++) {
    if (samples[i] > samples[i - 1] && samples[i] >= samples[i + 1]) peakCount++;
    if (samples[i] < samples[i - 1] && samples[i] <= samples[i + 1]) troughCount++;
  }

  return {
    length: n,
    sample_rate: sampleRate,
    duration_s: n / sampleRate,
    mean,
    rms,
    peak: max,
    trough: min,
    peak_count: peakCount,
    trough_count: troughCount,
    zero_crossings: zeroCrossings,
    dominant_frequencies: dominant,
  };
}

function applyFrequencyMask(samples, sampleRate, keep) {
  const n = samples.length;
  const N = nextPow2(n);
  const re = new Float64Array(N);
  const im = new Float64Array(N);
  for (let i = 0; i < n; i++) re[i] = samples[i];
  fft(re, im);
  for (let k = 0; k < N; k++) {
    // Frequency of bin k, folded so negative-frequency bins mirror positive ones.
    const f = (k <= N / 2 ? k : k - N) * (sampleRate / N);
    if (!keep(f)) {
      re[k] = 0;
      im[k] = 0;
    }
  }
  fft(re, im, true);
  return Array.from(re.subarray(0, n));
}

function applyOp(samples, sampleRate, op) {
  if (!op || typeof op !== 'object' || typeof op.type !== 'string') {
    throw new TypeError('each op needs a string "type"');
  }
  switch (op.type) {
    case 'gain': {
      const f = Number(op.factor);
      if (!Number.isFinite(f) || f < 0 || f > 10) throw new RangeError('gain factor must be 0..10');
      return samples.map((s) => s * f);
    }
    case 'normalize': {
      const m = Math.max(...samples.map(Math.abs));
      return m === 0 ? samples.slice() : samples.map((s) => s / m);
    }
    case 'remove_dc': {
      const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
      return samples.map((s) => s - mean);
    }
    case 'notch': {
      const f0 = Number(op.frequency);
      const bw = Number(op.bandwidth ?? 1000);
      if (!(f0 > 0) || !(bw > 0)) throw new RangeError('notch needs positive frequency and bandwidth');
      return applyFrequencyMask(samples, sampleRate, (f) => Math.abs(Math.abs(f) - f0) > bw / 2);
    }
    case 'lowpass': {
      const fc = Number(op.cutoff);
      if (!(fc > 0)) throw new RangeError('lowpass needs a positive cutoff');
      return applyFrequencyMask(samples, sampleRate, (f) => Math.abs(f) <= fc);
    }
    case 'highpass': {
      const fc = Number(op.cutoff);
      if (!(fc > 0)) throw new RangeError('highpass needs a positive cutoff');
      return applyFrequencyMask(samples, sampleRate, (f) => Math.abs(f) >= fc);
    }
    default:
      throw new RangeError(`unknown op type: ${op.type}`);
  }
}

function edit(samples, ops, sampleRate = 1e6) {
  validateSamples(samples);
  validateSampleRate(sampleRate);
  if (!Array.isArray(ops)) throw new TypeError('ops must be an array');
  if (ops.length > MAX_OPS) throw new RangeError(`at most ${MAX_OPS} ops`);
  let current = samples.slice();
  for (const op of ops) current = applyOp(current, sampleRate, op);
  return current;
}

module.exports = { fft, analyze, edit, MAX_SAMPLES, MAX_OPS };
