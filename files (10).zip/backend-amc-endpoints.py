#!/usr/bin/env python3
# ================================================================
# STRIKEBACK BACKEND - UPDATED WITH AMC & WAVEFORM ENDPOINTS
# Add to existing backend_main.py
# ================================================================

# ADD TO IMPORTS at top of backend_main.py:
"""
import sys
sys.path.insert(0, '/path/to/strikeback/python')
from amc_waveform_engine import (
    ModulationClassifier,
    DifferentiableWaveformEngine,
    ModulationSynthesizer,
    amc_classify_from_iq,
    generate_modulated_waveform
)
"""

# ================================================================
# ADD NEW FASTAPI ENDPOINTS
# ================================================================

# POST /api/v1/amc/classify
@app.post('/api/v1/amc/classify')
async def amc_classify(req: Dict):
    """
    Advanced Modulation Classification using CNN/LSTM
    Identifies modulation type from raw IQ data
    """
    try:
        iq_data = np.array(req['iq_data'], dtype=np.complex128)
        frequency = req.get('frequency')
        
        classifier = ModulationClassifier()
        result = classifier.classify(iq_data)
        
        logger.info(f'AMC classification: {result["modulation"]} ({result["confidence"]:.2%})')
        
        return result
    
    except Exception as e:
        logger.error(f'AMC classification error: {str(e)}')
        return {'error': str(e), 'modulation': 'unknown', 'confidence': 0}

# POST /api/v1/waveform/generate
@app.post('/api/v1/waveform/generate')
async def waveform_generate(req: Dict, background_tasks: BackgroundTasks):
    """
    Generate OFDM or OTFS waveforms with specified modulation
    """
    try:
        modulation = req['modulation']
        num_symbols = req['num_symbols']
        waveform_type = req.get('waveform_type', 'ofdm')
        num_subcarriers = req.get('num_subcarriers', 64)
        num_ofdm_symbols = req.get('num_ofdm_symbols', 14)
        sample_rate = req.get('sample_rate', 1e6)
        carrier_freq = req.get('carrier_freq', 2.4e9)
        
        # Generate symbols
        symbols = ModulationSynthesizer.generate_symbols(num_symbols, modulation)
        
        # Generate waveform
        engine = DifferentiableWaveformEngine(sample_rate=sample_rate, carrier_freq=carrier_freq)
        
        if waveform_type == 'ofdm':
            baseband = engine.generate_ofdm(
                symbols,
                num_subcarriers=num_subcarriers,
                modulation=modulation
            )
        elif waveform_type == 'otfs':
            baseband = engine.generate_otfs(
                symbols,
                num_subcarriers=num_subcarriers,
                num_ofdm_symbols=num_ofdm_symbols,
                modulation=modulation
            )
        else:
            baseband = symbols
        
        # Apply pulse shaping
        baseband = engine.apply_pulse_shaping(baseband, filter_type='rrc')
        
        # Upconvert to RF
        rf_signal = engine.upconvert_to_rf(baseband, carrier_freq)
        
        logger.info(f'Waveform generated: {waveform_type.upper()} {modulation} - {len(baseband)} samples')
        
        return {
            'success': True,
            'waveform_type': waveform_type,
            'modulation': modulation,
            'num_symbols': num_symbols,
            'num_samples': len(baseband),
            'num_subcarriers': num_subcarriers,
            'sample_rate': float(sample_rate),
            'carrier_freq': float(carrier_freq),
            'peak_power': float(np.max(np.abs(rf_signal) ** 2)),
            'baseband_iq': baseband[:1000].tolist(),  # First 1000 samples
            'rf_signal': rf_signal[:1000].tolist(),
        }
    
    except Exception as e:
        logger.error(f'Waveform generation error: {str(e)}')
        return {'success': False, 'error': str(e)}

# POST /api/v1/waveform/optimize
@app.post('/api/v1/waveform/optimize')
async def waveform_optimize(req: Dict):
    """
    Optimize symbols using TensorFlow gradient descent for channel
    """
    try:
        initial_symbols = np.array(req['initial_symbols'], dtype=np.complex128)
        channel_response = np.array(req['channel_response'], dtype=np.complex128)
        num_iterations = req.get('num_iterations', 100)
        learning_rate = req.get('learning_rate', 0.01)
        
        engine = DifferentiableWaveformEngine()
        optimized_symbols, final_loss = engine.optimize_waveform_for_channel(
            initial_symbols,
            channel_response,
            num_iterations=num_iterations,
            learning_rate=learning_rate
        )
        
        logger.info(f'Optimization complete: final_loss = {final_loss:.6f}')
        
        return {
            'success': True,
            'num_symbols': len(optimized_symbols),
            'final_loss': float(final_loss),
            'num_iterations': num_iterations,
            'optimized_symbols': optimized_symbols.tolist()[:100],  # First 100
        }
    
    except Exception as e:
        logger.error(f'Optimization error: {str(e)}')
        return {'success': False, 'error': str(e)}

# POST /api/v1/waveform/pulse-shape
@app.post('/api/v1/waveform/pulse-shape')
async def waveform_pulse_shape(req: Dict):
    """
    Apply pulse shaping filter to waveform
    """
    try:
        waveform = np.array(req['waveform'], dtype=np.complex128)
        filter_type = req.get('filter_type', 'rrc')
        rolloff = req.get('rolloff', 0.35)
        
        engine = DifferentiableWaveformEngine()
        shaped = engine.apply_pulse_shaping(waveform, filter_type=filter_type, rolloff=rolloff)
        
        logger.info(f'Pulse shaping applied: {filter_type} (rolloff={rolloff})')
        
        return {
            'success': True,
            'filter_type': filter_type,
            'rolloff': rolloff,
            'num_samples': len(shaped),
            'peak_power': float(np.max(np.abs(shaped) ** 2)),
            'shaped_waveform': shaped.tolist()[:1000],
        }
    
    except Exception as e:
        logger.error(f'Pulse shaping error: {str(e)}')
        return {'success': False, 'error': str(e)}

# POST /api/v1/waveform/upconvert
@app.post('/api/v1/waveform/upconvert')
async def waveform_upconvert(req: Dict):
    """
    Upconvert baseband waveform to RF carrier frequency
    """
    try:
        baseband = np.array(req['baseband'], dtype=np.complex128)
        carrier_freq = float(req['carrier_freq'])
        sample_rate = float(req.get('sample_rate', 1e6))
        
        engine = DifferentiableWaveformEngine(sample_rate=sample_rate)
        rf_signal = engine.upconvert_to_rf(baseband, carrier_freq)
        
        logger.info(f'Upconversion: {carrier_freq/1e9:.2f} GHz carrier')
        
        return {
            'success': True,
            'carrier_freq': float(carrier_freq),
            'sample_rate': float(sample_rate),
            'num_samples': len(rf_signal),
            'peak_power': float(np.max(np.abs(rf_signal) ** 2)),
            'rf_signal': rf_signal.tolist()[:1000],
        }
    
    except Exception as e:
        logger.error(f'Upconversion error: {str(e)}')
        return {'success': False, 'error': str(e)}

# POST /api/v1/waveform/apply-channel
@app.post('/api/v1/waveform/apply-channel')
async def waveform_apply_channel(req: Dict):
    """
    Simulate waveform through channel model (AWGN, Rayleigh, Rician, multipath)
    """
    try:
        waveform = np.array(req['waveform'], dtype=np.complex128)
        channel_model = req.get('channel_model', 'awgn')
        snr_db = float(req.get('snr_db', 20))
        doppler_freq = float(req.get('doppler_freq', 0))
        
        # Channel simulation
        if channel_model == 'awgn':
            # Add white Gaussian noise
            noise_power = 10 ** (-snr_db / 10)
            noise = np.sqrt(noise_power / 2) * (
                np.random.randn(len(waveform)) + 1j * np.random.randn(len(waveform))
            )
            received = waveform + noise
        
        elif channel_model == 'rayleigh':
            # Rayleigh fading
            h = np.sqrt(0.5) * (
                np.random.randn(len(waveform)) + 1j * np.random.randn(len(waveform))
            )
            received = waveform * h
            
            # Add noise
            noise_power = 10 ** (-snr_db / 10)
            noise = np.sqrt(noise_power / 2) * (
                np.random.randn(len(waveform)) + 1j * np.random.randn(len(waveform))
            )
            received += noise
        
        elif channel_model == 'rician':
            # Rician fading (LOS + Rayleigh)
            los_component = np.sqrt(0.5)
            rayleigh = np.sqrt(0.5) * (
                np.random.randn(len(waveform)) + 1j * np.random.randn(len(waveform))
            )
            h = los_component + rayleigh / np.sqrt(2)
            received = waveform * h
            
            noise_power = 10 ** (-snr_db / 10)
            noise = np.sqrt(noise_power / 2) * (
                np.random.randn(len(waveform)) + 1j * np.random.randn(len(waveform))
            )
            received += noise
        
        elif channel_model == 'multipath':
            # Multipath with multiple delayed copies
            delays = [0, 2, 5]  # Sample delays
            hs = [1.0, 0.7, 0.4]  # Path gains
            received = np.zeros(len(waveform), dtype=np.complex128)
            
            for delay, h in zip(delays, hs):
                delayed = np.roll(waveform, delay) * h
                received += delayed
            
            noise_power = 10 ** (-snr_db / 10)
            noise = np.sqrt(noise_power / 2) * (
                np.random.randn(len(waveform)) + 1j * np.random.randn(len(waveform))
            )
            received += noise
        
        else:
            received = waveform
        
        # Apply Doppler if specified
        if doppler_freq != 0:
            t = np.arange(len(received)) / 1e6  # Assuming 1 MHz sample rate
            doppler = np.exp(2j * np.pi * doppler_freq * t)
            received = received * doppler
        
        logger.info(f'Channel simulation: {channel_model} SNR={snr_db}dB Doppler={doppler_freq}Hz')
        
        return {
            'success': True,
            'channel_model': channel_model,
            'snr_db': float(snr_db),
            'doppler_freq': float(doppler_freq),
            'num_samples': len(received),
            'received_signal': received.tolist()[:1000],
            'signal_power': float(np.mean(np.abs(received) ** 2)),
        }
    
    except Exception as e:
        logger.error(f'Channel simulation error: {str(e)}')
        return {'success': False, 'error': str(e)}

# POST /api/v1/signal/modulation-stats
@app.post('/api/v1/signal/modulation-stats')
async def modulation_stats(req: Dict):
    """
    Compute modulation-specific statistics from signal
    """
    try:
        iq_data = np.array(req['iq_data'], dtype=np.complex128)
        
        # Compute statistics
        power = np.mean(np.abs(iq_data) ** 2)
        peak_power = np.max(np.abs(iq_data) ** 2)
        papr = peak_power / power if power > 0 else 0  # Peak-to-Average Power Ratio
        
        # Amplitude envelope
        envelope = np.abs(iq_data)
        
        # Phase continuity
        phase = np.unwrap(np.angle(iq_data))
        phase_std = np.std(np.diff(phase))
        
        # Spectral analysis
        fft = np.abs(np.fft.fft(iq_data))
        spectral_flatness = np.exp(np.mean(np.log(fft + 1e-10))) / (np.mean(fft) + 1e-10)
        
        return {
            'success': True,
            'power_db': float(10 * np.log10(power + 1e-10)),
            'peak_power_db': float(10 * np.log10(peak_power + 1e-10)),
            'papr_db': float(10 * np.log10(papr + 1e-10)),
            'crest_factor': float(np.sqrt(peak_power / power) if power > 0 else 0),
            'phase_std': float(phase_std),
            'spectral_flatness': float(spectral_flatness),
            'mean_amplitude': float(np.mean(envelope)),
            'std_amplitude': float(np.std(envelope)),
        }
    
    except Exception as e:
        logger.error(f'Modulation stats error: {str(e)}')
        return {'success': False, 'error': str(e)}
