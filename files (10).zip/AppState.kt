package com.icu.platform

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.sin

data class Device(
    val id: String,
    val online: Boolean,
    val rssi: Int? = null,
    val uptimeS: Long? = null,
    val tempC: Double? = null,
    val lastAck: String? = null
)

data class Analysis(
    val rms: Double,
    val peak: Double,
    val trough: Double,
    val dominant: List<Pair<Double, Double>>   // (Hz, amplitude)
)

data class UiState(
    val loggedIn: Boolean = false,
    val busy: Boolean = false,
    val notice: String = "",
    val linkState: String = "Offline",
    val devices: List<Device> = emptyList(),
    val selectedDevice: String? = null,
    val analysis: Analysis? = null,
    val analysisLabel: String = ""
)

/** Demo capture for the Signal tab: 500 Hz + 1.5 kHz + 3 kHz at 8 kHz, 1024 samples. */
object DemoCapture {
    const val SAMPLE_RATE = 8000.0
    const val LENGTH = 1024
    fun samples(): DoubleArray = DoubleArray(LENGTH) { i ->
        val t = i / SAMPLE_RATE
        0.6 * sin(2 * PI * 500 * t) + 0.4 * sin(2 * PI * 1500 * t) + 0.3 * sin(2 * PI * 3000 * t)
    }
}

class AppViewModel : ViewModel() {
    private val http = OkHttpClient()
    private var api: ICUApi? = null
    private var token: String? = null
    private var link: LiveLink? = null

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    fun login(host: String, port: String, user: String, password: String) {
        val base = "http://$host:$port"
        _state.update { it.copy(busy = true, notice = "Signing in...") }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val client = ICUApi(base)
                val t = client.login(user, password)
                api = client
                token = t
                _state.update { it.copy(loggedIn = true, busy = false, notice = "") }
                openLink("ws://$host:$port/ws/android?token=$t")
            } catch (e: ApiException) {
                _state.update { it.copy(busy = false, notice = "Login failed: ${e.message}") }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, notice = "Cannot reach server: ${e.message}") }
            }
        }
    }

    private fun openLink(url: String) {
        link?.close()
        link = LiveLink(
            http, url,
            onJson = ::handleServerMessage,
            onState = { s ->
                _state.update { it.copy(linkState = s) }
                if (s == "Live") refreshDevices()
            }
        ).also { it.open() }
    }

    override fun onCleared() {
        link?.close()
        super.onCleared()
    }

    /** Requests the current device list once the socket is open. */
    fun refreshDevices() {
        link?.send(JSONObject().put("action", "list_devices"))
    }

    private fun handleServerMessage(msg: JSONObject) {
        when (msg.optString("type")) {
            "devices" -> {
                val arr = msg.optJSONArray("devices") ?: JSONArray()
                val list = (0 until arr.length()).map { parseDevice(arr.getJSONObject(it)) }
                _state.update { it.copy(devices = list) }
            }
            "device_update" -> {
                val id = msg.optString("device_id")
                val online = msg.optBoolean("online", false)
                val status = msg.optJSONObject("status") ?: JSONObject()
                _state.update { s ->
                    val existing = s.devices.firstOrNull { it.id == id }
                    val updated = Device(
                        id = id,
                        online = online,
                        rssi = if (status.has("rssi")) status.getInt("rssi") else existing?.rssi,
                        uptimeS = if (status.has("uptime_s")) status.getLong("uptime_s") else existing?.uptimeS,
                        tempC = if (status.has("temp_c")) status.getDouble("temp_c") else existing?.tempC,
                        lastAck = existing?.lastAck
                    )
                    s.copy(devices = s.devices.filter { it.id != id } + updated)
                }
            }
            "ack" -> {
                val id = msg.optString("device_id")
                val cmd = msg.optString("command")
                _state.update { s ->
                    s.copy(devices = s.devices.map { if (it.id == id) it.copy(lastAck = cmd) else it })
                }
            }
            "command_result" -> {
                val ok = msg.optBoolean("ok", false)
                val text = if (ok) "Sent ${msg.optString("command")}" else "Refused: ${msg.optString("error")}"
                _state.update { it.copy(notice = text) }
            }
            "error" -> _state.update { it.copy(notice = msg.optString("error")) }
        }
    }

    private fun parseDevice(o: JSONObject): Device {
        val status = o.optJSONObject("status") ?: JSONObject()
        val ack = o.optJSONObject("lastAck")?.optString("command")
        return Device(
            id = o.optString("id"),
            online = o.optBoolean("online", false),
            rssi = if (status.has("rssi")) status.getInt("rssi") else null,
            uptimeS = if (status.has("uptime_s")) status.getLong("uptime_s") else null,
            tempC = if (status.has("temp_c")) status.getDouble("temp_c") else null,
            lastAck = ack
        )
    }

    fun selectDevice(id: String) {
        _state.update { it.copy(selectedDevice = id) }
    }

    /** Control buttons. Only whitelisted commands reach the server. */
    fun sendCommand(command: String) {
        val id = _state.value.selectedDevice ?: return
        val sent = link?.send(
            JSONObject().put("action", "command").put("device_id", id).put("command", command)
        ) ?: false
        if (!sent) _state.update { it.copy(notice = "Not connected") }
    }

    /** Signal tab: runs the edit pipeline on the demo capture and shows the result. */
    fun analyzeDemo(notchHz: Double?, lowpassHz: Double?, gain: Double) {
        val a = api
        val t = token
        if (a == null || t == null) return
        val ops = JSONArray()
        ops.put(JSONObject().put("type", "gain").put("factor", gain))
        notchHz?.let { ops.put(JSONObject().put("type", "notch").put("frequency", it).put("bandwidth", 100)) }
        lowpassHz?.let { ops.put(JSONObject().put("type", "lowpass").put("cutoff", it)) }

        val samples = JSONArray().apply { DemoCapture.samples().forEach { put(it) } }
        val body = JSONObject()
            .put("samples", samples)
            .put("sample_rate", DemoCapture.SAMPLE_RATE)
            .put("ops", ops)
        val label = buildString {
            append("gain x%.2f".format(gain))
            notchHz?.let { append(", notch %.0f Hz".format(it)) }
            lowpassHz?.let { append(", lowpass %.0f Hz".format(it)) }
        }

        _state.update { it.copy(busy = true, notice = "Analyzing...") }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val res = a.post(t, "/api/v1/signal/edit", body).getJSONObject("analysis")
                val dom = res.getJSONArray("dominant_frequencies")
                val pairs = (0 until dom.length()).map {
                    val d = dom.getJSONObject(it)
                    d.getDouble("frequency_hz") to d.getDouble("amplitude")
                }
                val result = Analysis(
                    rms = res.getDouble("rms"),
                    peak = res.getDouble("peak"),
                    trough = res.getDouble("trough"),
                    dominant = pairs
                )
                _state.update { it.copy(busy = false, notice = "", analysis = result, analysisLabel = label) }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, notice = "Analysis failed: ${e.message}") }
            }
        }
    }

    fun clearNotice() = _state.update { it.copy(notice = "") }
}
