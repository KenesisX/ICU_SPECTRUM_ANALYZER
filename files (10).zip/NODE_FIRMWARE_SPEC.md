# STRIKEBACK ENTERPRISE - Node Firmware Specification

## Overview
Lab nodes (ESP32, Raspberry Pi, Jetson) are remote agents that execute pentesting tools as directed by the central STRIKEBACK ENTERPRISE platform. They enforce scope limits locally and report all actions back for audit compliance.

---

## Architecture

### Node Types

**1. ESP32 (Wireless Specialized)**
- WiFi/BLE scanning and attacks
- Marauder-compatible firmware
- Lightweight, portable
- Deploy in field for WiFi/RF assessment
- ~4MB storage, 520KB RAM

**2. Raspberry Pi 4 (Compute Node)**
- Full Kali/Parrot toolkit
- GPU acceleration available
- Long-running operations (cracking, scanning)
- Stable power supply recommended
- 4-8GB RAM, storage as needed

**3. Jetson Nano/AGX (ML-Enhanced)**
- GPU-accelerated cracking (hashcat)
- Machine learning models for detection
- Vulnerability assessment
- High-performance compute

---

## Node Firmware Components

### 1. Boot Sequence

```
[START]
  ↓
[LOAD CONFIG] - firmware_config.json with:
  - Platform API endpoint
  - API credentials
  - Node ID
  - Capabilities list
  - Scope limits (hardcoded)
  ↓
[INITIALIZE HARDWARE]
  - WiFi/Network (RPi, ESP32)
  - GPIO/Sensors (if applicable)
  - Tool environment
  ↓
[CONNECT TO PLATFORM]
  - Register with platform
  - Receive heartbeat interval
  - Wait for job assignments
  ↓
[MAIN LOOP]
  - Listen for tool execution jobs
  - Execute with scope verification
  - Report results
  - Handle remote stop commands
```

---

## ESP32 Implementation

### MicroPython Node Agent (esp32_agent.py)

```python
import urequests
import json
import utime
import machine
import network
from ubinascii import hexlify

# ============================================================
# CONFIGURATION (loaded from flash)
# ============================================================
CONFIG = {
    "platform_url": "https://platform.strikeback.local/api/v1",
    "api_key": "esp32_api_key_xxxx",
    "node_id": "node_esp32_lab_1",
    "capabilities": ["wifi_scan", "ble_scan", "marauder", "jammer_control"],
    "scope_limits": {
        "allowed_frequencies": [(2400, 2500), (5150, 5850)],  # MHz
        "max_power_dbm": 20,
        "forbidden_targets": []  # MAC prefixes to block
    },
    "heartbeat_interval": 30  # seconds
}

class NodeAgent:
    def __init__(self):
        self.node_id = CONFIG['node_id']
        self.platform_url = CONFIG['platform_url']
        self.api_key = CONFIG['api_key']
        self.running = True
        self.current_job = None
        
    def register_with_platform(self):
        """Register node and capabilities with central platform"""
        payload = {
            "node_id": self.node_id,
            "node_type": "esp32",
            "capabilities": CONFIG['capabilities'],
            "firmware_version": "2.0",
            "status": "ONLINE"
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            response = urequests.post(
                f"{self.platform_url}/nodes/register",
                json=payload,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                print("[*] Registered with platform")
                return True
            else:
                print(f"[!] Registration failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"[!] Connection error: {e}")
            return False
    
    def send_heartbeat(self):
        """Send heartbeat to platform every 30 seconds"""
        payload = {
            "node_id": self.node_id,
            "status": "ONLINE",
            "timestamp": utime.time(),
            "wifi_signal": self.get_wifi_rssi(),
            "cpu_usage": 0,
            "memory_free": machine.mem_free()
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            urequests.post(
                f"{self.platform_url}/nodes/{self.node_id}/heartbeat",
                json=payload,
                headers=headers,
                timeout=5
            )
        except:
            pass  # Heartbeat failure is non-critical
    
    def poll_for_jobs(self):
        """Poll platform for tool execution jobs"""
        headers = {
            "Authorization": f"Bearer {self.api_key}"
        }
        
        try:
            response = urequests.get(
                f"{self.platform_url}/nodes/{self.node_id}/jobs",
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('job'):
                    return data['job']
        except:
            pass
        
        return None
    
    def execute_job(self, job):
        """Execute a tool with scope verification"""
        job_id = job.get('job_id')
        tool = job.get('tool')
        parameters = job.get('parameters', {})
        
        print(f"[*] Executing job {job_id}: {tool}")
        
        # ============================================================
        # SCOPE VERIFICATION (CRITICAL)
        # ============================================================
        if not self.verify_scope(job):
            self.report_job_result(job_id, "BLOCKED", {
                "error": "Scope verification failed",
                "reason": "Target outside authorized limits"
            })
            return
        
        # ============================================================
        # TOOL EXECUTION
        # ============================================================
        result = None
        
        if tool == "wifi_scan":
            result = self.execute_wifi_scan(parameters)
        
        elif tool == "ble_scan":
            result = self.execute_ble_scan(parameters)
        
        elif tool == "marauder_payload":
            result = self.execute_marauder(parameters)
        
        elif tool == "frequency_analysis":
            result = self.execute_frequency_analysis(parameters)
        
        else:
            result = {"error": "Unknown tool"}
        
        # ============================================================
        # REPORT RESULTS BACK TO PLATFORM
        # ============================================================
        status = "SUCCESS" if result and 'error' not in result else "FAILED"
        self.report_job_result(job_id, status, result)
    
    def verify_scope(self, job):
        """Verify job parameters are within scope limits"""
        
        # Check frequency limits
        frequencies = job.get('parameters', {}).get('frequencies', [])
        for freq in frequencies:
            valid = False
            for (min_f, max_f) in CONFIG['scope_limits']['allowed_frequencies']:
                if min_f <= freq <= max_f:
                    valid = True
                    break
            if not valid:
                print(f"[!] Frequency {freq} MHz outside allowed range")
                return False
        
        # Check power limits
        power_dbm = job.get('parameters', {}).get('power_dbm', 20)
        if power_dbm > CONFIG['scope_limits']['max_power_dbm']:
            print(f"[!] Power {power_dbm} dBm exceeds limit")
            return False
        
        # Check forbidden targets
        target_mac = job.get('parameters', {}).get('target_mac')
        if target_mac:
            for forbidden in CONFIG['scope_limits']['forbidden_targets']:
                if target_mac.startswith(forbidden):
                    print(f"[!] Target {target_mac} is forbidden")
                    return False
        
        return True
    
    def execute_wifi_scan(self, params):
        """Execute WiFi network scan"""
        try:
            import ubluetooth  # ESP32 has built-in WiFi/BLE
            
            # Pseudo-code - actual implementation uses ESP-IDF
            networks = []
            
            # Perform scan
            scan_results = scan_wifi_networks()  # Returns list of networks
            
            for ssid, bssid, channel, rssi, auth in scan_results:
                if not self.is_forbidden_target(bssid):
                    networks.append({
                        "ssid": ssid,
                        "bssid": bssid,
                        "channel": channel,
                        "rssi": rssi,
                        "security": auth
                    })
            
            return {
                "networks_found": len(networks),
                "networks": networks,
                "timestamp": utime.time()
            }
        except Exception as e:
            return {"error": str(e)}
    
    def execute_ble_scan(self, params):
        """Execute BLE device scan"""
        try:
            # Pseudo-code - actual implementation uses ESP-IDF
            devices = []
            
            # Perform BLE scan
            ble_results = scan_ble_devices(timeout=params.get('timeout', 10))
            
            for addr, name, rssi in ble_results:
                if not self.is_forbidden_target(addr):
                    devices.append({
                        "address": addr,
                        "name": name,
                        "rssi": rssi
                    })
            
            return {
                "devices_found": len(devices),
                "devices": devices
            }
        except Exception as e:
            return {"error": str(e)}
    
    def execute_marauder(self, params):
        """Execute Marauder attack (limited to authorized targets)"""
        attack_type = params.get('attack_type')
        target = params.get('target')
        
        # Verify target is not forbidden
        if self.is_forbidden_target(target):
            return {"error": "Target is forbidden"}
        
        # Execute Marauder attack
        # Pseudo-code - actual implementation integrates with Marauder firmware
        result = {
            "attack_type": attack_type,
            "target": target,
            "result": "SIMULATED_RESULT",
            "devices_affected": 0
        }
        
        return result
    
    def execute_frequency_analysis(self, params):
        """Analyze radio frequencies within authorized range"""
        freq_min = params.get('freq_min', 2400)
        freq_max = params.get('freq_max', 2500)
        
        # Verify frequency is in allowed range
        for (min_f, max_f) in CONFIG['scope_limits']['allowed_frequencies']:
            if freq_min >= min_f and freq_max <= max_f:
                break
        else:
            return {"error": "Frequency range outside scope"}
        
        # Pseudo frequency analysis
        result = {
            "frequency_range": f"{freq_min}-{freq_max} MHz",
            "signals_detected": 5,
            "signals": [
                {"freq": 2437, "power": -45, "type": "WiFi"},
                {"freq": 2440, "power": -52, "type": "WiFi"}
            ]
        }
        
        return result
    
    def is_forbidden_target(self, target):
        """Check if target (MAC address) is forbidden"""
        for forbidden in CONFIG['scope_limits']['forbidden_targets']:
            if str(target).startswith(forbidden):
                return True
        return False
    
    def report_job_result(self, job_id, status, result):
        """Report job execution result back to platform"""
        payload = {
            "job_id": job_id,
            "status": status,
            "result": result,
            "timestamp": utime.time(),
            "node_id": self.node_id
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            urequests.post(
                f"{self.platform_url}/nodes/{self.node_id}/job-result",
                json=payload,
                headers=headers,
                timeout=10
            )
        except Exception as e:
            print(f"[!] Failed to report result: {e}")
    
    def get_wifi_rssi(self):
        """Get WiFi signal strength"""
        try:
            sta_if = network.WLAN(network.STA_IF)
            if sta_if.isconnected():
                return sta_if.config('rssi')
        except:
            pass
        return -100
    
    def main_loop(self):
        """Main event loop"""
        print("[*] Node agent started")
        
        if not self.register_with_platform():
            print("[!] Failed to register. Retrying...")
            utime.sleep(10)
            return
        
        last_heartbeat = utime.time()
        
        while self.running:
            # Send heartbeat every 30 seconds
            now = utime.time()
            if now - last_heartbeat > CONFIG['heartbeat_interval']:
                self.send_heartbeat()
                last_heartbeat = now
            
            # Poll for jobs
            job = self.poll_for_jobs()
            if job:
                self.execute_job(job)
            
            utime.sleep(1)

# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    agent = NodeAgent()
    agent.main_loop()
```

---

## Raspberry Pi Implementation

### Python Node Agent (rpi_agent.py)

```python
import requests
import json
import time
import subprocess
import os
import signal
from threading import Thread
from typing import Dict, Any

class RPiNodeAgent:
    def __init__(self, config_file='node_config.json'):
        with open(config_file) as f:
            self.config = json.load(f)
        
        self.node_id = self.config['node_id']
        self.platform_url = self.config['platform_url']
        self.api_key = self.config['api_key']
        self.running = True
        self.current_process = None
        
    def register_with_platform(self):
        """Register RPi node with central platform"""
        payload = {
            "node_id": self.node_id,
            "node_type": "raspberry_pi",
            "capabilities": self.config['capabilities'],
            "firmware_version": "2.0",
            "status": "ONLINE"
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.post(
                f"{self.platform_url}/nodes/register",
                json=payload,
                headers=headers,
                timeout=10,
                verify=False  # Use self-signed certs in lab
            )
            
            if response.status_code == 200:
                print("[+] Registered with platform")
                return True
        except Exception as e:
            print(f"[-] Registration failed: {e}")
        
        return False
    
    def poll_for_jobs(self):
        """Poll platform for job assignments"""
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        try:
            response = requests.get(
                f"{self.platform_url}/nodes/{self.node_id}/jobs",
                headers=headers,
                timeout=10,
                verify=False
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('job')
        except:
            pass
        
        return None
    
    def verify_scope(self, job: Dict) -> bool:
        """Verify job parameters are within scope"""
        
        # Check target is in scope
        target = job.get('parameters', {}).get('target')
        if target and not self.is_target_in_scope(target):
            print(f"[!] Target {target} outside scope")
            return False
        
        # Check tool is in allowed list
        tool = job.get('tool')
        if tool not in self.config.get('allowed_tools', []):
            print(f"[!] Tool {tool} not in allowed list")
            return False
        
        return True
    
    def is_target_in_scope(self, target: str) -> bool:
        """Check if target IP is within authorized scope"""
        import ipaddress
        
        authorized_networks = self.config['scope_limits']['authorized_networks']
        
        try:
            target_ip = ipaddress.ip_address(target)
            for network_str in authorized_networks:
                network = ipaddress.ip_network(network_str, strict=False)
                if target_ip in network:
                    return True
        except:
            pass
        
        return False
    
    def execute_job(self, job: Dict):
        """Execute a tool job with scope enforcement"""
        job_id = job.get('job_id')
        tool = job.get('tool')
        parameters = job.get('parameters', {})
        
        print(f"[*] Executing job {job_id}: {tool}")
        
        # Verify scope before execution
        if not self.verify_scope(job):
            self.report_job_result(job_id, "BLOCKED", {
                "error": "Scope verification failed"
            })
            return
        
        # Execute tool
        result = None
        
        if tool == "nmap":
            result = self.execute_nmap(parameters)
        elif tool == "hashcat":
            result = self.execute_hashcat(parameters)
        elif tool == "hydra":
            result = self.execute_hydra(parameters)
        elif tool == "sqlmap":
            result = self.execute_sqlmap(parameters)
        else:
            result = {"error": "Unknown tool"}
        
        # Report back
        status = "SUCCESS" if result and 'error' not in result else "FAILED"
        self.report_job_result(job_id, status, result)
    
    def execute_nmap(self, params: Dict) -> Dict:
        """Execute Nmap scan"""
        target = params.get('target', '')
        scan_type = params.get('scan_type', '-sS')
        ports = params.get('ports', '1-1000')
        
        cmd = f"nmap {scan_type} -p {ports} {target}"
        
        try:
            self.current_process = subprocess.Popen(
                cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            
            stdout, stderr = self.current_process.communicate(timeout=300)
            
            return {
                "tool": "nmap",
                "target": target,
                "status": "COMPLETE",
                "output": stdout.decode('utf-8', errors='ignore'),
                "timestamp": time.time()
            }
        except subprocess.TimeoutExpired:
            self.current_process.kill()
            return {"error": "Scan timeout"}
        except Exception as e:
            return {"error": str(e)}
    
    def execute_hashcat(self, params: Dict) -> Dict:
        """Execute Hashcat cracking"""
        hash_file = params.get('hash_file')
        hash_type = params.get('hash_type', '0')  # MD5
        wordlist = params.get('wordlist', '/usr/share/wordlists/rockyou.txt')
        
        cmd = f"hashcat -m {hash_type} {hash_file} {wordlist}"
        
        try:
            self.current_process = subprocess.Popen(
                cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            
            stdout, stderr = self.current_process.communicate(timeout=3600)
            
            return {
                "tool": "hashcat",
                "hashes_processed": "N/A",
                "output": stdout.decode('utf-8', errors='ignore'),
                "timestamp": time.time()
            }
        except Exception as e:
            return {"error": str(e)}
    
    def execute_hydra(self, params: Dict) -> Dict:
        """Execute Hydra brute force"""
        target = params.get('target')
        service = params.get('service', 'ssh')
        username = params.get('username')
        wordlist = params.get('wordlist', '/usr/share/wordlists/rockyou.txt')
        
        cmd = f"hydra -l {username} -P {wordlist} {target} {service}"
        
        try:
            self.current_process = subprocess.Popen(
                cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            
            stdout, stderr = self.current_process.communicate(timeout=600)
            
            return {
                "tool": "hydra",
                "target": target,
                "output": stdout.decode('utf-8', errors='ignore'),
                "timestamp": time.time()
            }
        except Exception as e:
            return {"error": str(e)}
    
    def execute_sqlmap(self, params: Dict) -> Dict:
        """Execute SQLMap SQL injection testing"""
        url = params.get('url')
        parameter = params.get('parameter')
        
        cmd = f"sqlmap -u '{url}' -p {parameter} --batch"
        
        try:
            self.current_process = subprocess.Popen(
                cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            
            stdout, stderr = self.current_process.communicate(timeout=600)
            
            return {
                "tool": "sqlmap",
                "url": url,
                "vulnerable": "DETECTED" in stdout.decode(),
                "output": stdout.decode('utf-8', errors='ignore'),
                "timestamp": time.time()
            }
        except Exception as e:
            return {"error": str(e)}
    
    def stop_current_job(self):
        """Stop running tool execution"""
        if self.current_process:
            try:
                os.killpg(os.getpgid(self.current_process.pid), signal.SIGTERM)
                self.current_process = None
                print("[*] Job stopped")
            except:
                pass
    
    def report_job_result(self, job_id: str, status: str, result: Dict):
        """Report job result to platform"""
        payload = {
            "job_id": job_id,
            "status": status,
            "result": result,
            "timestamp": time.time(),
            "node_id": self.node_id
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            requests.post(
                f"{self.platform_url}/nodes/{self.node_id}/job-result",
                json=payload,
                headers=headers,
                timeout=10,
                verify=False
            )
            print(f"[+] Reported job {job_id}: {status}")
        except Exception as e:
            print(f"[-] Failed to report result: {e}")
    
    def main_loop(self):
        """Main node event loop"""
        print("[*] RPi Node Agent started")
        
        if not self.register_with_platform():
            print("[-] Failed to register")
            return
        
        last_heartbeat = time.time()
        
        while self.running:
            # Heartbeat every 30 seconds
            now = time.time()
            if now - last_heartbeat > 30:
                self.send_heartbeat()
                last_heartbeat = now
            
            # Poll for jobs
            job = self.poll_for_jobs()
            if job:
                self.execute_job(job)
            
            time.sleep(1)
    
    def send_heartbeat(self):
        """Send heartbeat to platform"""
        payload = {
            "node_id": self.node_id,
            "status": "ONLINE",
            "timestamp": time.time()
        }
        
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        try:
            requests.post(
                f"{self.platform_url}/nodes/{self.node_id}/heartbeat",
                json=payload,
                headers=headers,
                timeout=5,
                verify=False
            )
        except:
            pass

# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    agent = RPiNodeAgent('node_config.json')
    agent.main_loop()
```

---

## Node Configuration File

### node_config.json (for RPi/ESP32)

```json
{
  "node_id": "node_rpi_lab_1",
  "node_type": "raspberry_pi",
  "platform_url": "https://platform.strikeback.local/api/v1",
  "api_key": "rpi_node_key_xxxx",
  "heartbeat_interval": 30,
  
  "capabilities": [
    "nmap",
    "hashcat",
    "hydra",
    "sqlmap",
    "volatility",
    "wireshark",
    "metasploit"
  ],
  
  "allowed_tools": [
    "nmap",
    "hashcat",
    "hydra",
    "sqlmap"
  ],
  
  "scope_limits": {
    "authorized_networks": [
      "192.168.1.0/24",
      "10.20.30.0/24"
    ],
    "forbidden_networks": [],
    "max_concurrent_jobs": 1,
    "max_tool_timeout": 3600
  }
}
```

---

## Deployment Instructions

### ESP32 Deployment

1. Flash MicroPython to ESP32
2. Copy `esp32_agent.py` to device
3. Create `firmware_config.json` with platform URL and API key
4. Boot device - agent auto-registers
5. Monitor via platform dashboard

### Raspberry Pi Deployment

```bash
# On RPi
pip install requests

# Copy agent
cp rpi_agent.py /opt/strikeback/
cp node_config.json /opt/strikeback/

# Create systemd service
sudo tee /etc/systemd/system/strikeback-node.service << EOF
[Unit]
Description=Strikeback Lab Node Agent
After=network.target

[Service]
Type=simple
User=strikeback
WorkingDirectory=/opt/strikeback
ExecStart=/usr/bin/python3 rpi_agent.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start
sudo systemctl enable strikeback-node
sudo systemctl start strikeback-node

# Monitor logs
sudo journalctl -u strikeback-node -f
```

---

## Security Features

1. **Scope Hardcoded** - Firmware cannot be modified to exceed scope
2. **API Token Validation** - Every request verified
3. **Remote Kill Switch** - Platform can stop any tool < 1 second
4. **Audit Logging** - All executions logged on platform
5. **Timeout Protection** - Tools auto-stop after max_tool_timeout
6. **Resource Limits** - CPU/memory/network constrained

---

## Testing Scope Enforcement

Test that scope violations are properly blocked:

```bash
# This should SUCCEED (in scope)
curl -X POST http://platform/api/v1/tools/execute \
  -d '{"target": "192.168.1.50", "tool": "nmap"}'

# This should FAIL (out of scope)
curl -X POST http://platform/api/v1/tools/execute \
  -d '{"target": "192.168.2.50", "tool": "nmap"}'
# Expected response: {"error": "SCOPE_VIOLATION", "action": "BLOCKED"}
```

---

## Monitoring Node Health

Platform dashboard shows:
- Node online/offline status
- Last heartbeat time
- Tool execution history
- Failed jobs and reasons
- Resource usage (CPU, memory, network)

Nodes that miss 3 consecutive heartbeats (90 seconds) are marked offline.

---

This firmware architecture ensures nodes can only execute within authorized scope, with all actions auditable and revocable from the central platform.
