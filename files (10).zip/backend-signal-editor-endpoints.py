#!/usr/bin/env python3
# ================================================================
# FASTAPI ENDPOINTS: SIGNAL DECOMPOSITION & WAVEFORM EDITOR
# Module 10 Enhancement - Break down, analyze, edit signals
# ================================================================

from fastapi import APIRouter, HTTPException, UploadFile, File, BackgroundTasks
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import numpy as np
import io
import json
import logging

# Import signal processing engines
from signal_decomposition_editor import (
    SignalDecomposer,
    InteractiveWaveformEditor,
    SignalCaptureReplay,
    decompose_signal,
)

logger = logging.getLogger(__name__)

# ================================================================
# PYDANTIC MODELS
# ================================================================

class SignalData(BaseModel):
    """Raw signal data"""
    samples: List[float]
    sample_rate: float = 1e6
    signal_id: Optional[str] = None
    metadata: Optional[Dict] = None

class DecompositionRequest(BaseModel):
    """Request for signal decomposition"""
    signal: List[float]
    analysis_types: List[str] = ['frequency', 'time_frequency', 'envelope', 'peaks']
    sample_rate: float = 1e6

class WaveformEditRequest(BaseModel):
    """Request for waveform editing"""
    signal: List[float]
    edits: List[Dict[str, Any]]
    sample_rate: float = 1e6

class PeakEdit(BaseModel):
    """Edit a peak/crest"""
    index: int
    new_value: float
    smoothing_range: int = 5

class FrequencyShiftRequest(BaseModel):
    """Shift frequency components"""
    signal: List[float]
    frequency_shift: float
    sample_rate: float = 1e6

class WavelengthAdjustRequest(BaseModel):
    """Adjust wavelength (stretch/compress)"""
    signal: List[float]
    stretch_factor: float
    sample_rate: float = 1e6

class PhaseShiftRequest(BaseModel):
    """Adjust phase"""
    signal: List[float]
    phase_shift_radians: float
    sample_rate: float = 1e6

class HarmonicFilterRequest(BaseModel):
    """Remove or enhance specific harmonic"""
    signal: List[float]
    target_frequency: float
    bandwidth: float = 10000
    action: str = 'remove'  # 'remove' or 'enhance'
    sample_rate: float = 1e6

class SignalCaptureRequest(BaseModel):
    """Capture and store signal"""
    signal: List[float]
    signal_id: str
    metadata: Optional[Dict] = None
    sample_rate: float = 1e6

class SignalReplayRequest(BaseModel):
    """Replay captured signal with modifications"""
    signal_id: str
    repetitions: int = 1
    modifications: Optional[List[Dict[str, Any]]] = None
    sample_rate: float = 1e6

# ================================================================
# ROUTER SETUP
# ================================================================

router = APIRouter(
    prefix='/api/v1/sdr/signal',
    tags=['Signal Processing - Decomposition & Editing']
)

# Global instances
decomposer = None
editor = None
capture_replay = None

def initialize_engines(sample_rate: float = 1e6):
    """Initialize signal processing engines"""
    global decomposer, editor, capture_replay
    decomposer = SignalDecomposer(sample_rate)
    editor = InteractiveWaveformEditor(sample_rate)
    capture_replay = SignalCaptureReplay(sample_rate)
    logger.info(f'Signal processing engines initialized at {sample_rate/1e6:.1f} MS/s')

# ================================================================
# SIGNAL DECOMPOSITION ENDPOINTS
# ================================================================

@router.post('/decompose')
async def decompose_signal_endpoint(req: DecompositionRequest) -> Dict:
    """
    Decompose signal into multiple domains:
    - Frequency domain (FFT)
    - Time-frequency domain (STFT)
    - Wavelet domain (CWT)
    - Envelope extraction
    - Peak/trough detection
    
    **Example:** `POST /api/v1/sdr/signal/decompose`
    ```json
    {
      "signal": [0.1, 0.2, 0.15, ...],
      "analysis_types": ["frequency", "time_frequency", "envelope", "peaks"],
      "sample_rate": 1000000
    }
    ```
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if decomposer is None:
            initialize_engines(req.sample_rate)
        
        results = await decompose_signal(signal_data, req.analysis_types, req.sample_rate)
        
        return {
            'status': 'success',
            'signal_length': len(signal_data),
            'analysis': results,
        }
    
    except Exception as e:
        logger.error(f'Decomposition error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/frequency-domain')
async def analyze_frequency_domain(req: SignalData) -> Dict:
    """
    Analyze signal in frequency domain (FFT)
    Returns magnitude spectrum, phase spectrum, dominant frequencies
    """
    
    try:
        signal_data = np.array(req.samples, dtype=np.float32)
        
        if decomposer is None:
            initialize_engines(req.sample_rate)
        
        result = decomposer.analyze_frequency_domain(signal_data)
        
        return {
            'status': 'success',
            'analysis': result,
        }
    
    except Exception as e:
        logger.error(f'Frequency domain analysis error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/time-frequency')
async def analyze_time_frequency(
    req: SignalData,
    window_size: int = 256,
    overlap: float = 0.75
) -> Dict:
    """
    Analyze signal in time-frequency domain (STFT)
    Returns spectrogram: time vs frequency vs magnitude
    """
    
    try:
        signal_data = np.array(req.samples, dtype=np.float32)
        
        if decomposer is None:
            initialize_engines(req.sample_rate)
        
        result = decomposer.analyze_time_frequency_domain(signal_data, window_size, overlap)
        
        return {
            'status': 'success',
            'analysis': result,
        }
    
    except Exception as e:
        logger.error(f'Time-frequency analysis error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/wavelet')
async def analyze_wavelet(
    req: SignalData,
    wavelet: str = 'morlet'
) -> Dict:
    """
    Analyze signal using wavelet transform (CWT)
    Better time-frequency localization than STFT
    """
    
    try:
        signal_data = np.array(req.samples, dtype=np.float32)
        
        if decomposer is None:
            initialize_engines(req.sample_rate)
        
        result = decomposer.analyze_wavelet_domain(signal_data, wavelet)
        
        return {
            'status': 'success',
            'analysis': result,
        }
    
    except Exception as e:
        logger.error(f'Wavelet analysis error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/envelope')
async def extract_envelope(req: SignalData) -> Dict:
    """
    Extract amplitude envelope using Hilbert transform
    Returns: time, envelope, instantaneous phase, instantaneous frequency
    """
    
    try:
        signal_data = np.array(req.samples, dtype=np.float32)
        
        if decomposer is None:
            initialize_engines(req.sample_rate)
        
        result = decomposer.extract_envelope(signal_data)
        
        return {
            'status': 'success',
            'analysis': result,
        }
    
    except Exception as e:
        logger.error(f'Envelope extraction error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/peaks-troughs')
async def detect_peaks_and_troughs(
    req: SignalData,
    prominence: float = 0.1
) -> Dict:
    """
    Detect peaks (crests) and troughs in signal
    Returns: indices, times, values for both peaks and troughs
    """
    
    try:
        signal_data = np.array(req.samples, dtype=np.float32)
        
        if decomposer is None:
            initialize_engines(req.sample_rate)
        
        result = decomposer.detect_peaks_and_troughs(signal_data, prominence)
        
        return {
            'status': 'success',
            'analysis': result,
        }
    
    except Exception as e:
        logger.error(f'Peak detection error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

# ================================================================
# WAVEFORM EDITING ENDPOINTS
# ================================================================

@router.post('/edit/peak')
async def edit_peak(req: WaveformEditRequest) -> Dict:
    """
    Drag a peak to a new amplitude value
    Smoothly interpolate to preserve signal continuity
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        for edit in req.edits:
            if edit.get('type') == 'peak':
                signal_data = editor.edit_peak(
                    signal_data,
                    edit['index'],
                    edit['new_value'],
                    edit.get('smoothing_range', 5)
                )
        
        return {
            'status': 'success',
            'edited_signal': signal_data.tolist(),
        }
    
    except Exception as e:
        logger.error(f'Peak edit error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/edit/frequency-shift')
async def edit_frequency_shift(req: FrequencyShiftRequest) -> Dict:
    """
    Shift all frequency components by frequency_shift
    Useful for changing carrier frequency
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        edited = editor.shift_frequency(signal_data, req.frequency_shift)
        
        return {
            'status': 'success',
            'edited_signal': edited.tolist() if not np.iscomplexobj(edited) else np.abs(edited).tolist(),
            'frequency_shift': req.frequency_shift,
        }
    
    except Exception as e:
        logger.error(f'Frequency shift error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/edit/wavelength')
async def edit_wavelength(req: WavelengthAdjustRequest) -> Dict:
    """
    Stretch or compress wavelength (change period)
    stretch_factor > 1 = longer wavelength (lower frequency)
    stretch_factor < 1 = shorter wavelength (higher frequency)
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        edited = editor.adjust_wavelength(signal_data, req.stretch_factor)
        
        return {
            'status': 'success',
            'edited_signal': edited.tolist(),
            'stretch_factor': req.stretch_factor,
        }
    
    except Exception as e:
        logger.error(f'Wavelength adjustment error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/edit/phase')
async def edit_phase(req: PhaseShiftRequest) -> Dict:
    """
    Rotate phase of signal
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        edited = editor.adjust_phase(signal_data, req.phase_shift_radians)
        
        return {
            'status': 'success',
            'edited_signal': edited.tolist() if not np.iscomplexobj(edited) else np.abs(edited).tolist(),
            'phase_shift_radians': req.phase_shift_radians,
            'phase_shift_degrees': float(np.degrees(req.phase_shift_radians)),
        }
    
    except Exception as e:
        logger.error(f'Phase shift error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/edit/remove-harmonic')
async def remove_harmonic(req: HarmonicFilterRequest) -> Dict:
    """
    Remove specific frequency component (harmonic) using notch filter
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        edited = editor.remove_harmonic(
            signal_data,
            req.target_frequency,
            req.bandwidth
        )
        
        return {
            'status': 'success',
            'edited_signal': edited.tolist(),
            'removed_frequency': req.target_frequency,
        }
    
    except Exception as e:
        logger.error(f'Harmonic removal error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/edit/enhance-harmonic')
async def enhance_harmonic(req: HarmonicFilterRequest) -> Dict:
    """
    Enhance specific frequency component using bandpass filter
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        edited = editor.enhance_harmonic(
            signal_data,
            req.target_frequency,
            req.bandwidth
        )
        
        return {
            'status': 'success',
            'edited_signal': edited.tolist(),
            'enhanced_frequency': req.target_frequency,
        }
    
    except Exception as e:
        logger.error(f'Harmonic enhancement error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/edit/batch')
async def apply_edits_batch(req: WaveformEditRequest) -> Dict:
    """
    Apply multiple edits sequentially to signal
    Each edit modifies the result of the previous one
    
    **Edit Types:**
    - `peak`: Modify peak amplitude
    - `trough`: Modify trough amplitude
    - `frequency_shift`: Shift frequency components
    - `wavelength`: Stretch/compress wavelength
    - `phase_shift`: Rotate phase
    - `remove_harmonic`: Remove frequency component
    - `enhance_harmonic`: Enhance frequency component
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if editor is None:
            initialize_engines(req.sample_rate)
        
        edited = editor.apply_edits_batch(signal_data, req.edits)
        
        return {
            'status': 'success',
            'edited_signal': edited.tolist() if not np.iscomplexobj(edited) else np.abs(edited).tolist(),
            'num_edits_applied': len(req.edits),
        }
    
    except Exception as e:
        logger.error(f'Batch edits error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

# ================================================================
# SIGNAL CAPTURE & REPLAY ENDPOINTS
# ================================================================

@router.post('/capture')
async def capture_signal(req: SignalCaptureRequest) -> Dict:
    """
    Capture and store signal for later replay
    """
    
    try:
        signal_data = np.array(req.signal, dtype=np.float32)
        
        if capture_replay is None:
            initialize_engines(req.sample_rate)
        
        result = capture_replay.capture_signal(signal_data, req.signal_id, req.metadata)
        
        return {
            'status': 'success',
            'capture_result': result,
        }
    
    except Exception as e:
        logger.error(f'Signal capture error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/replay')
async def replay_signal(req: SignalReplayRequest) -> Dict:
    """
    Replay captured signal with optional modifications
    """
    
    try:
        if capture_replay is None:
            initialize_engines()
        
        replayed = capture_replay.replay_signal(
            req.signal_id,
            req.repetitions,
            req.modifications
        )
        
        return {
            'status': 'success',
            'replayed_signal': replayed.tolist() if not np.iscomplexobj(replayed) else np.abs(replayed).tolist(),
            'num_repetitions': req.repetitions,
            'num_samples': len(replayed),
        }
    
    except Exception as e:
        logger.error(f'Signal replay error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.get('/captured')
async def list_captured_signals() -> Dict:
    """
    List all captured signals
    """
    
    try:
        if capture_replay is None:
            return {'status': 'success', 'signals': []}
        
        signals = capture_replay.list_captured_signals()
        
        return {
            'status': 'success',
            'signals': signals,
            'count': len(signals),
        }
    
    except Exception as e:
        logger.error(f'List captured signals error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

# ================================================================
# EXPORT ENDPOINTS
# ================================================================

@router.post('/export/wav')
async def export_wav(req: SignalData) -> Dict:
    """
    Export signal as WAV file
    """
    
    try:
        signal_data = np.array(req.samples, dtype=np.float32)
        
        # Normalize
        max_val = np.max(np.abs(signal_data))
        if max_val > 0:
            signal_data = signal_data / max_val * 0.95
        
        # Quantize to 16-bit
        signal_int = np.int16(signal_data * 32767)
        
        # Create WAV bytes
        import wave
        import io
        
        wav_buffer = io.BytesIO()
        with wave.open(wav_buffer, 'wb') as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)
            wav_file.setframerate(int(req.sample_rate))
            wav_file.writeframes(signal_int.tobytes())
        
        return {
            'status': 'success',
            'format': 'wav',
            'sample_rate': req.sample_rate,
            'num_samples': len(signal_data),
        }
    
    except Exception as e:
        logger.error(f'WAV export error: {str(e)}')
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/export/json')
async def export_json(req: SignalData) -> Dict:
    """
    Export signal as JSON
    """
    
    return {
        'status': 'success',
        'format': 'json',
        'sample_rate': req.sample_rate,
        'num_samples': len(req.samples),
        'data': req.samples,
    }

# ================================================================
# HEALTH CHECK
# ================================================================

@router.get('/health')
async def health() -> Dict:
    """Check signal processing backend health"""
    return {
        'status': 'healthy',
        'service': 'Signal Decomposition & Waveform Editor',
        'engines_initialized': decomposer is not None,
    }

# Initialize engines on startup
initialize_engines()

logger.info('Signal decomposition and waveform editor endpoints loaded')
