package com.icu.platform

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ICURoot()
                }
            }
        }
    }
}

@Composable
fun ICURoot(vm: AppViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    if (!state.loggedIn) {
        LoginScreen(vm, state)
    } else {
        Dashboard(vm, state)
    }
}

@Composable
fun LoginScreen(vm: AppViewModel, state: UiState) {
    var host by remember { mutableStateOf("192.168.1.100") }
    var port by remember { mutableStateOf("5000") }
    var user by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ICU", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(host, { host = it }, label = { Text("Server host") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it }, label = { Text("Port") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Password") },
            modifier = Modifier.fillMaxWidth())
        Button(
            onClick = { vm.login(host.trim(), port.trim(), user.trim(), password) },
            enabled = !state.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Sign in") }
        if (state.busy) CircularProgressIndicator()
        if (state.notice.isNotEmpty()) Text(state.notice)
    }
}

@Composable
fun Dashboard(vm: AppViewModel, state: UiState) {
    var tab by remember { mutableStateOf(0) }
    val titles = listOf("Sensors", "Control", "Signal")

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Link: ${state.linkState}", fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { vm.refreshDevices() }) { Text("Refresh") }
        }
        TabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        if (state.notice.isNotEmpty()) {
            Text(state.notice, modifier = Modifier.padding(16.dp).clickable { vm.clearNotice() })
        }
        when (tab) {
            0 -> SensorsView(vm, state)
            1 -> ControlView(vm, state)
            else -> SignalView(vm, state)
        }
    }
}

@Composable
fun SensorsView(vm: AppViewModel, state: UiState) {
    if (state.devices.isEmpty()) {
        Text("No devices yet. Power on an ESP32 node with the right device token.",
            modifier = Modifier.padding(16.dp))
        return
    }
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(state.devices, key = { it.id }) { d ->
            Card(modifier = Modifier.fillMaxWidth().clickable { vm.selectDevice(d.id) }) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(d.id, fontWeight = FontWeight.Bold)
                    Text(if (d.online) "Online" else "Offline")
                    Text("RSSI: ${d.rssi?.let { "$it dBm" } ?: "-"}")
                    Text("Uptime: ${d.uptimeS?.let { "$it s" } ?: "-"}")
                    Text("Temp: ${d.tempC?.let { "%.1f °C".format(it) } ?: "-"}")
                    Text("Last ack: ${d.lastAck ?: "-"}")
                    if (state.selectedDevice == d.id) Text("Selected", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ControlView(vm: AppViewModel, state: UiState) {
    val selected = state.devices.firstOrNull { it.id == state.selectedDevice }
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (selected == null) {
            Text("Select a device on the Sensors tab first.")
            return@Column
        }
        Text("Device: ${selected.id}", fontWeight = FontWeight.Bold)
        val enabled = selected.online
        Button(onClick = { vm.sendCommand("led_on") }, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("LED on") }
        Button(onClick = { vm.sendCommand("led_off") }, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("LED off") }
        Button(onClick = { vm.sendCommand("reboot") }, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("Reboot device") }
        if (!enabled) Text("Device is offline; commands are disabled.")
    }
}

@Composable
fun SignalView(vm: AppViewModel, state: UiState) {
    var gain by remember { mutableFloatStateOf(1f) }
    var notch by remember { mutableStateOf("") }
    var lowpass by remember { mutableStateOf("") }

    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Demo capture: 500 Hz + 1.5 kHz + 3 kHz, 8 kHz sample rate, 1024 samples.")
            Text("Live SDR capture is not wired up yet, so this runs on a generated signal.")
        }
        item {
            Text("Gain: %.2f".format(gain))
            Slider(value = gain, onValueChange = { gain = it }, valueRange = 0f..2f)
        }
        item {
            OutlinedTextField(notch, { notch = it }, label = { Text("Notch Hz (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(lowpass, { lowpass = it }, label = { Text("Lowpass cutoff Hz (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        }
        item {
            Button(
                onClick = {
                    vm.analyzeDemo(
                        notchHz = notch.toDoubleOrNull()?.takeIf { it > 0 },
                        lowpassHz = lowpass.toDoubleOrNull()?.takeIf { it > 0 },
                        gain = gain.toDouble()
                    )
                },
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Apply and analyze") }
        }
        state.analysis?.let { a ->
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Result: ${state.analysisLabel}", fontWeight = FontWeight.Bold)
                        Text("RMS: %.4f".format(a.rms))
                        Text("Peak: %.4f   Trough: %.4f".format(a.peak, a.trough))
                        Spacer(Modifier.height(8.dp))
                        Text("Dominant frequencies:", fontWeight = FontWeight.Bold)
                        a.dominant.forEach { (hz, amp) ->
                            Text("%.1f Hz   amplitude %.3f".format(hz, amp))
                        }
                    }
                }
            }
        }
    }
}
