// ================================================================
// MODULE 10 ENHANCEMENT: ADVANCED AMC & WAVEFORM SYNTHESIS ROUTES
// Automatic Modulation Classification + OFDM/OTFS generation
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// ADVANCED MODULATION CLASSIFICATION (AMC)
// ================================================================

// POST /api/v1/sdr/amc/classify - Classify modulation from raw IQ
router.post('/amc/classify', authMiddleware, async (req, res) => {
  try {
    const { iq_data, frequency, duration } = req.body;

    if (!iq_data || !Array.isArray(iq_data)) {
      return res.status(400).json({ error: 'Invalid IQ data format' });
    }

    // Send to Python backend for TensorFlow classification
    const response = await fetch('http://strikeback-backend:8000/api/v1/amc/classify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        iq_data,
        frequency,
        duration,
      }),
    });

    const classification = await response.json();

    // Store classification result
    const dbResult = await db.query(
      `INSERT INTO amc_classifications 
       (iq_data_hash, primary_modulation, confidence, all_predictions, metadata)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        require('crypto').createHash('md5').update(JSON.stringify(iq_data)).digest('hex'),
        classification.modulation,
        classification.confidence,
        JSON.stringify(classification.all_predictions),
        JSON.stringify({
          frequency,
          duration,
          sample_count: iq_data.length,
          timestamp: new Date(),
        }),
      ],
    );

    logger.info('AMC classification stored', {
      modulation: classification.modulation,
      confidence: classification.confidence,
    });

    res.json(dbResult.rows[0]);
  } catch (error) {
    logger.error('AMC classification error', { error: error.message });
    res.status(500).json({ error: 'Classification failed' });
  }
});

// GET /api/v1/sdr/amc/history - View classification history
router.get('/amc/history', authMiddleware, async (req, res) => {
  try {
    const { limit = 100, modulation } = req.query;

    let query = 'SELECT * FROM amc_classifications WHERE 1=1';
    const params = [];

    if (modulation) {
      query += ' AND primary_modulation = $1';
      params.push(modulation);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get AMC history error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/v1/sdr/amc/statistics - Modulation distribution stats
router.get('/amc/statistics', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT 
        primary_modulation,
        COUNT(*) as count,
        AVG(confidence) as avg_confidence,
        MAX(confidence) as max_confidence,
        MIN(confidence) as min_confidence
      FROM amc_classifications
      WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY primary_modulation
      ORDER BY count DESC
    `);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get AMC statistics error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// DIFFERENTIABLE WAVEFORM SYNTHESIS
// ================================================================

// POST /api/v1/sdr/waveform/generate - Generate OFDM/OTFS waveform
router.post('/waveform/generate', authMiddleware, async (req, res) => {
  try {
    const {
      modulation, // BPSK, QPSK, 16QAM, 64QAM
      num_symbols,
      waveform_type, // ofdm or otfs
      num_subcarriers = 64,
      num_ofdm_symbols = 14,
      sample_rate = 1e6,
      carrier_freq = 2.4e9,
    } = req.body;

    if (!modulation || !num_symbols) {
      return res.status(400).json({ error: 'Missing modulation or num_symbols' });
    }

    // Send to Python backend for generation
    const response = await fetch('http://strikeback-backend:8000/api/v1/waveform/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        modulation,
        num_symbols,
        waveform_type: waveform_type || 'ofdm',
        num_subcarriers,
        num_ofdm_symbols,
        sample_rate,
        carrier_freq,
      }),
    });

    const waveform = await response.json();

    // Store generated waveform metadata
    const dbResult = await db.query(
      `INSERT INTO generated_waveforms 
       (modulation, waveform_type, num_symbols, num_subcarriers, num_samples, 
        peak_power, parameters, generated_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        modulation,
        waveform_type || 'ofdm',
        num_symbols,
        num_subcarriers,
        waveform.num_samples,
        waveform.peak_power,
        JSON.stringify({
          sample_rate,
          carrier_freq,
          num_ofdm_symbols,
        }),
        req.user.id,
      ],
    );

    logger.info('Waveform generated', {
      modulation,
      waveformType: waveform_type,
      numSymbols: num_symbols,
    });

    res.status(201).json({
      waveform_id: dbResult.rows[0].id,
      ...waveform,
    });
  } catch (error) {
    logger.error('Waveform generation error', { error: error.message });
    res.status(500).json({ error: 'Waveform generation failed' });
  }
});

// POST /api/v1/sdr/waveform/optimize - Optimize waveform for channel
router.post('/waveform/optimize', authMiddleware, async (req, res) => {
  try {
    const {
      initial_symbols,
      channel_response,
      num_iterations = 100,
      learning_rate = 0.01,
    } = req.body;

    if (!initial_symbols || !channel_response) {
      return res.status(400).json({ error: 'Missing symbols or channel response' });
    }

    // Send to Python backend for optimization
    const response = await fetch('http://strikeback-backend:8000/api/v1/waveform/optimize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        initial_symbols,
        channel_response,
        num_iterations,
        learning_rate,
      }),
    });

    const optimized = await response.json();

    // Store optimization result
    const dbResult = await db.query(
      `INSERT INTO waveform_optimizations 
       (initial_symbol_count, optimized_symbol_count, final_loss, 
        iterations, learning_rate, optimization_params)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        initial_symbols.length,
        optimized.num_symbols,
        optimized.final_loss,
        num_iterations,
        learning_rate,
        JSON.stringify({
          channel_response_len: channel_response.length,
          timestamp: new Date(),
        }),
      ],
    );

    logger.info('Waveform optimization complete', { finalLoss: optimized.final_loss });

    res.status(201).json({
      optimization_id: dbResult.rows[0].id,
      ...optimized,
    });
  } catch (error) {
    logger.error('Waveform optimization error', { error: error.message });
    res.status(500).json({ error: 'Optimization failed' });
  }
});

// POST /api/v1/sdr/waveform/pulse-shape - Apply pulse shaping
router.post('/waveform/pulse-shape', authMiddleware, async (req, res) => {
  try {
    const {
      waveform_id,
      filter_type = 'rrc', // rrc, blackman, hamming
      rolloff = 0.35,
    } = req.body;

    // Send to Python backend
    const response = await fetch('http://strikeback-backend:8000/api/v1/waveform/pulse-shape', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        waveform_id,
        filter_type,
        rolloff,
      }),
    });

    const shaped = await response.json();

    // Store pulse-shaped waveform
    const dbResult = await db.query(
      `INSERT INTO pulse_shaped_waveforms 
       (base_waveform_id, filter_type, rolloff, num_samples, peak_power)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [waveform_id, filter_type, rolloff, shaped.num_samples, shaped.peak_power],
    );

    logger.info('Pulse shaping applied', { filterType: filter_type });

    res.status(201).json(dbResult.rows[0]);
  } catch (error) {
    logger.error('Pulse shaping error', { error: error.message });
    res.status(500).json({ error: 'Pulse shaping failed' });
  }
});

// ================================================================
// UPCONVERSION TO RF
// ================================================================

// POST /api/v1/sdr/waveform/upconvert - Upconvert to RF carrier
router.post('/waveform/upconvert', authMiddleware, async (req, res) => {
  try {
    const {
      waveform_id,
      carrier_freq,
      sample_rate = 1e6,
    } = req.body;

    if (!carrier_freq) {
      return res.status(400).json({ error: 'Carrier frequency required' });
    }

    // Get baseband waveform
    const wfResult = await db.query(
      'SELECT * FROM generated_waveforms WHERE id = $1',
      [waveform_id],
    );

    if (wfResult.rows.length === 0) {
      return res.status(404).json({ error: 'Waveform not found' });
    }

    // Send to Python backend for upconversion
    const response = await fetch('http://strikeback-backend:8000/api/v1/waveform/upconvert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        waveform_id,
        carrier_freq,
        sample_rate,
      }),
    });

    const rf_signal = await response.json();

    // Store RF waveform metadata
    const dbResult = await db.query(
      `INSERT INTO rf_waveforms 
       (base_waveform_id, carrier_freq, sample_rate, num_samples, peak_power)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        waveform_id,
        carrier_freq,
        sample_rate,
        rf_signal.num_samples,
        rf_signal.peak_power,
      ],
    );

    logger.info('Upconversion complete', {
      carrierFreq: carrier_freq,
      sampleRate: sample_rate,
    });

    res.status(201).json({
      rf_waveform_id: dbResult.rows[0].id,
      ...rf_signal,
    });
  } catch (error) {
    logger.error('Upconversion error', { error: error.message });
    res.status(500).json({ error: 'Upconversion failed' });
  }
});

// ================================================================
// WAVEFORM EXPORT FOR TRANSMISSION
// ================================================================

// GET /api/v1/sdr/waveform/:waveform_id/export - Export waveform for transmission
router.get('/waveform/:waveform_id/export', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM generated_waveforms WHERE id = $1',
      [req.params.waveform_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Waveform not found' });
    }

    const waveform = result.rows[0];

    // Return waveform metadata and export options
    res.json({
      waveform_id: waveform.id,
      modulation: waveform.modulation,
      waveform_type: waveform.waveform_type,
      num_symbols: waveform.num_symbols,
      num_samples: waveform.num_samples,
      peak_power: waveform.peak_power,
      parameters: waveform.parameters,
      formats_available: [
        'iq_binary',      // Raw IQ data (float32)
        'iq_json',        // IQ as JSON array
        'wav_file',       // WAV audio format
        'usrp_stream',    // USRP-compatible streaming
        'hackrf_stream',  // HackRF-compatible streaming
        'rtlsdr_file',    // RTL-SDR file format
      ],
      export_urls: {
        iq_binary: `/api/v1/sdr/waveform/${req.params.waveform_id}/export/iq_binary`,
        iq_json: `/api/v1/sdr/waveform/${req.params.waveform_id}/export/iq_json`,
        wav_file: `/api/v1/sdr/waveform/${req.params.waveform_id}/export/wav`,
      },
    });
  } catch (error) {
    logger.error('Get waveform export error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// CHANNEL MODEL APPLICATION
// ================================================================

// POST /api/v1/sdr/waveform/apply-channel - Simulate waveform through channel
router.post('/waveform/apply-channel', authMiddleware, async (req, res) => {
  try {
    const {
      waveform_id,
      channel_model, // 'awgn', 'rayleigh', 'rician', 'multipath'
      snr_db = 20,
      doppler_freq = 0,
    } = req.body;

    // Send to Python backend
    const response = await fetch('http://strikeback-backend:8000/api/v1/waveform/apply-channel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        waveform_id,
        channel_model,
        snr_db,
        doppler_freq,
      }),
    });

    const channeled = await response.json();

    // Store channel simulation
    const dbResult = await db.query(
      `INSERT INTO channel_simulations 
       (base_waveform_id, channel_model, snr_db, doppler_freq, output_samples)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [waveform_id, channel_model, snr_db, doppler_freq, channeled.num_samples],
    );

    logger.info('Channel simulation complete', {
      channelModel: channel_model,
      snrDb: snr_db,
    });

    res.status(201).json({
      simulation_id: dbResult.rows[0].id,
      ...channeled,
    });
  } catch (error) {
    logger.error('Channel simulation error', { error: error.message });
    res.status(500).json({ error: 'Simulation failed' });
  }
});

module.exports = router;
