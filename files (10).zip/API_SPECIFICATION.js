// ================================================================
// STRIKEBACK 2.0 API GATEWAY — Node.js/Express Specification
// ================================================================
// This is a complete REST + WebSocket API specification
// for the unified command center backend

// ================================================================
// STACK
// ================================================================
// Node.js 18+
// Express.js 4.18+
// Socket.IO 4.5+
// JWT (jsonwebtoken)
// PostgreSQL (node-postgres)
// Redis (ioredis)
// Winston (logging)
// Joi (validation)

// ================================================================
// FILE STRUCTURE
// ================================================================
/*
api/
├── src/
│   ├── app.js                    # Express app initialization
│   ├── server.js                 # HTTP + WebSocket server startup
│   ├── config/
│   │   ├── database.js           # PostgreSQL connection pool
│   │   ├── redis.js              # Redis client
│   │   └── environment.js        # Config from .env
│   ├── middleware/
│   │   ├── auth.js               # JWT verification
│   │   ├── errorHandler.js       # Global error handling
│   │   ├── logging.js            # Request/response logging
│   │   └── validation.js         # Request validation with Joi
│   ├── routes/
│   │   ├── auth.js               # POST /auth/* routes
│   │   ├── engagements.js        # CRUD for engagements
│   │   ├── operations.js         # CRUD for operations
│   │   ├── osint.js              # OSINT integrations
│   │   ├── sdr.js                # SDR control & captures
│   │   ├── network.js            # Network scanning & topology
│   │   ├── findings.js           # Findings management
│   │   ├── reports.js            # Report generation
│   │   ├── hardware.js           # Hardware device management
│   │   ├── scripting.js          # Script execution
│   │   ├── compliance.js         # Compliance rules engine
│   │   ├── admin.js              # Admin operations
│   │   └── health.js             # System health endpoint
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── osintController.js
│   │   ├── sdrController.js
│   │   ├── networkController.js
│   │   ├── reportController.js
│   │   └── [... more controllers]
│   ├── services/
│   │   ├── osintService.js       # Shodan, VirusTotal API calls
│   │   ├── sdrService.js         # SDR device management
│   │   ├── networkService.js     # Network scanning
│   │   ├── reportService.js      # PDF/HTML/DOCX generation
│   │   ├── complianceService.js  # Rules engine
│   │   └── [... more services]
│   ├── models/
│   │   ├── User.js
│   │   ├── Engagement.js
│   │   ├── Operation.js
│   │   ├── Finding.js
│   │   ├── SDRCapture.js
│   │   └── [... more models]
│   ├── websockets/
│   │   ├── handlers/
│   │   │   ├── sdrStream.js      # SDR spectrum/waterfall streaming
│   │   │   ├── signalDetection.js
│   │   │   ├── trackingStream.js # ADS-B, AIS, GPS updates
│   │   │   ├── mapEvents.js      # Live map updates
│   │   │   └── collaboration.js  # Team messages, live updates
│   │   └── manager.js            # WebSocket connection management
│   ├── utils/
│   │   ├── logger.js
│   │   ├── validators.js
│   │   ├── crypto.js             # AES-256-GCM encryption
│   │   └── helpers.js
│   └── constants/
│       ├── errors.js
│       ├── permissions.js
│       └── frequencies.js
├── package.json
├── .env.example
└── Dockerfile
*/

// ================================================================
// AUTHENTICATION & JWT
// ================================================================

/*
ENDPOINT: POST /api/v1/auth/login
Request:
{
  "username": "operator",
  "password": "password"
}
Response:
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "uuid",
    "username": "operator",
    "role": "operator"
  },
  "expiresIn": 3600
}
*/

/*
ENDPOINT: POST /api/v1/auth/refresh-token
Headers: Authorization: Bearer <token>
Response: { "token": "new_jwt_token", "expiresIn": 3600 }
*/

/*
ENDPOINT: POST /api/v1/auth/logout
Headers: Authorization: Bearer <token>
Response: { "message": "Logged out successfully" }
*/

// ================================================================
// ENGAGEMENT MANAGEMENT
// ================================================================

/*
ENDPOINT: GET /api/v1/engagements
Query Params: ?status=active&page=1&limit=50
Headers: Authorization: Bearer <token>
Response:
{
  "engagements": [
    {
      "id": "uuid",
      "name": "Client ABC Pentest",
      "client": "ABC Corp",
      "scope": { "ips": ["192.168.1.0/24"], "domains": ["abc.com"] },
      "status": "active",
      "start_date": "2024-01-01",
      "end_date": "2024-03-31",
      "team_lead": "John Doe",
      "operations_count": 5,
      "findings_count": 24
    }
  ],
  "total": 12,
  "page": 1,
  "limit": 50
}
*/

/*
ENDPOINT: POST /api/v1/engagements
Headers: Authorization: Bearer <token>
Body:
{
  "name": "Client XYZ Pentest",
  "client": "XYZ Inc",
  "scope": {
    "ips": ["10.0.0.0/8"],
    "domains": ["xyz.com"],
    "exclude_ips": ["10.0.0.1"]
  },
  "start_date": "2024-06-01",
  "end_date": "2024-08-31",
  "authorization_doc_url": "https://s3.../auth.pdf"
}
Response: { "id": "new_uuid", ... }
*/

/*
ENDPOINT: PUT /api/v1/engagements/{id}
ENDPOINT: DELETE /api/v1/engagements/{id}
ENDPOINT: GET /api/v1/engagements/{id}
*/

// ================================================================
// OPERATIONS & FINDINGS
// ================================================================

/*
ENDPOINT: POST /api/v1/operations
Body:
{
  "engagement_id": "uuid",
  "name": "Network Reconnaissance",
  "type": "recon",
  "start_time": "2024-06-01T10:00:00Z"
}
*/

/*
ENDPOINT: GET /api/v1/operations/{id}/findings
Response: [ { "id", "title", "severity", "status", "description" } ]
*/

/*
ENDPOINT: POST /api/v1/findings
Body:
{
  "operation_id": "uuid",
  "title": "SQL Injection in Login Form",
  "severity": "critical",
  "description": "...",
  "remediation": "..."
}
*/

// ================================================================
// OSINT INTEGRATIONS
// ================================================================

/*
ENDPOINT: POST /api/v1/osint/shodan/search
Headers: Authorization: Bearer <token>
Body: { "query": "port:22 country:US" }
Response:
{
  "results": [ ... ],
  "total_results": 1234,
  "cached": false
}
Note: Requires SHODAN_API_KEY in .env
*/

/*
ENDPOINT: GET /api/v1/osint/virustotal/{hash|ip|domain}
Examples:
  GET /api/v1/osint/virustotal/192.168.1.1
  GET /api/v1/osint/virustotal/malware_hash_here
Response:
{
  "indicator": "192.168.1.1",
  "type": "ip",
  "detections": [ ... ],
  "last_analysis_stats": { "malicious": 2, "undetected": 50 }
}
*/

/*
ENDPOINT: POST /api/v1/osint/censys/search
Body: { "query": "services.service_name: http" }
Response: { "results": [ ... ] }
*/

/*
ENDPOINT: GET /api/v1/osint/threats
Query: ?operation_id=uuid
Response: [ { "indicator_type", "indicator_value", "severity" } ]
*/

/*
ENDPOINT: POST /api/v1/osint/check-breaches
Body: { "emails": ["user@example.com"] }
Response: [ { "email", "breaches": [ ... ] } ]
*/

// ================================================================
// SDR CONTROL & SIGNAL ANALYSIS
// ================================================================

/*
ENDPOINT: POST /api/v1/sdr/start-capture
Headers: Authorization: Bearer <token>
Body:
{
  "operation_id": "uuid",
  "device_type": "RTL-SDR",
  "frequency_start": 433000000,
  "frequency_end": 434000000,
  "sample_rate": 2000000,
  "duration_seconds": 60
}
Response:
{
  "capture_id": "uuid",
  "status": "capturing",
  "timestamp": "2024-06-01T10:00:00Z"
}
*/

/*
ENDPOINT: POST /api/v1/sdr/stop-capture
Body: { "capture_id": "uuid" }
*/

/*
ENDPOINT: GET /api/v1/sdr/captures
Query: ?operation_id=uuid&limit=20
Response: [ { "id", "device_type", "frequency_range", "duration", "status" } ]
*/

/*
ENDPOINT: GET /api/v1/signals/detect
Query: ?capture_id=uuid
Response:
{
  "signals": [
    {
      "frequency": 433920000,
      "modulation": "FSK",
      "rssi": -75.5,
      "bandwidth": 25000,
      "confidence": 0.92
    }
  ]
}
*/

/*
ENDPOINT: POST /api/v1/signals/decode
Body:
{
  "signal_id": "uuid",
  "decoder_type": "FSK"
}
Response: { "decoded_data": "...", "confidence": 0.95 }
*/

// ================================================================
// NETWORK SCANNING & TOPOLOGY
// ================================================================

/*
ENDPOINT: POST /api/v1/network/scan
Body:
{
  "operation_id": "uuid",
  "target": "192.168.1.0/24",
  "scan_type": "syn"
}
Response: { "scan_id": "uuid", "status": "starting" }
*/

/*
ENDPOINT: GET /api/v1/network/topology/{operation_id}
Response:
{
  "devices": [ { "ip", "hostname", "os", "services" } ],
  "edges": [ { "source_ip", "dest_ip", "relationship" } ]
}
*/

/*
ENDPOINT: GET /api/v1/vulnerabilities?operation_id=uuid&severity=critical
Response: [ { "id", "cve_id", "title", "severity", "cvss", "remediation" } ]
*/

// ================================================================
// REPORTING
// ================================================================

/*
ENDPOINT: POST /api/v1/reports/generate
Body:
{
  "engagement_id": "uuid",
  "report_type": "executive_summary",
  "output_format": "pdf",
  "include_sections": ["overview", "findings", "recommendations"]
}
Response: { "report_id": "uuid", "status": "generating" }
*/

/*
ENDPOINT: GET /api/v1/reports/{id}
Response:
{
  "id": "uuid",
  "engagement": "Client ABC",
  "generated_at": "2024-06-01T10:00:00Z",
  "file_url": "https://s3.../reports/uuid.pdf",
  "file_size": 2048576
}
*/

/*
ENDPOINT: GET /api/v1/reports/templates
Response: [ { "id", "name", "sections", "default": false } ]
*/

// ================================================================
// COMPLIANCE RULES ENGINE
// ================================================================

/*
ENDPOINT: POST /api/v1/compliance/check
Body:
{
  "engagement_id": "uuid",
  "action": "scan_ip",
  "target": "192.168.1.1"
}
Response:
{
  "allowed": true,
  "rules_checked": 5,
  "blocking_rules": [],
  "warnings": []
}
*/

/*
ENDPOINT: GET /api/v1/compliance/rules?engagement_id=uuid
Response: [ { "id", "rule_name", "rule_text", "status" } ]
*/

/*
ENDPOINT: POST /api/v1/compliance/rules
Body:
{
  "engagement_id": "uuid",
  "rule_name": "No scanning outside scope",
  "rule_text": "target_ip IN engagement.scope.ips",
  "enforcement_mode": "block"
}
*/

// ================================================================
// HARDWARE DEVICE MANAGEMENT
// ================================================================

/*
ENDPOINT: GET /api/v1/hardware/devices
Response:
[
  {
    "id": "uuid",
    "device_type": "RTL-SDR",
    "model": "RTL-SDR V4",
    "status": "connected",
    "last_sync": "2024-06-01T10:05:00Z",
    "battery_level": 92
  }
]
*/

/*
ENDPOINT: POST /api/v1/hardware/{id}/flash
Body:
{
  "firmware_url": "https://github.com/..../firmware.bin",
  "version": "1.2.3"
}
Response: { "status": "flashing", "progress": 0 }
*/

/*
ENDPOINT: GET /api/v1/hardware/{id}/telemetry
Response:
{
  "metrics": [
    { "name": "temperature", "value": 45.3, "unit": "C" },
    { "name": "cpu_load", "value": 32, "unit": "%" }
  ]
}
*/

// ================================================================
// SCRIPTING & AUTOMATION
// ================================================================

/*
ENDPOINT: GET /api/v1/scripts
Response: [ { "id", "name", "language", "category", "created_by" } ]
*/

/*
ENDPOINT: POST /api/v1/scripts
Body:
{
  "name": "WiFi Enumeration",
  "language": "python",
  "code": "import subprocess\nsubprocess.run(['airodump-ng', ...])",
  "description": "Enumerate nearby WiFi networks"
}
*/

/*
ENDPOINT: POST /api/v1/scripts/{id}/execute
Body: { "parameters": {} }
Response: { "execution_id": "uuid", "status": "running" }
*/

/*
ENDPOINT: GET /api/v1/script-executions/{id}
Response:
{
  "id": "uuid",
  "script_id": "uuid",
  "status": "completed",
  "exit_code": 0,
  "stdout": "... output ...",
  "stderr": "",
  "duration_seconds": 45
}
*/

/*
ENDPOINT: POST /api/v1/tasks/schedule
Body:
{
  "script_id": "uuid",
  "cron_expression": "0 0 * * *",
  "execution_timeout_seconds": 3600
}
Response: { "task_id": "uuid", "next_run": "2024-06-02T00:00:00Z" }
*/

// ================================================================
// TEAM COLLABORATION
// ================================================================

/*
ENDPOINT: POST /api/v1/messages
Headers: Authorization: Bearer <token>
Body:
{
  "recipients": ["user_id_1", "user_id_2"],
  "content": "Found SQL injection in login form"
}
Response: { "message_id": "uuid" }
*/

/*
ENDPOINT: GET /api/v1/messages/threads
Response: [ { "id", "participants", "last_message_at", "unread_count" } ]
*/

/*
ENDPOINT: GET /api/v1/messages/{thread_id}
Response: [ { "id", "sender", "content", "timestamp" } ]
*/

/*
ENDPOINT: POST /api/v1/findings/{id}/comments
Body: { "content": "This is a critical finding" }
*/

// ================================================================
// WEBSOCKET STREAMS
// ================================================================

/*
Connect: ws://api.server/ws
Authenticate: Send { "type": "auth", "token": "jwt_token" }

// Subscribe to SDR spectrum updates
io.emit('subscribe', {
  "stream": "sdr/spectrum",
  "capture_id": "uuid",
  "interval_ms": 100
})

Receive:
{
  "type": "spectrum_data",
  "capture_id": "uuid",
  "frequencies": [433000000, 433001000, ...],
  "power": [-80, -75, -70, ...],
  "timestamp": "2024-06-01T10:00:00.123Z"
}

// Subscribe to signal detections
io.emit('subscribe', {
  "stream": "signals/detect",
  "operation_id": "uuid"
})

Receive:
{
  "type": "signal_detected",
  "signal": {
    "frequency": 433920000,
    "modulation": "FSK",
    "rssi": -75.5,
    "confidence": 0.92
  }
}

// Subscribe to ADS-B aircraft positions
io.emit('subscribe', {
  "stream": "tracking/adsb"
})

Receive:
{
  "type": "adsb_update",
  "aircraft": [
    {
      "icao": "A123BC",
      "callsign": "SWA456",
      "lat": 40.123,
      "lon": -105.456,
      "altitude": 35000,
      "speed": 450
    }
  ]
}

// Subscribe to team messages
io.emit('subscribe', {
  "stream": "team/messages"
})

Receive:
{
  "type": "message",
  "sender": "user_id",
  "content": "...",
  "timestamp": "2024-06-01T10:00:00Z"
}
*/

// ================================================================
// ERROR RESPONSES
// ================================================================

/*
400 Bad Request
{ "error": "Invalid request", "details": "Field 'operation_id' is required" }

401 Unauthorized
{ "error": "Unauthorized", "message": "Invalid or expired token" }

403 Forbidden
{ "error": "Forbidden", "message": "You don't have permission to access this resource" }

404 Not Found
{ "error": "Not found", "message": "Resource with id 'uuid' not found" }

500 Internal Server Error
{ "error": "Internal server error", "message": "An unexpected error occurred" }
*/

// ================================================================
// RATE LIMITING
// ================================================================
// Global: 1000 requests per hour per IP
// OSINT endpoints: 100 per hour (Shodan, VirusTotal)
// SDR capture: 10 concurrent captures max
// Script execution: 5 concurrent executions max

// ================================================================
// EXAMPLE: STARTING THE SERVER
// ================================================================

/*
const express = require('express');
const { Server } = require('socket.io');
const { createServer } = require('http');
const pg = require('pg');
const Redis = require('ioredis');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

// Middleware
app.use(express.json());
app.use(authMiddleware);

// Routes
app.use('/api/v1/auth', require('./routes/auth'));
app.use('/api/v1/osint', require('./routes/osint'));
app.use('/api/v1/sdr', require('./routes/sdr'));
// ... more routes

// WebSocket handlers
io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);
  
  socket.on('subscribe', (params) => {
    if (params.stream === 'sdr/spectrum') {
      // Start sending spectrum updates
      const interval = setInterval(() => {
        socket.emit('spectrum_data', generateSpectrumData());
      }, params.interval_ms || 100);
      
      socket.on('disconnect', () => clearInterval(interval));
    }
  });
});

// Start server
httpServer.listen(5000, () => {
  console.log('API server running on port 5000');
});
*/
