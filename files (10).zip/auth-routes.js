// ================================================================
// AUTHENTICATION ROUTES
// POST /api/v1/auth/login
// POST /api/v1/auth/logout
// POST /api/v1/auth/refresh-token
// GET  /api/v1/auth/user
// ================================================================

const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { cache } = require('../config/redis');
const logger = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// ================================================================
// POST /api/v1/auth/login
// ================================================================
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({
        error: 'Validation error',
        message: 'Username and password are required',
      });
    }

    // Find user
    const userResult = await db.query(
      'SELECT id, username, email, password_hash, role FROM users WHERE username = $1',
      [username],
    );

    if (userResult.rows.length === 0) {
      logger.warn('Login attempt with non-existent user', { username });
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Invalid username or password',
      });
    }

    const user = userResult.rows[0];

    // Check password
    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch) {
      logger.warn('Login attempt with wrong password', { userId: user.id });
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Invalid username or password',
      });
    }

    // Generate tokens
    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
        role: user.role,
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRE || 3600 },
    );

    const refreshToken = jwt.sign(
      { id: user.id },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: process.env.REFRESH_TOKEN_EXPIRE || 604800 },
    );

    // Store refresh token in Redis
    await cache.set(`refresh_token:${user.id}`, refreshToken, 604800);

    // Log audit
    await db.query(
      'INSERT INTO audit_log (user_id, action, resource_type, status, ip_address) VALUES ($1, $2, $3, $4, $5)',
      [user.id, 'LOGIN', 'auth', 'success', req.ip],
    );

    logger.info('User logged in', { userId: user.id, username: user.username });

    return res.json({
      token,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
      },
      expiresIn: parseInt(process.env.JWT_EXPIRE || 3600),
    });
  } catch (error) {
    logger.error('Login error', { error: error.message });
    return res.status(500).json({
      error: 'Internal server error',
      message: 'An unexpected error occurred',
    });
  }
});

// ================================================================
// POST /api/v1/auth/refresh-token
// ================================================================
router.post('/refresh-token', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        error: 'Validation error',
        message: 'Refresh token is required',
      });
    }

    // Verify refresh token
    let decoded;
    try {
      decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);
    } catch (error) {
      return res.status(401).json({
        error: 'Token error',
        message: 'Invalid or expired refresh token',
      });
    }

    // Get user
    const userResult = await db.query(
      'SELECT id, username, email, role FROM users WHERE id = $1',
      [decoded.id],
    );

    if (userResult.rows.length === 0) {
      return res.status(401).json({
        error: 'Token error',
        message: 'User not found',
      });
    }

    const user = userResult.rows[0];

    // Generate new token
    const newToken = jwt.sign(
      {
        id: user.id,
        username: user.username,
        role: user.role,
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRE || 3600 },
    );

    logger.info('Token refreshed', { userId: user.id });

    return res.json({
      token: newToken,
      expiresIn: parseInt(process.env.JWT_EXPIRE || 3600),
    });
  } catch (error) {
    logger.error('Token refresh error', { error: error.message });
    return res.status(500).json({
      error: 'Internal server error',
      message: 'An unexpected error occurred',
    });
  }
});

// ================================================================
// POST /api/v1/auth/logout
// ================================================================
router.post('/logout', authMiddleware, async (req, res) => {
  try {
    const { user } = req;

    // Invalidate refresh token
    await cache.del(`refresh_token:${user.id}`);

    // Log audit
    await db.query(
      'INSERT INTO audit_log (user_id, action, resource_type, status) VALUES ($1, $2, $3, $4)',
      [user.id, 'LOGOUT', 'auth', 'success'],
    );

    logger.info('User logged out', { userId: user.id });

    return res.json({
      message: 'Logged out successfully',
    });
  } catch (error) {
    logger.error('Logout error', { error: error.message });
    return res.status(500).json({
      error: 'Internal server error',
      message: 'An unexpected error occurred',
    });
  }
});

// ================================================================
// GET /api/v1/auth/user
// ================================================================
router.get('/user', authMiddleware, async (req, res) => {
  try {
    const { user } = req;

    // Get full user data
    const userResult = await db.query(
      'SELECT id, username, email, role, last_login, created_at FROM users WHERE id = $1',
      [user.id],
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        error: 'Not found',
        message: 'User not found',
      });
    }

    return res.json(userResult.rows[0]);
  } catch (error) {
    logger.error('Get user error', { error: error.message });
    return res.status(500).json({
      error: 'Internal server error',
      message: 'An unexpected error occurred',
    });
  }
});

module.exports = router;
