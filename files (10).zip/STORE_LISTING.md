# Google Play store listing — draft

## A real risk to understand before you submit

Google Play's policies (Deceptive Behavior / Mobile Unwanted Software) are enforced partly on how an
app's *listing* describes it, not just what the code does. This app itself is benign: it's a WebSocket
client that shows status and sends a handful of whitelisted commands to a server you run. But if the
listing is written with "pentest" / "hacking" / "exploit" language, it reads very differently to an
automated or human reviewer than "IoT device dashboard," even though the underlying app is identical.
Reviewers and the pre-launch scanner have flagged otherwise-legitimate network/device tools for this
reason before. The draft below describes only what the app actually does, to keep the listing accurate
and reduce rejection risk. You can always market the broader ICU platform elsewhere (your own site,
direct distribution) in whatever terms fit your brand — Play's listing text just needs to match this
specific app's behavior.

## Draft listing copy

**App name:** ICU

**Short description** (80 char max):
> Dashboard and control for your own self-hosted IoT devices.

**Full description:**
> ICU connects to a server you run yourself and shows the status of devices you own: connection
> state, signal strength, uptime, and temperature. Send a small set of basic commands (power an
> indicator on/off, restart) to connected devices, and run basic offline signal analysis (frequency
> content, filtering) on sample data.
>
> ICU requires you to run your own server — it does not connect to any service operated by us, and
> no account or data is shared with any third party.

**Category:** Tools (or IoT-adjacent category Play offers at submission time — check current options)

**Content rating questionnaire:** answer "no" to violence/sexual content/gambling/etc. — there is none.
Expect a rating like "Everyone" / "PEGI 3."

**Data safety form (Play Console):**
- Data collected: None
- Data shared with third parties: None
- Data encrypted in transit: depends on your server — the app currently connects over `ws://` (plain)
  by default; see the note in `android/app/src/main/AndroidManifest.xml`
  (`android:usesCleartextTraffic="true"`). If you want to answer "Yes, encrypted in transit" truthfully,
  put your server behind TLS (`wss://`) and remove that manifest flag before submission — otherwise
  answer honestly that it is not guaranteed encrypted, since the app allows plain `ws://`.
- Data deleted on request: not applicable, nothing is stored by the app

## Graphic assets still needed (I can't generate these responsibly)
These are brand/design decisions, not code — generating placeholder raster art for a company's public
store listing would just hand you something you'd have to redo anyway:
- App icon, 512×512 PNG, no alpha channel
- Feature graphic, 1024×500 PNG
- At least 2 phone screenshots (1080×1920 or similar) — take these from a real build once you run one
- Optional: short promo video URL

The in-app launcher icon (`android/app/src/main/res/drawable/ic_launcher_*.xml`) is a placeholder
vector — simple eye motif, teal on dark navy — that will build and show up correctly, but you'll
likely want real branding before a public listing.
