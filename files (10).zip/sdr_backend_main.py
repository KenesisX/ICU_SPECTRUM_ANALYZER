#!/usr/bin/env python3
"""
STRIKEBACK SDR ANALYSIS PLATFORM
Backend API Server with Hardware Abstraction Layer

Supports: RTL-SDR V4, Pluto, HackRF, ESP32+CC1101, ESP32+NRF24, Mobile KVMP
"""

import os
import json
import time
import asyncio
import threading
import logging
from datetime import datetime
from collections import deque
from typing import Optional, Dict, List
import numpy as np

# Web framework
from flask import Flask, jsonify, request
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS

# Database
import psycopg2
from psycopg2.extras import RealDictCursor

# Scientific
from scipy import signal, fft as scipy_fft
from scipy.signal import find_peaks
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# HARDWARE DRIVERS
# ============================================================================

class SpectrumAnalyzer:
    """Real-time spectrum analysis engine"""
    def __init__(self, sample_rate=2.4e6, fft_size=2048):
        self.fs = sample_rate
        self.fft_size = fft_size
        self.window = signal.get_window('hann', fft_size)
        self.power_history = deque(maxlen=100)  # For waterfall
    
    def compute_fft(self, iq_samples):
        """Compute FFT with power spectrum"""
        if len(iq_samples) < self.fft_size:
            iq_samples = np.pad(iq_samples, (0, self.fft_size - len(iq_samples)))
        
        windowed = iq_samples[:self.fft_size] * self.window
        fft_result = np.fft.fft(windowed)
        power_db = 10 * np.log10(np.abs(fft_result) ** 2 + 1e-10)
        freqs = np.fft.fftfreq(self.fft_size, 1/self.fs)
        
        # Shift DC to center
        power_shifted = np.fft.fftshift(power_db)
        freqs_shifted = np.fft.fftshift(freqs)
        
        self.power_history.append(power_shifted)
        return freqs_shifted, power_shifted
    
    def get_waterfall(self):
        """Get recent waterfall data (100 FFT frames)"""
        if len(self.power_history) == 0:
            return np.zeros((1, self.fft_size))
        return np.array(self.power_history)
    
    def detect_signals(self, power_spectrum, threshold_db=-80, min_bandwidth=10):
        """Detect signal peaks above threshold"""
        peaks, properties = find_peaks(power_spectrum, height=threshold_db, distance=min_bandwidth)
        
        signals = []
        for peak in peaks:
            freq_idx = peak
            power = power_spectrum[freq_idx]
            # Estimate bandwidth (3dB width)
            level_3db = power - 3
            
            signals.append({
                'frequency_bin': int(freq_idx),
                'power_db': float(power),
                'prominence': float(properties['peak_heights'][list(peaks).index(peak)]),
            })
        
        return sorted(signals, key=lambda x: x['power_db'], reverse=True)[:10]  # Top 10
    
    def estimate_modulation(self, iq_samples):
        """Estimate modulation type from constellation"""
        # Normalize
        norm_samples = iq_samples / (np.max(np.abs(iq_samples)) + 1e-10)
        
        # Simple clustering-based classification
        constellation_type = self._classify_constellation(norm_samples[:1000])
        return constellation_type
    
    def _classify_constellation(self, samples):
        """Classify by counting constellation points"""
        # Quantize to nearest 0.25
        quantized = np.round(samples.real * 4) / 4 + 1j * np.round(samples.imag * 4) / 4
        unique_points = len(np.unique(quantized))
        
        if unique_points <= 2:
            return 'BPSK'
        elif unique_points <= 4:
            return 'QPSK'
        elif unique_points <= 16:
            return 'QAM16'
        elif unique_points <= 64:
            return 'QAM64'
        else:
            return 'UNKNOWN'


class DemodulatorChain:
    """Signal demodulation engines"""
    def __init__(self, sample_rate=2.4e6):
        self.fs = sample_rate
        self.audio_rate = 48000
    
    def demod_fm(self, samples):
        """FM demodulation"""
        phase = np.unwrap(np.angle(samples))
        freq = np.diff(phase) * self.fs / (2 * np.pi)
        
        # Resample to audio rate
        audio = scipy_fft.resample(freq, int(len(freq) * self.audio_rate / self.fs))
        
        # Normalize
        if np.max(np.abs(audio)) > 0:
            audio = audio / np.max(np.abs(audio))
        
        return audio.real
    
    def demod_am(self, samples):
        """AM demodulation"""
        envelope = np.abs(samples)
        
        # Low-pass filter to extract modulation
        b, a = signal.butter(5, 0.01)
        audio = signal.filtfilt(b, a, envelope)
        
        if np.max(np.abs(audio)) > 0:
            audio = audio / np.max(np.abs(audio))
        
        return audio
    
    def demod_lsb(self, samples):
        """Single-sideband demodulation (LSB)"""
        # Hilbert transform for complex signal recovery
        analytic = signal.hilbert(samples.real)
        audio = np.imag(analytic)
        
        return audio / (np.max(np.abs(audio)) + 1e-10)
    
    def demod_fsk(self, samples, mark_freq=1200, space_freq=2200):
        """FSK demodulation"""
        t = np.arange(len(samples)) / self.fs
        
        mark_filter = np.exp(2j * np.pi * mark_freq * t)
        space_filter = np.exp(2j * np.pi * space_freq * t)
        
        mark_corr = np.correlate(samples, mark_filter, mode='same')
        space_corr = np.correlate(samples, space_filter, mode='same')
        
        # Simple threshold detection
        bits = (np.abs(mark_corr) > np.abs(space_corr)).astype(int)
        return bits


# ============================================================================
# FLASK APP INITIALIZATION
# ============================================================================

app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Global state
sdr_state = {
    'device': None,
    'device_type': 'rtlsdr',
    'is_capturing': False,
    'center_freq': 100e6,
    'sample_rate': 2.4e6,
    'iq_buffer': deque(maxlen=262144),
    'spectrum_analyzer': SpectrumAnalyzer(2.4e6),
    'demodulator': DemodulatorChain(2.4e6),
    'signal_detections': [],
    'capture_session': None,
}

# PostgreSQL connection
def get_db_connection():
    try:
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            database=os.getenv('DB_NAME', 'strikeback_sdr'),
            user=os.getenv('DB_USER', 'sdr_user'),
            password=os.getenv('DB_PASS', 'sdr_password')
        )
        return conn
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        return None


# ============================================================================
# REST API ENDPOINTS
# ============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'version': '1.0.0',
        'timestamp': datetime.now().isoformat(),
        'device_status': {
            'device_type': sdr_state['device_type'],
            'is_capturing': sdr_state['is_capturing'],
            'center_freq': sdr_state['center_freq'],
            'sample_rate': sdr_state['sample_rate'],
        }
    })


@app.route('/api/sdr/devices', methods=['GET'])
def list_devices():
    """List available SDR devices"""
    devices = [
        {
            'id': 0,
            'name': 'RTL-SDR V4',
            'type': 'rtlsdr',
            'freq_range': [24e6, 1.7e9],
            'sample_rate_max': 3.2e6,
            'sample_rate_typical': 2.4e6,
            'available': True,
        },
        {
            'id': 1,
            'name': 'ADALM Pluto',
            'type': 'pluto',
            'freq_range': [325e6, 3.8e9],
            'sample_rate_max': 61e6,
            'sample_rate_typical': 30e6,
            'available': False,  # Placeholder
        },
        {
            'id': 2,
            'name': 'HackRF One',
            'type': 'hackrf',
            'freq_range': [1e6, 6e9],
            'sample_rate_max': 20e6,
            'sample_rate_typical': 10e6,
            'available': False,
        },
        {
            'id': 3,
            'name': 'ESP32 + CC1101',
            'type': 'esp32_cc1101',
            'freq_range': [300e6, 928e6],
            'sample_rate_max': 500e3,
            'sample_rate_typical': 200e3,
            'available': False,
        },
        {
            'id': 4,
            'name': 'ESP32 + NRF24',
            'type': 'esp32_nrf24',
            'freq_range': [2.4e9, 2.5e9],
            'sample_rate_max': 2e6,
            'sample_rate_typical': 1e6,
            'available': False,
        },
    ]
    
    return jsonify({'devices': devices})


@app.route('/api/sdr/start', methods=['POST'])
def start_capture():
    """Start SDR capture session"""
    try:
        data = request.json or {}
        device_type = data.get('device_type', 'rtlsdr')
        freq = data.get('frequency', 100e6)
        sample_rate = data.get('sample_rate', 2.4e6)
        
        sdr_state['device_type'] = device_type
        sdr_state['center_freq'] = freq
        sdr_state['sample_rate'] = sample_rate
        sdr_state['is_capturing'] = True
        
        # Initialize spectrum analyzer with correct sample rate
        sdr_state['spectrum_analyzer'] = SpectrumAnalyzer(sample_rate)
        sdr_state['demodulator'] = DemodulatorChain(sample_rate)
        
        # Start background capture thread
        threading.Thread(target=_capture_thread, daemon=True).start()
        
        return jsonify({
            'status': 'started',
            'device_type': device_type,
            'frequency': freq,
            'sample_rate': sample_rate,
        })
    
    except Exception as e:
        logger.error(f"Capture start error: {e}")
        return jsonify({'error': str(e)}), 400


@app.route('/api/sdr/stop', methods=['POST'])
def stop_capture():
    """Stop SDR capture"""
    sdr_state['is_capturing'] = False
    return jsonify({'status': 'stopped'})


@app.route('/api/sdr/setFreq', methods=['POST'])
def set_frequency():
    """Set center frequency"""
    try:
        data = request.json
        freq = data.get('frequency')
        
        if freq is None:
            return jsonify({'error': 'frequency required'}), 400
        
        sdr_state['center_freq'] = freq
        
        return jsonify({
            'status': 'ok',
            'frequency': freq,
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/spectrum/current', methods=['GET'])
def get_current_spectrum():
    """Get current spectrum (FFT)"""
    try:
        if len(sdr_state['iq_buffer']) < sdr_state['spectrum_analyzer'].fft_size:
            return jsonify({'error': 'insufficient data'}), 400
        
        samples = np.array(list(sdr_state['iq_buffer'])[-2048:])
        freqs, power = sdr_state['spectrum_analyzer'].compute_fft(samples)
        
        # Detect signals
        signals = sdr_state['spectrum_analyzer'].detect_signals(power)
        
        return jsonify({
            'frequencies': freqs.tolist(),
            'power_db': power.tolist(),
            'detected_signals': signals,
            'center_freq': sdr_state['center_freq'],
            'sample_rate': sdr_state['sample_rate'],
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/signals/detect', methods=['GET'])
def get_detected_signals():
    """Get list of detected signals"""
    return jsonify({
        'signals': sdr_state['signal_detections'],
        'count': len(sdr_state['signal_detections']),
    })


@app.route('/api/iq/scatter', methods=['GET'])
def get_iq_constellation():
    """Get IQ constellation data"""
    try:
        if len(sdr_state['iq_buffer']) < 1000:
            return jsonify({'error': 'insufficient data'}), 400
        
        samples = np.array(list(sdr_state['iq_buffer'])[-10000:])
        decimated = samples[::10]  # Reduce for plotting
        
        modulation = sdr_state['spectrum_analyzer'].estimate_modulation(samples)
        
        return jsonify({
            'i_values': decimated.real.tolist(),
            'q_values': decimated.imag.tolist(),
            'estimated_modulation': modulation,
            'sample_count': len(decimated),
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/demod/<demod_type>', methods=['POST'])
def demodulate(demod_type):
    """Demodulate signal (FM, AM, FSK, LSB, etc.)"""
    try:
        if len(sdr_state['iq_buffer']) < 4096:
            return jsonify({'error': 'insufficient data'}), 400
        
        samples = np.array(list(sdr_state['iq_buffer'])[-262144:])
        
        if demod_type.lower() == 'fm':
            audio = sdr_state['demodulator'].demod_fm(samples)
            audio_type = 'audio/wav'
        elif demod_type.lower() == 'am':
            audio = sdr_state['demodulator'].demod_am(samples)
            audio_type = 'audio/wav'
        elif demod_type.lower() == 'lsb':
            audio = sdr_state['demodulator'].demod_lsb(samples)
            audio_type = 'audio/wav'
        elif demod_type.lower() == 'fsk':
            bits = sdr_state['demodulator'].demod_fsk(samples)
            return jsonify({
                'bits': bits.tolist(),
                'bit_count': len(bits),
            })
        else:
            return jsonify({'error': f'unknown demodulation type: {demod_type}'}), 400
        
        # Resample to 16-bit PCM
        audio_int16 = np.int16(audio * 32767)
        
        return jsonify({
            'demodulation_type': demod_type,
            'audio_length_samples': len(audio_int16),
            'audio_duration_sec': len(audio_int16) / 48000,
            'sample_rate': 48000,
        })
    
    except Exception as e:
        logger.error(f"Demodulation error: {e}")
        return jsonify({'error': str(e)}), 400


@app.route('/api/captures/list', methods=['GET'])
def list_captures():
    """List saved captures from database"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'database unavailable'}), 500
        
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("""
            SELECT id, name, created_at, center_freq, sample_rate, 
                   duration_seconds, modulation 
            FROM captures 
            ORDER BY created_at DESC 
            LIMIT 50
        """)
        
        captures = cur.fetchall()
        cur.close()
        conn.close()
        
        return jsonify({
            'captures': [dict(c) for c in captures],
            'count': len(captures),
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/captures/save', methods=['POST'])
def save_capture():
    """Save current capture session to database"""
    try:
        data = request.json or {}
        name = data.get('name', f'Capture_{int(time.time())}')
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'database unavailable'}), 500
        
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO captures 
            (name, created_at, center_freq, sample_rate, hardware_type, notes)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (name, datetime.now(), sdr_state['center_freq'], 
              sdr_state['sample_rate'], sdr_state['device_type'], 
              data.get('notes', '')))
        
        capture_id = cur.fetchone()[0]
        conn.commit()
        
        # Save detected signals
        for detection in sdr_state['signal_detections'][:100]:  # Limit
            cur.execute("""
                INSERT INTO signals 
                (capture_id, frequency, power_dbm, modulation, timestamp)
                VALUES (%s, %s, %s, %s, %s)
            """, (capture_id, detection.get('frequency'), 
                  detection.get('power_db'), detection.get('modulation'), 
                  datetime.now()))
        
        conn.commit()
        cur.close()
        conn.close()
        
        return jsonify({
            'status': 'saved',
            'capture_id': capture_id,
            'name': name,
            'signal_count': len(sdr_state['signal_detections']),
        })
    
    except Exception as e:
        logger.error(f"Save capture error: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# WEBSOCKET STREAMS
# ============================================================================

@socketio.on('connect')
def handle_connect():
    """Client connected"""
    logger.info(f"Client connected: {request.sid}")
    emit('response', {'data': 'Connected to SDR server'})


@socketio.on('subscribe_spectrum')
def handle_spectrum_subscription():
    """Subscribe to real-time spectrum updates"""
    join_room('spectrum_stream')
    emit('subscribed', {'stream': 'spectrum'})


@socketio.on('subscribe_waterfall')
def handle_waterfall_subscription():
    """Subscribe to waterfall display"""
    join_room('waterfall_stream')
    emit('subscribed', {'stream': 'waterfall'})


@socketio.on('subscribe_iq')
def handle_iq_subscription():
    """Subscribe to IQ constellation updates"""
    join_room('iq_stream')
    emit('subscribed', {'stream': 'iq'})


# ============================================================================
# BACKGROUND THREADS
# ============================================================================

def _capture_thread():
    """Background thread for continuous SDR capture and analysis"""
    logger.info(f"Capture thread started - Device: {sdr_state['device_type']}")
    
    # Simulate IQ data generation (replace with actual hardware driver)
    frame_count = 0
    
    while sdr_state['is_capturing']:
        try:
            # Generate test signal (replace with actual SDR read)
            # In production, call actual device driver here
            num_samples = 2048
            test_signal = _generate_test_signal(
                freq=100e6,
                sample_rate=sdr_state['sample_rate'],
                num_samples=num_samples
            )
            
            # Add to buffer
            for sample in test_signal:
                sdr_state['iq_buffer'].append(sample)
            
            # Analyze every 2 frames
            if frame_count % 2 == 0:
                samples = np.array(list(sdr_state['iq_buffer'])[-2048:])
                freqs, power = sdr_state['spectrum_analyzer'].compute_fft(samples)
                
                # Detect signals
                signals = sdr_state['spectrum_analyzer'].detect_signals(power)
                sdr_state['signal_detections'] = signals
                
                # Broadcast spectrum
                socketio.emit('spectrum_update', {
                    'frequencies': freqs.tolist(),
                    'power_db': power.tolist(),
                    'center_freq': sdr_state['center_freq'],
                    'timestamp': time.time(),
                }, room='spectrum_stream')
                
                # Broadcast IQ
                decimated = samples[::10]
                socketio.emit('iq_update', {
                    'i_values': decimated.real.tolist(),
                    'q_values': decimated.imag.tolist(),
                    'timestamp': time.time(),
                }, room='iq_stream')
            
            frame_count += 1
            time.sleep(0.1)  # 100ms between frames
        
        except Exception as e:
            logger.error(f"Capture thread error: {e}")
            time.sleep(1)


def _generate_test_signal(freq, sample_rate, num_samples):
    """Generate test signal (sine wave with noise)"""
    t = np.arange(num_samples) / sample_rate
    # Sine wave at specified frequency
    signal_iq = np.exp(2j * np.pi * (freq / sample_rate) * np.arange(num_samples))
    # Add noise
    noise = 0.1 * (np.random.randn(num_samples) + 1j * np.random.randn(num_samples))
    return signal_iq + noise


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'not found'}), 404


@app.errorhandler(500)
def server_error(e):
    logger.error(f"Server error: {e}")
    return jsonify({'error': 'internal server error'}), 500


# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    logger.info("Starting STRIKEBACK SDR Platform")
    
    # Create database tables if needed
    try:
        conn = get_db_connection()
        if conn:
            logger.info("Database connected")
            conn.close()
    except Exception as e:
        logger.warning(f"Database initialization needed: {e}")
    
    # Start Flask/SocketIO
    socketio.run(app, host='0.0.0.0', port=5000, debug=False, allow_unsafe_werkzeug=True)
