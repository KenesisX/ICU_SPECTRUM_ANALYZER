# STRIKEBACK ENTERPRISE - Backend API Specification

## Overview
This document specifies the API architecture for integrating actual pentesting tools (Kali Linux, Parrot OS, Marauder, etc.) with the STRIKEBACK ENTERPRISE platform while enforcing scope limitations and ROE compliance.

---

## Core Principles

1. **Scope Enforcement** - All tool execution is verified against authorized targets before execution
2. **ROE Verification** - Operations are checked against Rules of Engagement on every execution
3. **Audit Logging** - Every operation is logged with timestamp, operator, target, result
4. **Authorization Checks** - Valid signed engagement documentation required
5. **Kill Switch** - Tools can be remotely stopped if they exceed scope

---

## Authentication

### Token-Based Authentication
```
Header: Authorization: Bearer {ENGAGEMENT_TOKEN}
Header: X-API-Key: {PLATFORM_API_KEY}

Engagement tokens expire when engagement ends.
API keys tied to operator accounts with audit trail.
```

### Scope Token
```
X-Scope-Token: {VERIFIED_SCOPE}
Contains hashed hash of authorized targets.
Regenerated on scope verification.
```

---

## Core API Endpoints

### 1. Engagement Management

#### GET /api/v1/engagements
Retrieve all active engagements.

**Response:**
```json
{
  "engagements": [
    {
      "id": "eng_acme_2024",
      "client": "Acme Corporation",
      "status": "ACTIVE",
      "scope": ["192.168.1.0/24", "10.20.30.0/24"],
      "roe_signed": true,
      "roe_date": "2024-09-22",
      "authorized_operators": ["operator1@strikeback.local"],
      "start_date": "2024-09-22",
      "end_date": "2024-10-06",
      "active": true
    }
  ]
}
```

#### POST /api/v1/engagements/{id}/verify-scope
Verify a target IP/CIDR is within authorized scope.

**Request:**
```json
{
  "target": "192.168.1.50",
  "operation": "nmap_scan",
  "tool": "nmap"
}
```

**Response:**
```json
{
  "authorized": true,
  "target": "192.168.1.50",
  "engagement": "eng_acme_2024",
  "roe_permits": true,
  "restrictions": ["no_dos", "no_db_access"],
  "timestamp": "2024-09-22T14:30:00Z",
  "scope_token": "st_xxxxx"
}
```

**If Unauthorized:**
```json
{
  "authorized": false,
  "reason": "Target outside authorized scope",
  "engagement_scope": ["192.168.1.0/24"],
  "requested_target": "192.168.2.50",
  "action": "BLOCKED"
}
```

---

### 2. Tool Execution APIs

#### POST /api/v1/tools/execute
Execute a tool with scope verification.

**Request:**
```json
{
  "engagement_id": "eng_acme_2024",
  "tool": "nmap",
  "target": "192.168.1.0/24",
  "parameters": {
    "scan_type": "syn_stealth",
    "ports": "1-65535",
    "timing": "sneaky"
  },
  "timeout": 3600
}
```

**Pre-Execution Checks:**
1. Verify engagement is active
2. Verify all targets in parameters are within scope
3. Verify ROE permits this tool on these targets
4. Check operator authorization
5. Generate audit log entry

**Response:**
```json
{
  "execution_id": "exec_nmap_001",
  "status": "RUNNING",
  "tool": "nmap",
  "targets": ["192.168.1.0/24"],
  "operator": "operator1@strikeback.local",
  "started": "2024-09-22T14:35:00Z",
  "backend": "kali_lab_01",
  "scope_verified": true
}
```

#### GET /api/v1/tools/execution/{execution_id}
Get execution status and results.

**Response:**
```json
{
  "execution_id": "exec_nmap_001",
  "status": "COMPLETE",
  "tool": "nmap",
  "started": "2024-09-22T14:35:00Z",
  "completed": "2024-09-22T14:42:15Z",
  "results": {
    "hosts_discovered": 23,
    "ports_open": 47,
    "services": [
      {"host": "192.168.1.1", "port": 22, "service": "ssh"},
      {"host": "192.168.1.5", "port": 80, "service": "http"}
    ]
  },
  "output_file": "/results/exec_nmap_001.xml"
}
```

#### POST /api/v1/tools/execution/{execution_id}/stop
Stop a running tool execution.

**Response:**
```json
{
  "status": "STOPPED",
  "execution_id": "exec_nmap_001",
  "reason": "User requested stop"
}
```

---

### 3. Scope Protection

#### POST /api/v1/scope/validate-targets
Validate a list of targets before bulk operations.

**Request:**
```json
{
  "engagement_id": "eng_acme_2024",
  "targets": ["192.168.1.50", "192.168.1.51", "10.20.30.1"],
  "operation": "vulnerability_scan"
}
```

**Response:**
```json
{
  "validation": {
    "authorized": [
      {"target": "192.168.1.50", "in_scope": true},
      {"target": "192.168.1.51", "in_scope": true}
    ],
    "unauthorized": [
      {"target": "10.20.30.1", "in_scope": false, "reason": "Outside scope"}
    ],
    "safe_to_execute": false,
    "message": "1 out of 3 targets unauthorized. Execution blocked."
  }
}
```

---

### 4. Node Management

#### GET /api/v1/nodes
List all authorized lab nodes.

**Response:**
```json
{
  "nodes": [
    {
      "id": "node_esp32_lab_1",
      "name": "ESP32 Lab-1",
      "type": "esp32",
      "location": "Strikeback Lab",
      "status": "ONLINE",
      "capabilities": ["wifi", "ble", "sdr"],
      "last_heartbeat": "2024-09-22T14:40:00Z",
      "api_endpoint": "http://192.168.1.50:8080"
    },
    {
      "id": "node_rpi_lab_1",
      "name": "RPi Scanner-1",
      "type": "raspberry_pi",
      "location": "Strikeback Lab",
      "status": "ONLINE",
      "capabilities": ["nmap", "hydra", "hashcat"],
      "last_heartbeat": "2024-09-22T14:40:00Z",
      "api_endpoint": "http://192.168.1.60:8080"
    }
  ]
}
```

#### POST /api/v1/nodes/{node_id}/deploy-tool
Deploy a tool to a specific node.

**Request:**
```json
{
  "tool": "hashcat",
  "parameters": {
    "hash_type": "md5",
    "wordlist": "rockyou.txt",
    "rule": "best64"
  }
}
```

**Response:**
```json
{
  "deployment_id": "dep_hashcat_001",
  "node_id": "node_rpi_lab_1",
  "status": "DEPLOYED",
  "tool": "hashcat",
  "started": "2024-09-22T14:45:00Z"
}
```

---

### 5. Findings & Reporting

#### POST /api/v1/findings/add
Add a finding to the engagement database.

**Request:**
```json
{
  "engagement_id": "eng_acme_2024",
  "finding": {
    "title": "SQL Injection in Login Form",
    "description": "Allows arbitrary database access via username field",
    "target": "192.168.1.5:80",
    "severity": "CRITICAL",
    "cvss_score": 9.8,
    "proof_of_concept": "' OR '1'='1",
    "remediation": "Use prepared statements",
    "tool_used": "sqlmap",
    "timestamp": "2024-09-22T14:50:00Z"
  }
}
```

**Response:**
```json
{
  "finding_id": "find_sql_inject_001",
  "created": "2024-09-22T14:50:00Z",
  "status": "DOCUMENTED"
}
```

#### GET /api/v1/findings/{engagement_id}
Retrieve all findings for an engagement.

**Response:**
```json
{
  "engagement_id": "eng_acme_2024",
  "findings": [
    {
      "id": "find_sql_inject_001",
      "title": "SQL Injection",
      "severity": "CRITICAL",
      "target": "192.168.1.5",
      "status": "OPEN"
    }
  ],
  "summary": {
    "total": 24,
    "critical": 3,
    "high": 7,
    "medium": 8,
    "low": 6
  }
}
```

#### POST /api/v1/reports/generate
Generate a formatted report.

**Request:**
```json
{
  "engagement_id": "eng_acme_2024",
  "report_type": "technical",
  "include": ["executive_summary", "findings", "recommendations", "evidence"],
  "format": "pdf"
}
```

**Response:**
```json
{
  "report_id": "rpt_acme_001",
  "status": "GENERATING",
  "format": "pdf",
  "estimated_completion": "2024-09-22T15:15:00Z"
}
```

#### GET /api/v1/reports/{report_id}/download
Download generated report.

---

### 6. Audit & Compliance

#### GET /api/v1/audit-log
Retrieve audit log for compliance verification.

**Query Parameters:**
- `engagement_id` - Filter by engagement
- `operator` - Filter by operator
- `start_date` - Filter by date range
- `action` - Filter by action type (TOOL_EXECUTED, SCOPE_VERIFIED, etc.)

**Response:**
```json
{
  "logs": [
    {
      "timestamp": "2024-09-22T14:35:00Z",
      "action": "TOOL_EXECUTED",
      "engagement": "eng_acme_2024",
      "operator": "operator1@strikeback.local",
      "tool": "nmap",
      "target": "192.168.1.0/24",
      "scope_verified": true,
      "roe_verified": true,
      "result": "SUCCESS",
      "hosts_discovered": 23
    },
    {
      "timestamp": "2024-09-22T14:50:00Z",
      "action": "SCOPE_VIOLATION_BLOCKED",
      "engagement": "eng_acme_2024",
      "operator": "operator2@strikeback.local",
      "tool": "sqlmap",
      "target": "192.168.2.50",
      "scope_verified": false,
      "reason": "Target outside scope",
      "result": "BLOCKED"
    }
  ]
}
```

---

## Integration Examples

### Example 1: Executing Nmap via API

```bash
curl -X POST https://platform.strikeback.local/api/v1/tools/execute \
  -H "Authorization: Bearer engagement_token_acme" \
  -H "Content-Type: application/json" \
  -d '{
    "engagement_id": "eng_acme_2024",
    "tool": "nmap",
    "target": "192.168.1.0/24",
    "parameters": {
      "scan_type": "syn",
      "ports": "1-1000",
      "timing": "normal"
    }
  }'
```

**Backend Flow:**
1. Platform verifies engagement is active
2. Platform verifies all targets in 192.168.1.0/24 are in scope
3. Platform checks ROE permits network scanning
4. Platform sends request to available Kali instance
5. Kali instance executes nmap with scope parameters
6. Results streamed back to platform
7. Findings stored in database
8. Operator can view results in UI

---

### Example 2: Deploying Hashcat to RPi Node

```bash
curl -X POST https://platform.strikeback.local/api/v1/nodes/node_rpi_lab_1/deploy-tool \
  -H "Authorization: Bearer engagement_token" \
  -d '{
    "tool": "hashcat",
    "parameters": {
      "hash_file": "hashes.txt",
      "hash_type": "1000",
      "wordlist": "rockyou.txt"
    }
  }'
```

**Workflow:**
1. Platform verifies node is online and authorized
2. Platform sends deployment command to RPi
3. RPi downloads necessary wordlists/rules
4. RPi executes hashcat
5. Results streamed back real-time
6. Cracked hashes stored in findings database

---

## Error Handling

### Scope Violation Error
```json
{
  "error": "SCOPE_VIOLATION",
  "message": "Target 192.168.2.50 is outside authorized scope",
  "authorized_scope": ["192.168.1.0/24"],
  "http_code": 403,
  "action": "BLOCKED"
}
```

### Authorization Error
```json
{
  "error": "UNAUTHORIZED",
  "message": "Engagement authorization expired",
  "engagement_id": "eng_acme_2024",
  "http_code": 401
}
```

### Tool Execution Error
```json
{
  "error": "EXECUTION_FAILED",
  "message": "Tool execution timeout after 3600 seconds",
  "execution_id": "exec_nmap_001",
  "http_code": 500
}
```

---

## Security Considerations

1. **All requests must be HTTPS**
2. **Tokens expire after engagement ends**
3. **API keys rotated quarterly**
4. **Every request logged and auditable**
5. **Scope tokens regenerated for each verification**
6. **Tools run in isolated containers with resource limits**
7. **Kills switch can terminate any tool in < 1 second**
8. **All findings encrypted at rest**

---

## Node Firmware Integration Points

Your ESP32/RPi nodes would:
1. Connect to platform via API
2. Register capabilities (tools available)
3. Poll for job assignments
4. Execute within scope parameters only
5. Stream results back to platform
6. Report heartbeat every 30 seconds
7. Accept remote stop commands

**See NODE_FIRMWARE_SPEC.md for implementation details.**

---

## Implementation Stack (Recommended)

**Frontend:** Already built (HTML/JS in platform)

**Backend Services:**
- **Framework:** Python Flask/FastAPI + PostgreSQL
- **Tool Integration:** Subprocess execution with timeouts + Docker containers
- **Scope Enforcement:** IPAddress library for validation + hardcoded limits
- **Audit Logging:** PostgreSQL with immutable audit table
- **API Authentication:** JWT tokens + operator role-based access

**Node Agents:**
- **ESP32:** MicroPython with HTTP client
- **RPi:** Python with requests library
- **Kali/Parrot:** Bash agents with tool wrapper scripts

---

## Deployment Architecture

```
┌─────────────────────────────────────────────────────┐
│         STRIKEBACK ENTERPRISE PLATFORM              │
│  (Scope Enforcement + ROE Verification + Audit)     │
└────────────────────┬────────────────────────────────┘
                     │ API
         ┌───────────┼───────────┬──────────────┐
         │           │           │              │
    ┌────▼──┐   ┌───▼──┐   ┌───▼──┐   ┌─────▼──┐
    │ Kali  │   │Parrot│   │ESP32 │   │  RPi   │
    │ Lab   │   │ Lab  │   │Lab-1 │   │Scanner │
    └───────┘   └──────┘   └──────┘   └────────┘
    
All tools execute with scope checking.
All results flow back to central platform.
```

---

## Next Steps

1. Implement Flask backend with PostgreSQL
2. Create tool wrapper scripts for Kali/Parrot tools
3. Develop Node firmware (ESP32 MicroPython + RPi Python agent)
4. Deploy in your lab environment
5. Test scope enforcement with unauthorized targets
6. Add more tools as needed
7. Generate professional reports for clients

This architecture ensures you maintain **full control** while staying **fully compliant** with engagement authorizations.
