// ================================================================
// NETWORK TOPOLOGY MAPPER & ADVANCED GIS
// Module 6: Network Topology Mapper, Module 20: Advanced GIS (3D TDOA)
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// NETWORK TOPOLOGY DISCOVERY & MAPPING
// ================================================================

router.post('/topology/discover', authMiddleware, async (req, res) => {
  try {
    const { engagement_id, subnet, scan_type } = req.body;

    const result = await db.query(
      `INSERT INTO network_scans (engagement_id, subnet, scan_type, status, initiated_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [engagement_id, subnet, scan_type, 'in_progress', req.user.id],
    );

    const scanId = result.rows[0].id;

    // Log scan initiation
    logger.info('Network scan initiated', { scanId, subnet, scanType: scan_type });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Network discovery error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/topology/nodes', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      ip_address,
      hostname,
      mac_address,
      device_type,
      open_ports,
      services,
      os_info,
    } = req.body;

    const result = await db.query(
      `INSERT INTO network_nodes 
       (engagement_id, ip_address, hostname, mac_address, device_type, open_ports, services, os_info)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (engagement_id, ip_address) DO UPDATE 
       SET hostname = EXCLUDED.hostname,
           open_ports = EXCLUDED.open_ports,
           services = EXCLUDED.services,
           os_info = EXCLUDED.os_info,
           updated_at = NOW()
       RETURNING *`,
      [
        engagement_id,
        ip_address,
        hostname,
        mac_address,
        device_type,
        JSON.stringify(open_ports),
        JSON.stringify(services),
        JSON.stringify(os_info),
      ],
    );

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Add network node error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/topology/links', authMiddleware, async (req, res) => {
  try {
    const { source_ip, dest_ip, protocol, port, connection_type } = req.body;

    const result = await db.query(
      `INSERT INTO network_links 
       (source_ip, dest_ip, protocol, port, connection_type)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (source_ip, dest_ip) DO UPDATE 
       SET connection_type = EXCLUDED.connection_type,
           updated_at = NOW()
       RETURNING *`,
      [source_ip, dest_ip, protocol, port, connection_type],
    );

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Add network link error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/topology/:engagement_id', authMiddleware, async (req, res) => {
  try {
    // Get all nodes
    const nodesResult = await db.query(
      `SELECT * FROM network_nodes WHERE engagement_id = $1 ORDER BY ip_address`,
      [req.params.engagement_id],
    );

    // Get all links
    const linksResult = await db.query(
      'SELECT * FROM network_links ORDER BY source_ip, dest_ip',
    );

    res.json({
      nodes: nodesResult.rows,
      links: linksResult.rows,
    });
  } catch (error) {
    logger.error('Get topology error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// GIS & GEOLOCATION MAPPING
// ================================================================

router.post('/gis/locations', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      name,
      latitude,
      longitude,
      address,
      location_type, // building, checkpoint, etc
      access_points,
    } = req.body;

    const result = await db.query(
      `INSERT INTO gis_locations 
       (engagement_id, name, latitude, longitude, address, location_type, access_points)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        engagement_id,
        name,
        latitude,
        longitude,
        address,
        location_type,
        JSON.stringify(access_points),
      ],
    );

    logger.info('GIS location created', { locationId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create GIS location error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/gis/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM gis_locations WHERE engagement_id = $1 ORDER BY created_at DESC`,
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get GIS locations error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// TDOA (TIME DIFFERENCE OF ARRIVAL) TRIANGULATION
// ================================================================

router.post('/tdoa/signals', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      signal_id,
      frequency,
      bearing,
      signal_strength,
      receiver_location,
      timestamp,
    } = req.body;

    const result = await db.query(
      `INSERT INTO tdoa_signals 
       (engagement_id, signal_id, frequency, bearing, signal_strength, receiver_location, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        engagement_id,
        signal_id,
        frequency,
        bearing,
        signal_strength,
        JSON.stringify(receiver_location),
        timestamp,
      ],
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Record TDOA signal error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/tdoa/triangulate', authMiddleware, async (req, res) => {
  try {
    const { signal_id, signals } = req.body;

    // Calculate triangulation from 3+ signal bearing measurements
    // Simple algorithm: average of bearing positions
    if (signals.length < 3) {
      return res.status(400).json({ error: 'Need at least 3 signal measurements for triangulation' });
    }

    const avgLat = signals.reduce((sum, s) => sum + s.receiver_location.latitude, 0) / signals.length;
    const avgLon = signals.reduce((sum, s) => sum + s.receiver_location.longitude, 0) / signals.length;

    const triangulation = {
      signal_id,
      estimated_latitude: avgLat,
      estimated_longitude: avgLon,
      confidence: 0.85, // Simplified confidence score
      signals_used: signals.length,
    };

    const result = await db.query(
      `INSERT INTO tdoa_triangulations 
       (signal_id, estimated_latitude, estimated_longitude, confidence, signals_used)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        signal_id,
        triangulation.estimated_latitude,
        triangulation.estimated_longitude,
        triangulation.confidence,
        triangulation.signals_used,
      ],
    );

    logger.info('TDOA triangulation calculated', { signalId: signal_id });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('TDOA triangulation error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// DRONE FLIGHT PATH PLANNING (Module 21)
// ================================================================

router.post('/drone/missions', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      name,
      waypoints,
      flight_time,
      altitude,
      objectives,
    } = req.body;

    const result = await db.query(
      `INSERT INTO drone_missions 
       (engagement_id, name, waypoints, flight_time, altitude, objectives, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        engagement_id,
        name,
        JSON.stringify(waypoints),
        flight_time,
        altitude,
        JSON.stringify(objectives),
        req.user.id,
      ],
    );

    logger.info('Drone mission created', { missionId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create drone mission error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/drone/missions/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM drone_missions WHERE engagement_id = $1 ORDER BY created_at DESC',
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get drone missions error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
