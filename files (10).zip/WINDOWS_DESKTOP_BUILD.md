# 🪟 STRIKEBACK COMMAND CENTER — Windows Desktop Build

Build a standalone Windows executable for the unified command center.

---

## Quick Start (Pre-Built Executable)

If you just want to **run it on Windows**:

1. Download: `STRIKEBACK-Command-Center-1.0.0-portable.exe`
2. Double-click to launch
3. No installation required, no dependencies

(Pre-built coming soon — use the manual build below for now)

---

## Manual Build (Windows 10/11)

### Prerequisites
1. **Node.js** (16+ LTS recommended)
   - Download: https://nodejs.org/
   - Install with npm included

2. **Git** (optional but recommended)
   - Download: https://git-scm.com/download/win

### Step 1: Prepare Files

Create a folder for the build:
```cmd
mkdir C:\strikeback-build
cd C:\strikeback-build
```

Copy these files into `C:\strikeback-build\`:
- `strikeback_unified_command_center.html` (rename from the outputs folder)
- `electron-main.js`
- `electron-preload.js`
- `electron-package.json` (rename to `package.json`)

### Step 2: Install Electron & Dependencies

Open Command Prompt in `C:\strikeback-build\`:
```cmd
npm install electron --save-dev
npm install electron-builder --save-dev
```

This downloads ~200-300 MB of files.

### Step 3: Test the App (Optional)

```cmd
npm start
```

This launches the app in development mode. Close to continue building.

### Step 4: Build Executable

```cmd
npm run build-win
```

This creates two installers in the `dist/` folder:
- **NSIS Installer** (`STRIKEBACK-Command-Center-Setup-1.0.0.exe`) — Full installer with uninstaller
- **Portable** (`STRIKEBACK-Command-Center-1.0.0-portable.exe`) — No installation, just run

Building takes 2-3 minutes.

### Step 5: Distribute

Both executables in `C:\strikeback-build\dist\` are standalone and ready to share:
- Portable version: **~150 MB** (no installation)
- Installer version: **~120 MB** (installs to `C:\Users\[user]\AppData\Local\Programs\STRIKEBACK Command Center\`)

---

## Script-Based Build (Automated)

Create `build.bat` in `C:\strikeback-build\`:

```batch
@echo off
REM STRIKEBACK Windows Build Script

echo [+] Installing dependencies...
call npm install electron --save-dev
call npm install electron-builder --save-dev

echo [+] Building Windows executables...
call npm run build-win

echo [+] Build complete!
echo [+] Check C:\strikeback-build\dist\ for executables

pause
```

Run:
```cmd
build.bat
```

---

## PowerShell Automation Script

Create `build.ps1`:

```powershell
# STRIKEBACK Windows Build Automation
$buildDir = "C:\strikeback-build"
$distDir = "$buildDir\dist"

Write-Host "[*] STRIKEBACK Command Center — Windows Build" -ForegroundColor Cyan
Write-Host "[*] Target: $buildDir" -ForegroundColor Cyan

Set-Location $buildDir

Write-Host "[+] Installing Node dependencies..." -ForegroundColor Green
npm install electron --save-dev
npm install electron-builder --save-dev

Write-Host "[+] Building executables..." -ForegroundColor Green
npm run build-win

Write-Host "[+] Build complete!" -ForegroundColor Green
Write-Host "[*] Executables in: $distDir" -ForegroundColor Yellow

# List files
Get-ChildItem $distDir -Filter "*.exe" | ForEach-Object {
    Write-Host "  - $($_.Name) ($([Math]::Round($_.Length/1MB, 1)) MB)" -ForegroundColor Cyan
}

Write-Host "[*] Ready to distribute!" -ForegroundColor Green
```

Run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\build.ps1
```

---

## Customization

### Change App Name
Edit `package.json`:
```json
"name": "strikeback-command-center",
"productName": "STRIKEBACK Command Center",
```

### Change App Icon
Replace `assets/icon.ico` (256x256 pixels recommended)

Create one from PNG:
1. Create 256x256 PNG
2. Use online converter: https://convertio.co/png-ico/
3. Save to `assets/icon.ico`

### Change Window Size
Edit `electron-main.js`:
```javascript
mainWindow = new BrowserWindow({
  width: 1600,      // Change width
  height: 1000,     // Change height
  minWidth: 1200,
  minHeight: 800,
});
```

### Enable DevTools
Edit `electron-main.js`, uncomment:
```javascript
mainWindow.webContents.openDevTools();
```

---

## Installation & Distribution

### Option 1: NSIS Installer
Users download `STRIKEBACK-Command-Center-Setup-1.0.0.exe`:
```
[Click installer]
→ Choose install location
→ Create Start Menu shortcuts
→ Creates uninstaller
```

### Option 2: Portable Executable
Users download `STRIKEBACK-Command-Center-1.0.0-portable.exe`:
```
[Double-click executable]
→ Runs immediately
→ No installation
→ Can run from USB drive
```

### Option 3: Corporate Deployment
For large teams, use Group Policy or SCCM to deploy the `.exe` to all machines.

---

## Troubleshooting

### "npm is not recognized"
- Node.js not installed or not in PATH
- **Fix:** Download & install Node.js from https://nodejs.org/
- Restart Command Prompt after installation

### "electron is not recognized"
- Dependencies not installed
- **Fix:** Run `npm install` again

### Build fails with "SIGNTOOL not found"
- Code signing tool missing (non-critical for private builds)
- **Fix:** Remove code signing from `package.json`:
```json
"win": {
  "certificateFile": null
}
```

### "icon.ico not found"
- Icon file missing
- **Fix:** Create `assets/` folder, add `icon.ico`
- Or remove icon from `package.json` temporarily

### App won't start
- Check `electron-main.js` path to HTML file
- Ensure `strikeback_unified_command_center.html` is in root directory

### Large file size
- Electron includes full Chromium browser (~150 MB)
- Normal. Use Portable version for minimal footprint.

---

## Advanced: Auto-Updater

Add auto-update capability:

```javascript
// In electron-main.js
const { autoUpdater } = require('electron-updater');

app.on('ready', () => {
  autoUpdater.checkForUpdatesAndNotify();
  createWindow();
});
```

Users automatically download new versions when available.

---

## Production Deployment

For production use:

1. **Code Sign** the executable (requires certificate)
   ```json
   "win": {
     "certificateFile": "path/to/cert.pfx",
     "certificatePassword": "password"
   }
   ```

2. **Enable Auto-Updates** (host on update server)

3. **Create Installer MSI** (for enterprise deployment)
   ```json
   "win": {
     "target": ["msi"]
   }
   ```

4. **Add EULA** (Required for installer)
   ```json
   "nsis": {
     "license": "LICENSE.txt"
   }
   ```

---

## Security Notes

⚠️ This builds a standalone app — **no data is sent to external servers** by default.

- **WebSocket Backend:** If you enable WebSocket streaming, ensure your backend is on a **secure network** or use **WSS (WebSocket Secure)**
- **Local Storage:** Map data is stored locally in the app
- **Offline Mode:** App works completely offline (simulated data)

---

## Support

For issues:
1. Check DevTools: Press `Ctrl+Shift+I` in the running app
2. Check Command Prompt for build errors
3. Ensure all prerequisites installed
4. Delete `node_modules/` and `package-lock.json`, reinstall with `npm install`

---

## File Checklist

Before building, ensure you have:
- ✅ `strikeback_unified_command_center.html` (main app)
- ✅ `electron-main.js` (launcher)
- ✅ `electron-preload.js` (security layer)
- ✅ `package.json` (config)
- ✅ `assets/icon.ico` (optional)
- ✅ Node.js installed (`node -v` returns version)

---

## Final Build Output

Success looks like:
```
[+] Building Windows executables...
  ✓ 1 file
  ⚙ building        target=NSIS arch=x64 file=STRIKEBACK-Command-Center-Setup-1.0.0.exe
  ⚙ building        target=portable arch=x64 file=STRIKEBACK-Command-Center-1.0.0-portable.exe

[+] Build complete in 2 minutes 47 seconds
```

Then in `dist/`:
```
STRIKEBACK-Command-Center-Setup-1.0.0.exe     ~120 MB  (installer)
STRIKEBACK-Command-Center-1.0.0-portable.exe  ~150 MB  (standalone)
```

**Ready to deploy!** 🚀
