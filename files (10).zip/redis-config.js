// ================================================================
// REDIS CONFIGURATION
// Caching, session management, pub/sub
// ================================================================

const Redis = require('ioredis');
const logger = require('../utils/logger');

const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD,
  db: process.env.REDIS_DB || 0,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  enableReadyCheck: false,
  enableOfflineQueue: true,
});

redis.on('connect', () => {
  logger.info('Redis connected');
});

redis.on('error', (err) => {
  logger.error('Redis error', { error: err.message });
});

redis.on('reconnecting', () => {
  logger.warn('Redis reconnecting...');
});

// Cache helper functions
const cache = {
  // Get value
  get: async (key) => {
    try {
      const value = await redis.get(key);
      return value ? JSON.parse(value) : null;
    } catch (err) {
      logger.error('Cache get error', { key, error: err.message });
      return null;
    }
  },

  // Set value with TTL
  set: async (key, value, ttl = 3600) => {
    try {
      await redis.setex(key, ttl, JSON.stringify(value));
      return true;
    } catch (err) {
      logger.error('Cache set error', { key, error: err.message });
      return false;
    }
  },

  // Delete key
  del: async (key) => {
    try {
      await redis.del(key);
      return true;
    } catch (err) {
      logger.error('Cache delete error', { key, error: err.message });
      return false;
    }
  },

  // Exists
  exists: async (key) => {
    try {
      const result = await redis.exists(key);
      return result === 1;
    } catch (err) {
      logger.error('Cache exists error', { key, error: err.message });
      return false;
    }
  },

  // Publish to channel
  publish: async (channel, message) => {
    try {
      await redis.publish(channel, JSON.stringify(message));
      return true;
    } catch (err) {
      logger.error('Publish error', { channel, error: err.message });
      return false;
    }
  },
};

module.exports = {
  redis,
  cache,
};
