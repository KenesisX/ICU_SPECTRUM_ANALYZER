/**
 * ================================================================
 * SIGNAL DECOMPOSITION & WAVEFORM EDITOR ROUTES
 * Module 10 Enhancement - Break down, analyze, edit signals
 * Proxies to Python FastAPI backend
 * ================================================================
 */

const express = require('express');
const axios = require('axios');
const { authenticate, authorize } = require('./auth-middleware');

const router = express.Router();

// Python backend endpoint
const PYTHON_BACKEND = process.env.PYTHON_BACKEND_URL || 'http://localhost:8000';

/**
 * @route   POST /api/v1/signal/decompose
 * @desc    Decompose signal into multiple domains
 * @access  Private
 * @body    {
 *            signal: [float],
 *            analysis_types: ['frequency', 'time_frequency', 'envelope', 'peaks'],
 *            sample_rate: float
 *          }
 */
router.post('/decompose', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, analysis_types = ['frequency', 'time_frequency', 'envelope', 'peaks'], sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/decompose`, {
      signal,
      analysis_types,
      sample_rate,
    });
    
    res.json({
      status: 'success',
      analysis: response.data.analysis,
      signal_length: response.data.signal_length,
    });
  } catch (err) {
    console.error('Signal decomposition error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/frequency-domain
 * @desc    Analyze signal in frequency domain (FFT)
 * @access  Private
 */
router.post('/frequency-domain', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/frequency-domain`, {
      samples: signal,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Frequency domain analysis error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/time-frequency
 * @desc    Analyze signal in time-frequency domain (STFT)
 * @access  Private
 */
router.post('/time-frequency', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, sample_rate = 1e6, window_size = 256, overlap = 0.75 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/time-frequency`, {
      samples: signal,
      sample_rate,
    }, {
      params: { window_size, overlap },
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Time-frequency analysis error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/wavelet
 * @desc    Analyze signal using wavelet transform (CWT)
 * @access  Private
 */
router.post('/wavelet', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, sample_rate = 1e6, wavelet = 'morlet' } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/wavelet`, {
      samples: signal,
      sample_rate,
    }, {
      params: { wavelet },
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Wavelet analysis error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/envelope
 * @desc    Extract amplitude envelope
 * @access  Private
 */
router.post('/envelope', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/envelope`, {
      samples: signal,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Envelope extraction error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/peaks-troughs
 * @desc    Detect peaks and troughs in signal
 * @access  Private
 */
router.post('/peaks-troughs', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, sample_rate = 1e6, prominence = 0.1 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/peaks-troughs`, {
      samples: signal,
      sample_rate,
    }, {
      params: { prominence },
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Peak detection error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/peak
 * @desc    Edit peak/crest amplitude
 * @access  Private
 */
router.post('/edit/peak', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, edits, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (!edits || !Array.isArray(edits)) {
      return res.status(400).json({ error: 'Edits array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/peak`, {
      signal,
      edits,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Peak edit error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/frequency-shift
 * @desc    Shift frequency components
 * @access  Private
 */
router.post('/edit/frequency-shift', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, frequency_shift, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (typeof frequency_shift !== 'number') {
      return res.status(400).json({ error: 'Frequency shift (Hz) required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/frequency-shift`, {
      signal,
      frequency_shift,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Frequency shift error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/wavelength
 * @desc    Adjust wavelength (stretch/compress)
 * @access  Private
 */
router.post('/edit/wavelength', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, stretch_factor, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (typeof stretch_factor !== 'number' || stretch_factor <= 0) {
      return res.status(400).json({ error: 'Stretch factor must be positive number' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/wavelength`, {
      signal,
      stretch_factor,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Wavelength adjustment error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/phase
 * @desc    Adjust phase
 * @access  Private
 */
router.post('/edit/phase', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, phase_shift_radians, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (typeof phase_shift_radians !== 'number') {
      return res.status(400).json({ error: 'Phase shift (radians) required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/phase`, {
      signal,
      phase_shift_radians,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Phase shift error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/remove-harmonic
 * @desc    Remove specific frequency component
 * @access  Private
 */
router.post('/edit/remove-harmonic', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, target_frequency, bandwidth = 10000, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (typeof target_frequency !== 'number') {
      return res.status(400).json({ error: 'Target frequency (Hz) required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/remove-harmonic`, {
      signal,
      target_frequency,
      bandwidth,
      action: 'remove',
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Harmonic removal error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/enhance-harmonic
 * @desc    Enhance specific frequency component
 * @access  Private
 */
router.post('/edit/enhance-harmonic', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, target_frequency, bandwidth = 50000, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (typeof target_frequency !== 'number') {
      return res.status(400).json({ error: 'Target frequency (Hz) required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/enhance-harmonic`, {
      signal,
      target_frequency,
      bandwidth,
      action: 'enhance',
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Harmonic enhancement error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/edit/batch
 * @desc    Apply multiple edits sequentially
 * @access  Private
 * @body    {
 *            signal: [float],
 *            edits: [
 *              {type: 'peak', index: int, new_value: float},
 *              {type: 'frequency_shift', amount: float},
 *              {type: 'wavelength', factor: float},
 *              ...
 *            ],
 *            sample_rate: float
 *          }
 */
router.post('/edit/batch', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, edits, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (!edits || !Array.isArray(edits)) {
      return res.status(400).json({ error: 'Edits array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/edit/batch`, {
      signal,
      edits,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Batch edits error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/capture
 * @desc    Capture and store signal for replay
 * @access  Private
 */
router.post('/capture', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, signal_id, metadata, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    if (!signal_id || typeof signal_id !== 'string') {
      return res.status(400).json({ error: 'Signal ID required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/capture`, {
      signal,
      signal_id,
      metadata,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Signal capture error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/replay
 * @desc    Replay captured signal with modifications
 * @access  Private
 */
router.post('/replay', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal_id, repetitions = 1, modifications, sample_rate = 1e6 } = req.body;
    
    if (!signal_id || typeof signal_id !== 'string') {
      return res.status(400).json({ error: 'Signal ID required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/replay`, {
      signal_id,
      repetitions,
      modifications,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('Signal replay error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   GET /api/v1/signal/captured
 * @desc    List all captured signals
 * @access  Private
 */
router.get('/captured', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const response = await axios.get(`${PYTHON_BACKEND}/api/v1/sdr/signal/captured`);
    
    res.json(response.data);
  } catch (err) {
    console.error('List captured signals error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/v1/signal/export/json
 * @desc    Export signal as JSON
 * @access  Private
 */
router.post('/export/json', authenticate, authorize(['operator', 'analyst', 'lead', 'admin']), async (req, res) => {
  try {
    const { signal, sample_rate = 1e6 } = req.body;
    
    if (!signal || !Array.isArray(signal)) {
      return res.status(400).json({ error: 'Signal array required' });
    }
    
    const response = await axios.post(`${PYTHON_BACKEND}/api/v1/sdr/signal/export/json`, {
      samples: signal,
      sample_rate,
    });
    
    res.json(response.data);
  } catch (err) {
    console.error('JSON export error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   GET /api/v1/signal/health
 * @desc    Check signal processing health
 * @access  Public
 */
router.get('/health', async (req, res) => {
  try {
    const response = await axios.get(`${PYTHON_BACKEND}/api/v1/sdr/signal/health`);
    res.json(response.data);
  } catch (err) {
    res.status(503).json({ error: 'Signal processing backend unavailable' });
  }
});

module.exports = router;
