'use strict';
const crypto = require('crypto');

function hashPassword(password, salt = crypto.randomBytes(16)) {
  const key = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

function verifyPassword(password, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const salt = Buffer.from(parts[1], 'base64');
  const expected = Buffer.from(parts[2], 'base64');
  const actual = crypto.scryptSync(String(password), salt, expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

// Minimal HMAC-signed bearer tokens: base64url(payload).base64url(hmac).
function createTokenService(secret, ttlMs = 12 * 60 * 60 * 1000) {
  const sign = (body) =>
    crypto.createHmac('sha256', secret).update(body).digest('base64url');

  return {
    issue(username) {
      const body = Buffer.from(
        JSON.stringify({ sub: username, exp: Date.now() + ttlMs })
      ).toString('base64url');
      return `${body}.${sign(body)}`;
    },
    verify(token) {
      if (typeof token !== 'string') return null;
      const dot = token.indexOf('.');
      if (dot < 1) return null;
      const body = token.slice(0, dot);
      const sig = token.slice(dot + 1);
      const expected = sign(body);
      if (sig.length !== expected.length) return null;
      if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
      let payload;
      try {
        payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
      } catch {
        return null;
      }
      if (typeof payload.exp !== 'number' || payload.exp < Date.now()) return null;
      return typeof payload.sub === 'string' ? payload.sub : null;
    },
  };
}

module.exports = { hashPassword, verifyPassword, createTokenService };
