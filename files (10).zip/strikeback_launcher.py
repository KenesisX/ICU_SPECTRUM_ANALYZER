#!/usr/bin/env python3
"""
STRIKEBACK COMMAND CENTER - Windows Launcher
Single-file executable that serves the app locally
"""

import os
import sys
import webbrowser
import threading
import time
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler

# Configuration
PORT = 8888
HOST = "127.0.0.1"
APP_NAME = "STRIKEBACK Command Center"


class StrikebackHTTPHandler(SimpleHTTPRequestHandler):
    """Custom HTTP handler with proper MIME types"""

    def end_headers(self):
        """Add security and cache headers"""
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, format, *args):
        """Suppress default logging"""
        pass


def find_html_file():
    """Find the HTML app file"""
    possible_names = [
        "strikeback_unified_command_center.html",
        "index.html",
    ]

    for name in possible_names:
        if Path(name).exists():
            return name

    # Check if running from a PyInstaller bundle
    if getattr(sys, "frozen", False):
        bundle_dir = Path(sys._MEIPASS)
        for name in possible_names:
            if (bundle_dir / name).exists():
                return str(bundle_dir / name)

    raise FileNotFoundError(
        f"Could not find HTML app file. Expected one of: {possible_names}"
    )


def start_server(app_file):
    """Start local HTTP server"""
    # Change to app directory
    app_dir = Path(app_file).parent
    os.chdir(app_dir)

    # Create server
    server = HTTPServer((HOST, PORT), StrikebackHTTPHandler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    return server


def main():
    """Main entry point"""
    print(f"\n{'='*60}")
    print(f"  {APP_NAME}")
    print(f"  Launching on http://{HOST}:{PORT}")
    print(f"{'='*60}\n")

    try:
        # Find HTML file
        print("[*] Locating application files...")
        html_file = find_html_file()
        print(f"[✓] Found: {html_file}")

        # Start server
        print("[*] Starting local server...")
        server = start_server(html_file)
        print(f"[✓] Server running on http://{HOST}:{PORT}")

        # Wait for server to start
        time.sleep(1)

        # Open browser
        print("[*] Opening browser...")
        url = f"http://{HOST}:{PORT}/{Path(html_file).name}"
        webbrowser.open(url)
        print(f"[✓] Launched: {url}")

        print("\n[*] Server running. Close this window to stop.\n")

        # Keep running
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\n\n[*] Shutting down...")
        sys.exit(0)

    except FileNotFoundError as e:
        print(f"\n[!] ERROR: {e}")
        print("\n[!] Make sure strikeback_unified_command_center.html is in the same folder.")
        input("\nPress Enter to exit...")
        sys.exit(1)

    except Exception as e:
        print(f"\n[!] ERROR: {e}")
        input("\nPress Enter to exit...")
        sys.exit(1)


if __name__ == "__main__":
    main()
