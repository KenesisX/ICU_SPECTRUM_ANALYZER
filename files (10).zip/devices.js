'use strict';
// Device registry for ESP32 nodes connected over WebSocket.

const ALLOWED_COMMANDS = new Set(['led_on', 'led_off', 'reboot']);

function createRegistry() {
  const devices = new Map(); // id -> { id, socket, status, lastAck, lastSeen, online }

  function ensure(id) {
    if (!devices.has(id)) {
      devices.set(id, { id, socket: null, status: {}, lastAck: null, lastSeen: null, online: false });
    }
    return devices.get(id);
  }

  return {
    attach(id, client) {
      const d = ensure(id);
      if (d.socket && d.socket !== client) d.socket.close(1000);
      d.socket = client;
      d.online = true;
      d.lastSeen = Date.now();
      return d;
    },
    detach(client) {
      for (const d of devices.values()) {
        if (d.socket === client) {
          d.socket = null;
          d.online = false;
        }
      }
    },
    update(id, fields) {
      const d = ensure(id);
      d.lastSeen = Date.now();
      Object.assign(d.status, fields);
      return d;
    },
    recordAck(id, command) {
      const d = ensure(id);
      d.lastAck = { command, at: Date.now() };
      return d;
    },
    list() {
      return [...devices.values()].map(({ id, status, lastAck, lastSeen, online }) => ({
        id, status, lastAck, lastSeen, online,
      }));
    },
    get(id) {
      return devices.get(id) || null;
    },
    // Returns { ok, error } so callers can report failures without throwing.
    sendCommand(id, command) {
      if (!ALLOWED_COMMANDS.has(command)) return { ok: false, error: 'command not allowed' };
      const d = devices.get(id);
      if (!d) return { ok: false, error: 'unknown device' };
      if (!d.online || !d.socket) return { ok: false, error: 'device offline' };
      d.socket.send(JSON.stringify({ command }));
      return { ok: true };
    },
  };
}

module.exports = { createRegistry, ALLOWED_COMMANDS };
