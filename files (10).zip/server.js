#!/usr/bin/env node
'use strict';
// Entry point. Refuses to start without explicit secrets: there are no defaults.
const { createApp } = require('./src/app');
const { hashPassword } = require('./src/auth');

function required(name, minLength) {
  const v = process.env[name];
  if (!v || v.length < minLength) {
    console.error(`${name} is required (min ${minLength} chars). See .env.example.`);
    process.exit(1);
  }
  return v;
}

const config = {
  adminUsername: process.env.ICU_ADMIN_USER || 'admin',
  adminPasswordHash: hashPassword(required('ICU_ADMIN_PASSWORD', 12)),
  tokenSecret: required('ICU_SECRET', 32),
  deviceToken: required('ICU_DEVICE_TOKEN', 24),
};

const port = Number(process.env.PORT || 5000);
const host = process.env.HOST || '0.0.0.0';
const { server } = createApp(config);

server.listen(port, host, () => {
  console.log(`ICU API listening on http://${host}:${port}`);
});

function shutdown() {
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
