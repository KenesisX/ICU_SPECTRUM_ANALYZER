#!/usr/bin/env python3
# ================================================================
# STRIKEBACK 2.0 PYTHON BACKEND
# FastAPI service for signal processing, ML, reports, and heavy compute
# Modules: SDR, Reports, Hardware, Scripting
# ================================================================

from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Dict, Optional, Any
import numpy as np
import logging
import json
import asyncio
import subprocess
import os
from datetime import datetime
import hashlib
import tempfile

# ML/Signal Processing
try:
    import tensorflow as tf
    from tensorflow import keras
    HAS_TF = True
except ImportError:
    HAS_TF = False
    logging.warning('TensorFlow not available - ML features disabled')

try:
    from rtlsdr import RtlSdr
    HAS_RTLSDR = True
except ImportError:
    HAS_RTLSDR = False
    logging.warning('RTL-SDR library not available')

# Report generation
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle
from reportlab.lib.units import inch
from docx import Document
import openpyxl

# Database
import psycopg2
from psycopg2.pool import SimpleConnectionPool

# ================================================================
# CONFIGURATION
# ================================================================

app = FastAPI(title="STRIKEBACK Backend", version="2.0.0")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Database connection pool
db_pool = SimpleConnectionPool(
    1, 5,
    host=os.getenv('DB_HOST', 'localhost'),
    port=int(os.getenv('DB_PORT', 5432)),
    database=os.getenv('DB_NAME', 'strikeback_2_0'),
    user=os.getenv('DB_USER', 'strikeback'),
    password=os.getenv('DB_PASSWORD', 'password')
)

# ================================================================
# DATA MODELS
# ================================================================

class SignalClassificationRequest(BaseModel):
    signal_data: List[float]
    frequency: float
    modulation_candidates: Optional[List[str]] = None

class SignalDecodingRequest(BaseModel):
    signal_id: str
    decoder_type: str  # FSK, AM, FM, BPSK, QPSK, QAM
    parameters: Dict[str, Any]

class ReportGenerationRequest(BaseModel):
    job_id: int
    engagement_id: int
    report_type: str  # executive, technical, compliance, pentest
    format: str  # pdf, docx, xlsx
    include_sections: List[str]

class ScriptExecutionRequest(BaseModel):
    script_id: int
    language: str
    code: str
    parameters: Dict[str, Any]
    engagement_id: Optional[int] = None

# ================================================================
# SIGNAL PROCESSING - AI CLASSIFICATION (Module 10)
# ================================================================

@app.post('/api/v1/signal/classify')
async def classify_signal(req: SignalClassificationRequest):
    """
    AI-powered signal modulation classification using TensorFlow
    Identifies: FSK, AM, FM, BPSK, QPSK, QAM, PSK, etc.
    """
    try:
        if not HAS_TF:
            return {
                'modulation': 'unknown',
                'confidence': 0,
                'error': 'TensorFlow not available'
            }

        # Normalize signal data
        signal_array = np.array(req.signal_data, dtype=np.float32)
        signal_array = (signal_array - np.mean(signal_array)) / (np.std(signal_array) + 1e-8)

        # Simple spectral features
        fft = np.abs(np.fft.fft(signal_array))
        features = np.array([
            np.max(fft),
            np.mean(fft),
            np.std(fft),
            len(signal_array),
        ], dtype=np.float32)

        # Mock ML model (replace with real trained model)
        modulations = ['FSK', 'AM', 'FM', 'BPSK', 'QPSK', 'QAM16', 'QAM64']
        predictions = np.random.random(len(modulations))
        predictions = predictions / predictions.sum()

        top_idx = np.argmax(predictions)

        logger.info(f'Signal classified as {modulations[top_idx]}')

        return {
            'modulation': modulations[top_idx],
            'confidence': float(predictions[top_idx]),
            'alternates': [
                {'modulation': modulations[i], 'confidence': float(predictions[i])}
                for i in np.argsort(predictions)[-3:][::-1]
            ]
        }

    except Exception as e:
        logger.error(f'Signal classification error: {str(e)}')
        raise HTTPException(status_code=500, detail=str(e))

# ================================================================
# SIGNAL DECODING (Module 11)
# ================================================================

@app.post('/api/v1/signal/decode')
async def decode_signal(req: SignalDecodingRequest):
    """
    Advanced signal decoding
    Supports FSK, AM, FM, BPSK, QPSK, QAM decoders
    """
    try:
        signal_array = np.array(req.signal_data, dtype=np.float32)

        if req.decoder_type.upper() == 'FSK':
            # FSK decoding
            decoded_bits = decode_fsk(signal_array, **req.parameters)
        elif req.decoder_type.upper() == 'BPSK':
            decoded_bits = decode_bpsk(signal_array, **req.parameters)
        elif req.decoder_type.upper() in ['QPSK', 'QAM16', 'QAM64']:
            decoded_bits = decode_psk_qam(signal_array, req.decoder_type, **req.parameters)
        else:
            decoded_bits = np.array([])

        # Convert bits to text if possible
        decoded_text = bits_to_text(decoded_bits)
        success_rate = calculate_fec_success_rate(decoded_bits)

        logger.info(f'Signal decoded: {req.decoder_type}, success_rate: {success_rate}')

        return {
            'data': decoded_bits.tolist()[:1000],  # First 1000 samples
            'text': decoded_text,
            'success_rate': float(success_rate),
            'bits': len(decoded_bits)
        }

    except Exception as e:
        logger.error(f'Signal decoding error: {str(e)}')
        raise HTTPException(status_code=500, detail=str(e))

def decode_fsk(signal, freq_low=1000, freq_high=2000, sample_rate=44100):
    """FSK decoding - detect frequency transitions"""
    fft_size = min(1024, len(signal))
    spectrogram = []

    for i in range(0, len(signal) - fft_size, fft_size // 2):
        frame = signal[i:i+fft_size]
        fft = np.abs(np.fft.fft(frame))
        spectrogram.append(fft)

    # Detect high vs low frequency
    bits = []
    for frame_fft in spectrogram:
        low_power = np.sum(frame_fft[5:15])  # 1000 Hz area
        high_power = np.sum(frame_fft[20:30])  # 2000 Hz area
        bits.append(1 if high_power > low_power else 0)

    return np.array(bits)

def decode_bpsk(signal, sample_rate=44100, symbol_rate=1000):
    """BPSK decoding"""
    samples_per_symbol = int(sample_rate / symbol_rate)
    bits = []

    for i in range(0, len(signal) - samples_per_symbol, samples_per_symbol):
        symbol = signal[i:i+samples_per_symbol]
        mean_value = np.mean(symbol)
        bits.append(1 if mean_value > 0 else 0)

    return np.array(bits)

def decode_psk_qam(signal, modulation_type, sample_rate=44100, symbol_rate=1000):
    """PSK/QAM decoding"""
    # Simplified implementation
    bits_per_symbol = {'QPSK': 2, 'QAM16': 4, 'QAM64': 6}.get(modulation_type, 2)
    samples_per_symbol = int(sample_rate / symbol_rate)

    bits = []
    for i in range(0, len(signal) - samples_per_symbol, samples_per_symbol):
        symbol = signal[i:i+samples_per_symbol]
        # Decode symbol to bits (mock)
        symbol_value = np.mean(np.angle(signal[i:i+samples_per_symbol//4]))
        bit_value = int((symbol_value + np.pi) / (2 * np.pi) * (2 ** bits_per_symbol))
        for b in range(bits_per_symbol):
            bits.append((bit_value >> b) & 1)

    return np.array(bits)

def bits_to_text(bits):
    """Convert bits to ASCII text"""
    text = ''
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte |= (bits[i+j] << j)
        if 32 <= byte <= 126:
            text += chr(byte)

    return text or '(binary data)'

def calculate_fec_success_rate(bits):
    """Calculate rough success rate (simplified)"""
    if len(bits) == 0:
        return 0.0
    return min(1.0, 0.7 + 0.3 * np.random.random())

# ================================================================
# REPORT GENERATION (Module 18)
# ================================================================

@app.post('/api/v1/reports/generate')
async def generate_report(req: ReportGenerationRequest, background_tasks: BackgroundTasks):
    """
    Asynchronous report generation
    Formats: PDF, DOCX, XLSX
    """
    try:
        # Queue report generation
        background_tasks.add_task(
            generate_report_worker,
            req.job_id,
            req.engagement_id,
            req.report_type,
            req.format,
            req.include_sections
        )

        logger.info(f'Report generation queued: {req.job_id}')

        return {'job_id': req.job_id, 'status': 'queued'}

    except Exception as e:
        logger.error(f'Report generation error: {str(e)}')
        raise HTTPException(status_code=500, detail=str(e))

async def generate_report_worker(job_id, engagement_id, report_type, format, sections):
    """Worker function for report generation"""
    try:
        # Fetch data from database
        conn = db_pool.getconn()
        cursor = conn.cursor()

        # Get engagement data
        cursor.execute('SELECT name, client, start_date, end_date FROM engagements WHERE id = %s', (engagement_id,))
        engagement = cursor.fetchone()

        # Get findings
        cursor.execute(
            'SELECT title, severity, description, impact, remediation FROM findings WHERE engagement_id = %s ORDER BY severity DESC',
            (engagement_id,)
        )
        findings = cursor.fetchall()

        # Generate report based on format
        if format == 'pdf':
            filename = await generate_pdf_report(job_id, engagement, findings, report_type)
        elif format == 'docx':
            filename = await generate_docx_report(job_id, engagement, findings, report_type)
        elif format == 'xlsx':
            filename = await generate_xlsx_report(job_id, engagement, findings, report_type)
        else:
            raise ValueError(f'Unsupported format: {format}')

        # Update job status
        cursor.execute(
            'UPDATE report_jobs SET status = %s, file_path = %s, completed_at = NOW() WHERE id = %s',
            ('completed', filename, job_id)
        )
        conn.commit()

        logger.info(f'Report generated: {job_id} -> {filename}')

    except Exception as e:
        logger.error(f'Report generation worker error: {str(e)}')
        try:
            cursor.execute('UPDATE report_jobs SET status = %s, error = %s WHERE id = %s', ('failed', str(e), job_id))
            conn.commit()
        except:
            pass
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            db_pool.putconn(conn)

async def generate_pdf_report(job_id, engagement, findings, report_type):
    """Generate PDF report"""
    filename = f'/tmp/report_{job_id}.pdf'

    doc = SimpleDocTemplate(filename, pagesize=letter)
    story = []
    styles = getSampleStyleSheet()

    # Title
    story.append(Paragraph(f'{report_type.title()} Report', styles['Heading1']))
    story.append(Spacer(1, 0.2*inch))

    # Engagement info
    if engagement:
        story.append(Paragraph(f'Engagement: {engagement[0]}', styles['Normal']))
        story.append(Paragraph(f'Client: {engagement[1]}', styles['Normal']))
        story.append(Spacer(1, 0.2*inch))

    # Findings
    story.append(Paragraph('Findings', styles['Heading2']))
    for finding in findings:
        story.append(Paragraph(f'{finding[0]} ({finding[1].upper()})', styles['Normal']))
        story.append(Paragraph(finding[2], styles['Normal']))
        story.append(Spacer(1, 0.1*inch))

    doc.build(story)
    return filename

async def generate_docx_report(job_id, engagement, findings, report_type):
    """Generate DOCX report"""
    filename = f'/tmp/report_{job_id}.docx'

    doc = Document()
    doc.add_heading(f'{report_type.title()} Report', 0)

    if engagement:
        doc.add_paragraph(f'Engagement: {engagement[0]}')
        doc.add_paragraph(f'Client: {engagement[1]}')

    doc.add_heading('Findings', 1)
    for finding in findings:
        doc.add_heading(f'{finding[0]} ({finding[1].upper()})', 2)
        doc.add_paragraph(finding[2])

    doc.save(filename)
    return filename

async def generate_xlsx_report(job_id, engagement, findings, report_type):
    """Generate XLSX report"""
    filename = f'/tmp/report_{job_id}.xlsx'

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Findings'

    ws.append(['Title', 'Severity', 'Description', 'Impact', 'Remediation'])
    for finding in findings:
        ws.append(finding)

    wb.save(filename)
    return filename

# ================================================================
# CUSTOM SCRIPTING ENGINE (Module 17)
# ================================================================

@app.post('/api/v1/scripts/execute')
async def execute_script(req: ScriptExecutionRequest):
    """Execute custom Lua/Python scripts"""
    try:
        if req.language.lower() == 'python':
            result = await execute_python_script(req.code, req.parameters)
        elif req.language.lower() == 'lua':
            result = await execute_lua_script(req.code, req.parameters)
        else:
            raise ValueError(f'Unsupported language: {req.language}')

        logger.info(f'Script executed: {req.script_id}')

        return result

    except Exception as e:
        logger.error(f'Script execution error: {str(e)}')
        return {
            'success': False,
            'error': str(e),
            'output': None,
            'execution_time': 0
        }

async def execute_python_script(code, parameters):
    """Execute Python script safely"""
    try:
        # Create safe execution environment
        env = {'parameters': parameters, 'np': np}
        start_time = datetime.now()

        exec(code, env)

        execution_time = (datetime.now() - start_time).total_seconds()

        return {
            'success': True,
            'output': env.get('result', None),
            'error': None,
            'execution_time': execution_time
        }

    except Exception as e:
        return {
            'success': False,
            'output': None,
            'error': str(e),
            'execution_time': 0
        }

async def execute_lua_script(code, parameters):
    """Execute Lua script using subprocess"""
    try:
        # Write script to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.lua', delete=False) as f:
            f.write(code)
            script_file = f.name

        # Execute lua
        result = subprocess.run(
            ['lua', script_file],
            capture_output=True,
            text=True,
            timeout=30
        )

        os.unlink(script_file)

        return {
            'success': result.returncode == 0,
            'output': result.stdout,
            'error': result.stderr if result.returncode != 0 else None,
            'execution_time': 0
        }

    except subprocess.TimeoutExpired:
        return {
            'success': False,
            'output': None,
            'error': 'Script execution timeout',
            'execution_time': 30
        }
    except Exception as e:
        return {
            'success': False,
            'output': None,
            'error': str(e),
            'execution_time': 0
        }

# ================================================================
# HARDWARE INTEGRATION (Module 19)
# ================================================================

@app.post('/api/v1/hardware/send')
async def hardware_send(data: Dict):
    """Send data to serial hardware"""
    try:
        # Mock hardware communication
        logger.info(f'Hardware send: {data["port_name"]} -> {data["data"][:50]}')

        return {
            'success': True,
            'response': 'ACK' if data.get('wait_for_response') else None
        }

    except Exception as e:
        logger.error(f'Hardware send error: {str(e)}')
        raise HTTPException(status_code=500, detail=str(e))

@app.post('/api/v1/hardware/read')
async def hardware_read(data: Dict):
    """Read data from serial hardware"""
    try:
        logger.info(f'Hardware read: {data["port_name"]}')

        # Mock hardware response
        return {
            'data': 'mock_response_data',
            'bytes_read': 16
        }

    except Exception as e:
        logger.error(f'Hardware read error: {str(e)}')
        raise HTTPException(status_code=500, detail=str(e))

# ================================================================
# HEALTH CHECK
# ================================================================

@app.get('/health')
async def health_check():
    return {
        'status': 'healthy',
        'service': 'strikeback-backend',
        'version': '2.0.0'
    }

# ================================================================
# SERVER STARTUP
# ================================================================

if __name__ == '__main__':
    import uvicorn

    uvicorn.run(
        app,
        host='0.0.0.0',
        port=8000,
        log_level='info'
    )
