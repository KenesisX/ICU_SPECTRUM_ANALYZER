# 🚀 STRIKEBACK WINDOWS BUILD — Quick Reference

Two ways to build a Windows executable. Pick one.

---

## 🏃 FASTEST METHOD (Recommended)

### PyInstaller — 5 Minute Build

**What you need:**
- Python 3.8+ (https://python.org)

**Files:**
- `strikeback_unified_command_center.html` (the app)
- `strikeback_launcher.py` (launcher)

**Build:**
```cmd
pip install pyinstaller
pyinstaller --onefile strikeback_launcher.py
```

**Output:**
- Single `.exe` file (~50 MB)
- No installation needed
- Double-click to run

**See:** `WINDOWS_PYINSTALLER_BUILD.md` for full details

---

## ⚡ PROFESSIONAL METHOD

### Electron — Full-Featured Build

**What you need:**
- Node.js + npm (https://nodejs.org)

**Files:**
- `strikeback_unified_command_center.html` (the app)
- `electron-main.js`
- `electron-preload.js`
- `electron-package.json` (rename to `package.json`)

**Build:**
```cmd
npm install
npm run build-win
```

**Output:**
- Two `.exe` files:
  - **NSIS Installer** (~120 MB) — Full installer with uninstaller
  - **Portable** (~150 MB) — No installation required
- Customizable icons, shortcuts, etc.

**See:** `WINDOWS_DESKTOP_BUILD.md` for full details

---

## 📊 Comparison

| Aspect | PyInstaller | Electron |
|--------|-------------|----------|
| **Setup Time** | 2 min | 5 min |
| **Build Time** | < 1 min | 3 min |
| **File Size** | 50 MB | 150 MB |
| **Dependencies** | Python only | Node.js + npm |
| **Customization** | Limited | High |
| **Ease** | ★★★★★ | ★★★★ |
| **Best For** | Quick distribution | Corporate deployments |

---

## ⚡ If You Want Speed

Use **PyInstaller**:

```cmd
pip install pyinstaller
pyinstaller --onefile strikeback_launcher.py
```

Your `.exe` is done in < 1 minute.

---

## 🏢 If You Need Professional Features

Use **Electron**:

```cmd
npm install
npm run build-win
```

You get:
- Professional installer with uninstaller
- Start Menu shortcuts
- Custom icons
- Desktop shortcuts
- Auto-updates capability

---

## 📦 Distribution

### PyInstaller Output
```
dist/STRIKEBACK Command Center.exe (50 MB)
→ Share directly via email, cloud storage, etc.
→ User downloads and runs
→ Works immediately
```

### Electron Output
```
dist/STRIKEBACK-Command-Center-Setup-1.0.0.exe (120 MB)
   ↓ Professional installer
dist/STRIKEBACK-Command-Center-1.0.0-portable.exe (150 MB)
   ↓ Portable (no installation)
```

---

## 📋 Folder Structure

For PyInstaller:
```
C:\strikeback-build\
  ├── strikeback_unified_command_center.html
  ├── strikeback_launcher.py
  └── [icon.ico - optional]
```

For Electron:
```
C:\strikeback-build\
  ├── strikeback_unified_command_center.html
  ├── electron-main.js
  ├── electron-preload.js
  ├── package.json
  ├── assets/
  │   └── icon.ico
  └── [node_modules - auto-created]
```

---

## 🎯 My Recommendation

**For Strikeback Tech:**

1. **For internal team use:** PyInstaller
   - Single .exe
   - Works on any Windows machine
   - Easy to update

2. **For client distribution:** Electron
   - Professional installer
   - Auto-updates
   - Custom branding

---

## ✅ Checklist

PyInstaller:
- [ ] Python 3.8+ installed
- [ ] `strikeback_launcher.py` in folder
- [ ] `strikeback_unified_command_center.html` in folder
- [ ] Run: `pip install pyinstaller`
- [ ] Run: `pyinstaller --onefile strikeback_launcher.py`

Electron:
- [ ] Node.js installed
- [ ] `electron-main.js` in folder
- [ ] `electron-preload.js` in folder
- [ ] `package.json` (renamed from electron-package.json)
- [ ] `strikeback_unified_command_center.html` in folder
- [ ] Run: `npm install`
- [ ] Run: `npm run build-win`

---

## 🔗 Files in This Package

- `strikeback_unified_command_center.html` — Main app (updated with smaller console)
- `strikeback_launcher.py` — Python launcher (PyInstaller method)
- `electron-main.js` — Electron launcher
- `electron-preload.js` — Electron security layer
- `electron-package.json` → rename to `package.json` for Electron build
- `WINDOWS_PYINSTALLER_BUILD.md` — Full PyInstaller guide
- `WINDOWS_DESKTOP_BUILD.md` — Full Electron guide
- `WINDOWS_BUILD_QUICK_REFERENCE.md` — This file

---

## 🚀 Get Started

1. **Choose your method** (PyInstaller = faster, Electron = more features)
2. **Read the full guide** (WINDOWS_PYINSTALLER_BUILD.md or WINDOWS_DESKTOP_BUILD.md)
3. **Gather files** and follow build steps
4. **Share the .exe** with your team

Questions? Each guide has detailed troubleshooting sections.

**You're 5 minutes away from a standalone Windows app.** 🎯
