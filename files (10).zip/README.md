# ICU Platform

| Component | Path | How it is built | Verified here |
|---|---|---|---|
| Node API (auth, devices, signal tools) | `api/` | `npm test` / `npm start` | Yes: 19/19 tests pass against a live server |
| Android app (`.apk`, `.aab`) | `android/` | CI (Gradle 8.7) or `gradle assembleRelease bundleRelease` | No: not compiled |
| ESP32 firmware (`.bin`) | `esp32/` | CI (PlatformIO) or `pio run` | No: not compiled |
| Raspberry Pi image (`.img.xz`) | `pi-image/` | CI, manual trigger (pi-gen) | No: not built |
| Windows launcher (`.exe`) | `windows-launcher/` | CI (PyInstaller on Windows) | No: not built |
| Release automation | `.github/workflows/build.yml` | Runs on push, tag, or manual dispatch | Not yet run |

`legacy-unverified/` holds everything from earlier sessions that was never compiled or tested. It is
not part of the product above — see `legacy-unverified/README.md`.

## Get the binaries

1. Push this repo to GitHub.
2. Add the secrets listed in `.github/workflows/build.yml` (`ICU_KEYSTORE_B64`, `ICU_KEYSTORE_PASS`,
   `ICU_KEY_ALIAS`, `ICU_KEY_PASS`, `PI_FIRST_USER_PASS`).
3. Run the workflow manually, or push a `v*` tag to get a release with the APK, AAB, firmware `.bin`,
   and `.exe` attached.
4. Send any failing build log back for a fix — none of these builds have been run yet.

Signing keys, Play Console account, and WiFi credentials are yours to supply; none are in this repo.

## Google Play

See `GOOGLE_PLAY_CHECKLIST.md` for the full submission path, `STORE_LISTING.md` for draft listing copy
(and a real policy-risk note worth reading before you write your own), and `PRIVACY_POLICY.md` for the
required privacy policy text — you'll need to host that at a public URL and fill in the two blanks
before submitting.
