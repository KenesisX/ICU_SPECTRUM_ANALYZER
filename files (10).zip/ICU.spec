# Build on Windows:  pyinstaller --noconfirm ICU.spec   -> dist\ICU.exe
# Bundles the Node API (server.js + src/) next to the exe. Node.js must be on the PATH of the
# target machine, because the API is JavaScript and is not compiled into the exe.
block_cipher = None

a = Analysis(
    ['launcher.py'],
    pathex=[],
    datas=[
        ('../api/server.js', '.'),
        ('../api/package.json', '.'),
        ('../api/src', 'src'),
    ],
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    cipher=block_cipher,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name='ICU',
    console=True,
    upx=False,
)
