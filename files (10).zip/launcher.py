"""ICU Windows launcher.

Starts the bundled Node API and opens the web UI. Needs Node.js on PATH.
The API refuses to start without its secrets, so create api/.env next to the exe
(see api/.env.example) before running.
"""
import os
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

PORT = os.environ.get("PORT", "5000")
URL = f"http://localhost:{PORT}"


def base_dir() -> Path:
    # PyInstaller unpacks bundled files to sys._MEIPASS; otherwise use the script folder.
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))


def find_node() -> str | None:
    return shutil.which("node")


def main() -> int:
    node = find_node()
    if node is None:
        print("Node.js was not found on PATH. Install Node.js 18+ from https://nodejs.org and try again.")
        input("Press Enter to exit...")
        return 1

    server = base_dir() / "server.js"
    env = dict(os.environ, PORT=PORT)
    proc = subprocess.Popen([node, str(server)], cwd=str(base_dir()), env=env)
    time.sleep(2)
    webbrowser.open(URL)
    print(f"ICU running at {URL}. Close this window to stop.")
    try:
        proc.wait()
    except KeyboardInterrupt:
        pass
    finally:
        if proc.poll() is None:
            proc.terminate()
    return proc.returncode or 0


if __name__ == "__main__":
    sys.exit(main())
