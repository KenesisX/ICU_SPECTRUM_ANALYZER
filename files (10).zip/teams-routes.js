// ================================================================
// TEAM COLLABORATION & E2E ENCRYPTED MESSAGING
// Module 2: Team Collaboration
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// TEAMS CRUD
// ================================================================

router.post('/', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const { name, description, members } = req.body;

    const result = await db.query(
      `INSERT INTO teams (name, description, created_by)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [name, description, req.user.id],
    );

    const teamId = result.rows[0].id;

    // Add creator as admin
    await db.query(
      'INSERT INTO team_members (team_id, user_id, role) VALUES ($1, $2, $3)',
      [teamId, req.user.id, 'admin'],
    );

    // Add other members
    if (members && members.length > 0) {
      for (const memberId of members) {
        await db.query(
          'INSERT INTO team_members (team_id, user_id, role) VALUES ($1, $2, $3)',
          [teamId, memberId, 'member'],
        );
      }
    }

    logger.info('Team created', { teamId, createdBy: req.user.id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create team error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT DISTINCT t.* FROM teams t
       INNER JOIN team_members tm ON t.id = tm.team_id
       WHERE tm.user_id = $1
       ORDER BY t.created_at DESC`,
      [req.user.id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get teams error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:team_id/members', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT u.id, u.username, u.email, tm.role 
       FROM users u
       INNER JOIN team_members tm ON u.id = tm.user_id
       WHERE tm.team_id = $1`,
      [req.params.team_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get team members error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// E2E ENCRYPTED MESSAGING (AES-256-GCM)
// ================================================================

router.post('/:team_id/messages', authMiddleware, async (req, res) => {
  try {
    const { content, encrypted_key } = req.body; // content pre-encrypted by client

    const result = await db.query(
      `INSERT INTO messages (team_id, sender_id, content, encrypted_key)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [req.params.team_id, req.user.id, content, encrypted_key],
    );

    logger.info('Message sent', { messageId: result.rows[0].id, teamId: req.params.team_id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Send message error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:team_id/messages', authMiddleware, async (req, res) => {
  try {
    const { limit = 100, offset = 0 } = req.query;

    const result = await db.query(
      `SELECT m.*, u.username 
       FROM messages m
       INNER JOIN users u ON m.sender_id = u.id
       WHERE m.team_id = $1
       ORDER BY m.created_at DESC
       LIMIT $2 OFFSET $3`,
      [req.params.team_id, limit, offset],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get messages error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// SHARED FINDINGS & ARTIFACTS
// ================================================================

router.post('/:team_id/artifacts', authMiddleware, async (req, res) => {
  try {
    const { name, type, data_url } = req.body;

    const result = await db.query(
      `INSERT INTO team_artifacts (team_id, uploaded_by, name, type, data_url)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [req.params.team_id, req.user.id, name, type, data_url],
    );

    logger.info('Artifact uploaded', { artifactId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Upload artifact error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:team_id/artifacts', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT ta.*, u.username 
       FROM team_artifacts ta
       INNER JOIN users u ON ta.uploaded_by = u.id
       WHERE ta.team_id = $1
       ORDER BY ta.created_at DESC`,
      [req.params.team_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get artifacts error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// TEAM ROLES & PERMISSIONS
// ================================================================

router.post('/:team_id/members/:user_id', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { role } = req.body;

    const result = await db.query(
      `UPDATE team_members SET role = $1 WHERE team_id = $2 AND user_id = $3 RETURNING *`,
      [role, req.params.team_id, req.params.user_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Team member not found' });
    }

    logger.info('Team member role updated', { teamId: req.params.team_id, userId: req.params.user_id });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Update team member error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/:team_id/members/:user_id', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const result = await db.query(
      `DELETE FROM team_members WHERE team_id = $1 AND user_id = $2 RETURNING *`,
      [req.params.team_id, req.params.user_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Team member not found' });
    }

    logger.info('Team member removed', { teamId: req.params.team_id });

    res.json({ message: 'Member removed' });
  } catch (error) {
    logger.error('Remove team member error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
