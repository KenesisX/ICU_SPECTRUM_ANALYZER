// ================================================================
// STRIKEBACK 2.0 MAIN SERVER
// Updated to include all 23 modules
// ================================================================

const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');

const logger = require('./utils/logger');
const { authMiddleware } = require('./middleware/auth');
const apiRouter = require('./routes/api-router-complete');

// ================================================================
// APP INITIALIZATION
// ================================================================

const app = express();
const server = http.createServer(app);

// WebSocket Server
const io = socketIO(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || '*',
    methods: ['GET', 'POST'],
    credentials: true,
  },
  transports: ['websocket', 'polling'],
  maxHttpBufferSize: 1e8, // 100MB for large data transfers
});

// ================================================================
// MIDDLEWARE
// ================================================================

// Security
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
}));

// Compression
app.use(compression());

// Body parsing
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // limit each IP to 1000 requests per windowMs
  message: 'Too many requests, please try again later.',
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5, // Limit auth attempts
  message: 'Too many login attempts, please try again later.',
});

app.use('/api/', limiter);
app.use('/api/v1/auth/login', authLimiter);

// Logging middleware
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`, { ip: req.ip });
  next();
});

// ================================================================
// STATIC FILES
// ================================================================

app.use(express.static(path.join(__dirname, '../../frontend/build')));
app.use('/assets', express.static(path.join(__dirname, '../assets')));

// ================================================================
// API ROUTES - ALL 23 MODULES
// ================================================================

app.use('/api/v1', apiRouter);

// ================================================================
// HEALTH CHECK
// ================================================================

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '2.0.0',
    timestamp: new Date(),
  });
});

// ================================================================
// FALLBACK TO REACT APP
// ================================================================

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../../frontend/build/index.html'));
});

// ================================================================
// WEBSOCKET HANDLERS - REAL-TIME FEATURES
// ================================================================

const connectedUsers = new Map();
const roomSubscriptions = new Map();

io.on('connection', (socket) => {
  logger.info('WebSocket connected', { socketId: socket.id });

  // User authentication
  socket.on('authenticate', async (token, callback) => {
    try {
      // Verify JWT token
      const jwt = require('jsonwebtoken');
      const verified = jwt.verify(token, process.env.JWT_SECRET);

      connectedUsers.set(socket.id, {
        userId: verified.id,
        username: verified.username,
        role: verified.role,
        connectedAt: new Date(),
      });

      logger.info('WebSocket authenticated', { userId: verified.id });

      if (callback) callback({ success: true });
    } catch (error) {
      logger.error('WebSocket auth failed', { error: error.message });
      if (callback) callback({ success: false, error: 'Authentication failed' });
      socket.disconnect();
    }
  });

  // Real-time message broadcasting
  socket.on('message', (data) => {
    const user = connectedUsers.get(socket.id);
    if (user) {
      io.to(data.room).emit('message', {
        ...data,
        sender: user.username,
        timestamp: new Date(),
      });

      logger.info('Message broadcast', { room: data.room, from: user.username });
    }
  });

  // Team room subscriptions
  socket.on('subscribe', (teamId) => {
    socket.join(`team:${teamId}`);

    if (!roomSubscriptions.has(`team:${teamId}`)) {
      roomSubscriptions.set(`team:${teamId}`, []);
    }
    roomSubscriptions.get(`team:${teamId}`).push(socket.id);

    logger.info('Team subscribed', { teamId, socketId: socket.id });
  });

  socket.on('unsubscribe', (teamId) => {
    socket.leave(`team:${teamId}`);

    const subscribers = roomSubscriptions.get(`team:${teamId}`);
    if (subscribers) {
      subscribers = subscribers.filter((id) => id !== socket.id);
    }

    logger.info('Team unsubscribed', { teamId, socketId: socket.id });
  });

  // Signal data real-time streaming (for SDR module)
  socket.on('signal-data', (data) => {
    io.to(`engagement:${data.engagement_id}`).emit('signal-update', {
      frequency: data.frequency,
      power: data.power,
      phase: data.phase,
      timestamp: new Date(),
    });
  });

  // Engagement updates (for dashboard)
  socket.on('engagement-update', (data) => {
    io.to(`engagement:${data.engagement_id}`).emit('engagement-changed', data);

    logger.info('Engagement update broadcast', { engagementId: data.engagement_id });
  });

  // Finding alerts (critical findings go to all connected users in engagement)
  socket.on('finding-alert', (data) => {
    if (data.severity === 'critical') {
      io.emit('critical-finding', {
        ...data,
        timestamp: new Date(),
        alert_type: 'critical_finding',
      });

      logger.warn('Critical finding alert', { findingId: data.finding_id });
    }
  });

  // Compliance check notifications
  socket.on('compliance-check', (data) => {
    io.to(`engagement:${data.engagement_id}`).emit('compliance-update', data);
  });

  // Report generation progress
  socket.on('report-progress', (data) => {
    io.to(`engagement:${data.engagement_id}`).emit('report-status', {
      job_id: data.job_id,
      progress: data.progress,
      status: data.status,
    });
  });

  // SDR/Signal monitoring live updates
  socket.on('signal-analysis', (data) => {
    io.to(`engagement:${data.engagement_id}`).emit('analysis-update', {
      signal_id: data.signal_id,
      modulation: data.modulation,
      confidence: data.confidence,
    });
  });

  // Disconnect
  socket.on('disconnect', () => {
    const user = connectedUsers.get(socket.id);
    connectedUsers.delete(socket.id);

    // Clean up room subscriptions
    for (const [room, sockets] of roomSubscriptions.entries()) {
      const index = sockets.indexOf(socket.id);
      if (index > -1) {
        sockets.splice(index, 1);
      }
    }

    logger.info('WebSocket disconnected', { userId: user?.userId });
  });

  // Error handling
  socket.on('error', (error) => {
    logger.error('WebSocket error', { socketId: socket.id, error });
  });
});

// ================================================================
// BROADCAST UTILITIES
// ================================================================

// Broadcast to specific engagement
global.broadcastToEngagement = (engagementId, event, data) => {
  io.to(`engagement:${engagementId}`).emit(event, data);
};

// Broadcast to specific team
global.broadcastToTeam = (teamId, event, data) => {
  io.to(`team:${teamId}`).emit(event, data);
};

// Broadcast critical alert
global.broadcastCriticalAlert = (alert) => {
  io.emit('alert', {
    ...alert,
    severity: 'critical',
    timestamp: new Date(),
  });
};

// ================================================================
// ERROR HANDLING
// ================================================================

app.use((err, req, res, next) => {
  logger.error('Unhandled error', {
    error: err.message,
    stack: err.stack,
    path: req.path,
  });

  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    status: err.status || 500,
  });
});

// ================================================================
// GRACEFUL SHUTDOWN
// ================================================================

const gracefulShutdown = async () => {
  logger.info('Graceful shutdown initiated');

  server.close(() => {
    logger.info('HTTP server closed');
  });

  io.close();
  logger.info('WebSocket server closed');

  // Close database connections
  try {
    const db = require('./config/database');
    if (db.pool) {
      await db.pool.end();
      logger.info('Database pool closed');
    }
  } catch (error) {
    logger.error('Error closing database pool', { error: error.message });
  }

  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// ================================================================
// SERVER START
// ================================================================

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  logger.info(`🔥 STRIKEBACK 2.0 Backend listening on port ${PORT}`);
  logger.info(`📊 23 modules loaded and ready`);
  logger.info(`🔐 Security: JWT + RBAC enabled`);
  logger.info(`📡 WebSocket: Real-time features active`);
  logger.info(`🐳 Docker: ${process.env.DOCKER_ENABLED ? 'Enabled' : 'Disabled'}`);
});

module.exports = { app, server, io };
