#!/usr/bin/env python3
# ================================================================
# ADVANCED MODULATION CLASSIFICATION & WAVEFORM SYNTHESIS
# Module 10 Enhancement: AMC + Differentiable OFDM/OTFS Engines
# ================================================================

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, Model
import scipy.signal as signal
from typing import Tuple, List, Dict, Optional
import json
import logging

logger = logging.getLogger(__name__)

# ================================================================
# AUTOMATIC MODULATION CLASSIFICATION (AMC) MODEL
# CNN/RNN hybrid for IQ data classification
# ================================================================

class ModulationClassifier:
    """
    Advanced AMC using CNN for feature extraction + LSTM for temporal patterns
    Classifies: AM, FM, GFSK, QPSK, 16-QAM, 64-QAM, BPSK, PSK, FSK, OFDM, etc.
    """
    
    MODULATIONS = [
        'AM', 'FM', 'GFSK', 'QPSK', '16QAM', '64QAM',
        'BPSK', 'PSK4', 'PSK8', 'FSK2', 'FSK4', 'OFDM',
        'ASK', 'OOK', 'DSB', 'SSB'
    ]
    
    def __init__(self, model_path: Optional[str] = None):
        """Initialize AMC classifier"""
        if model_path:
            self.model = keras.models.load_model(model_path)
        else:
            self.model = self._build_model()
        
        logger.info('AMC Classifier initialized')
    
    def _build_model(self) -> Model:
        """
        Build CNN + LSTM hybrid model for modulation classification
        Input: IQ data arrays (batch_size, sequence_length, 2)
        Output: Modulation class probabilities
        """
        
        # Input layer: (None, 1024, 2) - 1024 IQ samples
        inputs = keras.Input(shape=(1024, 2), name='iq_input')
        
        # ================================================================
        # CNN BRANCH - Extract spectral and amplitude features
        # ================================================================
        
        # Compute spectral representation
        # FFT branch - magnitude spectrum
        x_fft = layers.Lambda(
            lambda x: tf.abs(tf.signal.fft(tf.complex(x[:, :, 0], x[:, :, 1]))),
            name='fft_magnitude'
        )(inputs)
        x_fft = layers.Reshape((512, 1))(x_fft[:, :512])  # Keep positive freqs
        
        # Conv block 1 - Low-level features
        x_conv = layers.Conv1D(64, 8, activation='relu', padding='same')(x_fft)
        x_conv = layers.BatchNormalization()(x_conv)
        x_conv = layers.MaxPooling1D(2)(x_conv)
        
        # Conv block 2
        x_conv = layers.Conv1D(128, 8, activation='relu', padding='same')(x_conv)
        x_conv = layers.BatchNormalization()(x_conv)
        x_conv = layers.MaxPooling1D(2)(x_conv)
        
        # Conv block 3
        x_conv = layers.Conv1D(256, 4, activation='relu', padding='same')(x_conv)
        x_conv = layers.BatchNormalization()(x_conv)
        x_conv = layers.GlobalMaxPooling1D()(x_conv)
        
        # ================================================================
        # RNN BRANCH - Temporal patterns in IQ data
        # ================================================================
        
        # LSTM for sequential IQ patterns
        x_lstm = layers.LSTM(128, return_sequences=True)(inputs)
        x_lstm = layers.Dropout(0.3)(x_lstm)
        x_lstm = layers.LSTM(64)(x_lstm)
        x_lstm = layers.Dropout(0.3)(x_lstm)
        
        # ================================================================
        # MERGE & CLASSIFY
        # ================================================================
        
        # Combine CNN spectral features + LSTM temporal patterns
        x_merged = layers.Concatenate()([x_conv, x_lstm])
        x_merged = layers.Dense(256, activation='relu')(x_merged)
        x_merged = layers.Dropout(0.4)(x_merged)
        x_merged = layers.Dense(128, activation='relu')(x_merged)
        x_merged = layers.Dropout(0.3)(x_merged)
        
        # Output: softmax over modulation classes
        outputs = layers.Dense(
            len(self.MODULATIONS),
            activation='softmax',
            name='modulation_output'
        )(x_merged)
        
        model = Model(inputs=inputs, outputs=outputs, name='AMC_Classifier')
        
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=1e-3),
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        logger.info(f'AMC model built: {len(self.MODULATIONS)} classes')
        return model
    
    def classify(self, iq_data: np.ndarray) -> Dict:
        """
        Classify modulation from IQ data
        
        Args:
            iq_data: (N, 2) array or (N,) complex array
            
        Returns:
            Dict with modulation, confidence, alternates
        """
        try:
            # Normalize IQ data
            if iq_data.dtype == np.complex128 or iq_data.dtype == np.complex64:
                iq_array = np.column_stack([iq_data.real, iq_data.imag])
            else:
                iq_array = iq_data
            
            # Pad/truncate to 1024 samples
            if len(iq_array) < 1024:
                iq_array = np.pad(iq_array, ((0, 1024 - len(iq_array)), (0, 0)))
            else:
                iq_array = iq_array[:1024]
            
            # Normalize
            iq_array = (iq_array - np.mean(iq_array, axis=0)) / (np.std(iq_array, axis=0) + 1e-8)
            
            # Predict
            batch = np.expand_dims(iq_array, axis=0)
            predictions = self.model.predict(batch, verbose=0)[0]
            
            # Top 3 predictions
            top_indices = np.argsort(predictions)[-3:][::-1]
            
            return {
                'modulation': self.MODULATIONS[top_indices[0]],
                'confidence': float(predictions[top_indices[0]]),
                'alternates': [
                    {
                        'modulation': self.MODULATIONS[idx],
                        'confidence': float(predictions[idx])
                    }
                    for idx in top_indices[1:]
                ],
                'all_predictions': {
                    self.MODULATIONS[i]: float(predictions[i])
                    for i in range(len(self.MODULATIONS))
                }
            }
        
        except Exception as e:
            logger.error(f'Classification error: {str(e)}')
            return {
                'modulation': 'unknown',
                'confidence': 0.0,
                'error': str(e)
            }

# ================================================================
# DIFFERENTIABLE WAVEFORM ENGINE
# OFDM/OTFS modulation with learnable parameters
# ================================================================

class DifferentiableWaveformEngine:
    """
    TensorFlow-based waveform generation for OFDM and OTFS
    Uses differentiable operations for optimization/adaptation
    """
    
    def __init__(self, sample_rate: float = 1e6, carrier_freq: float = 2.4e9):
        self.sample_rate = sample_rate
        self.carrier_freq = carrier_freq
        logger.info(f'Waveform engine initialized: {sample_rate/1e6:.1f} MS/s')
    
    # ================================================================
    # OFDM WAVEFORM GENERATION
    # ================================================================
    
    def generate_ofdm(
        self,
        data_symbols: np.ndarray,
        num_subcarriers: int = 64,
        cyclic_prefix_len: int = 16,
        modulation: str = 'QPSK'  # QPSK, 16QAM, 64QAM
    ) -> np.ndarray:
        """
        Generate OFDM waveform from data symbols
        
        Args:
            data_symbols: Modulated symbols (shape: (num_symbols,))
            num_subcarriers: Number of subcarriers
            cyclic_prefix_len: Length of cyclic prefix
            modulation: Modulation type
            
        Returns:
            Complex waveform (time-domain IQ data)
        """
        
        # Pad data symbols to fill subcarriers
        num_symbols = len(data_symbols)
        num_ofdm_frames = int(np.ceil(num_symbols / num_subcarriers))
        data_padded = np.pad(data_symbols, (0, num_ofdm_frames * num_subcarriers - num_symbols))
        
        # Reshape to frames
        frames = data_padded.reshape(num_ofdm_frames, num_subcarriers)
        
        # IFFT to time domain
        waveform = []
        for frame in frames:
            # Zero-pad center DC and Nyquist
            subcarriers = np.zeros(num_subcarriers, dtype=np.complex128)
            subcarriers[1:-1] = frame[:num_subcarriers-2]
            
            # IFFT
            time_domain = np.fft.ifft(subcarriers)
            
            # Add cyclic prefix
            cp = time_domain[-cyclic_prefix_len:]
            ofdm_symbol = np.concatenate([cp, time_domain])
            
            waveform.append(ofdm_symbol)
        
        waveform = np.concatenate(waveform)
        
        # Normalize
        peak = np.max(np.abs(waveform))
        if peak > 0:
            waveform = waveform / peak * 0.9
        
        logger.info(f'OFDM waveform generated: {len(waveform)} samples, {num_ofdm_frames} frames')
        return waveform
    
    # ================================================================
    # OTFS (Orthogonal Time Frequency Space) WAVEFORM
    # ================================================================
    
    def generate_otfs(
        self,
        data_symbols: np.ndarray,
        num_subcarriers: int = 64,
        num_ofdm_symbols: int = 14,
        modulation: str = 'QPSK'
    ) -> np.ndarray:
        """
        Generate OTFS waveform (2D time-frequency grid)
        OTFS provides better Doppler/delay robustness than OFDM
        
        Args:
            data_symbols: Modulated symbols
            num_subcarriers: Number of frequency bins
            num_ofdm_symbols: Number of time slots
            modulation: Modulation type
            
        Returns:
            Complex OTFS waveform
        """
        
        # Create 2D constellation grid (delay-Doppler domain)
        dd_grid = np.zeros((num_subcarriers, num_ofdm_symbols), dtype=np.complex128)
        
        # Map data symbols to DD grid
        num_symbols = len(data_symbols)
        symbol_idx = 0
        for m in range(num_ofdm_symbols):
            for k in range(num_subcarriers):
                if symbol_idx < num_symbols:
                    dd_grid[k, m] = data_symbols[symbol_idx]
                    symbol_idx += 1
        
        # OTFS modulation: 2D IFFT (delay-Doppler to time-frequency)
        tf_grid = np.fft.ifft2(dd_grid, axes=(0, 1))
        
        # OFDM modulation on each column (time slot)
        waveform = []
        for t in range(num_ofdm_symbols):
            subcarriers = tf_grid[:, t]
            
            # IFFT for each time slot
            time_symbol = np.fft.ifft(subcarriers)
            
            # Add cyclic prefix
            cp_len = 16
            cp = time_symbol[-cp_len:]
            ofdm_symbol = np.concatenate([cp, time_symbol])
            
            waveform.append(ofdm_symbol)
        
        waveform = np.concatenate(waveform)
        
        # Normalize
        peak = np.max(np.abs(waveform))
        if peak > 0:
            waveform = waveform / peak * 0.9
        
        logger.info(f'OTFS waveform generated: {len(waveform)} samples')
        return waveform
    
    # ================================================================
    # LEARNABLE WAVEFORM OPTIMIZATION
    # ================================================================
    
    def optimize_waveform_for_channel(
        self,
        initial_symbols: np.ndarray,
        channel_response: np.ndarray,
        num_iterations: int = 100,
        learning_rate: float = 0.01
    ) -> Tuple[np.ndarray, float]:
        """
        Optimize symbols using TensorFlow gradient descent to minimize
        error over a known channel
        
        Args:
            initial_symbols: Starting modulated symbols
            channel_response: Known channel impulse response
            num_iterations: Optimization iterations
            learning_rate: Adam learning rate
            
        Returns:
            Optimized symbols, final loss
        """
        
        # Convert to TensorFlow variables
        symbols_var = tf.Variable(
            tf.cast(initial_symbols, tf.complex128),
            trainable=True,
            name='optimized_symbols'
        )
        
        channel_tf = tf.constant(channel_response, dtype=tf.complex128)
        
        optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
        
        losses = []
        
        for iteration in range(num_iterations):
            with tf.GradientTape() as tape:
                # Generate OFDM with current symbols
                symbols_normalized = tf.cast(symbols_var, tf.complex128)
                
                # Apply channel
                received = tf.signal.fft(symbols_normalized)
                received = received * tf.expand_dims(channel_tf, axis=0)
                received = tf.signal.ifft(received)
                
                # MSE loss
                loss = tf.reduce_mean(tf.abs(received - symbols_normalized) ** 2)
            
            # Gradient step
            grads = tape.gradient(loss, [symbols_var])
            optimizer.apply_gradients(zip(grads, [symbols_var]))
            
            losses.append(float(loss))
            
            if iteration % 20 == 0:
                logger.info(f'Iteration {iteration}: Loss = {float(loss):.6f}')
        
        logger.info(f'Waveform optimization complete: final loss = {losses[-1]:.6f}')
        
        return np.array(symbols_var), losses[-1]
    
    # ================================================================
    # PULSE SHAPING & WINDOWING
    # ================================================================
    
    def apply_pulse_shaping(
        self,
        waveform: np.ndarray,
        filter_type: str = 'rrc',  # root-raised-cosine
        rolloff: float = 0.35
    ) -> np.ndarray:
        """Apply pulse shaping filter to reduce out-of-band emissions"""
        
        num_taps = 101
        
        if filter_type == 'rrc':
            # Root-raised cosine filter
            t = np.arange(-num_taps//2, num_taps//2 + 1)
            h = signal.firwin(num_taps, 0.5, window='hamming')
            
            # RRC design
            t_norm = t / (num_taps // 2)
            h = np.sinc(t_norm)
            h *= np.cos(np.pi * rolloff * t_norm) / (1 - (2 * rolloff * t_norm) ** 2 + 1e-10)
            h /= np.sum(h)
        
        elif filter_type == 'blackman':
            h = signal.windows.blackman(num_taps)
            h /= np.sum(h)
        
        else:
            h = signal.windows.hamming(num_taps)
            h /= np.sum(h)
        
        # Apply filter
        shaped = signal.convolve(waveform, h, mode='same')
        
        return shaped
    
    # ================================================================
    # UPCONVERT TO RF
    # ================================================================
    
    def upconvert_to_rf(
        self,
        baseband_waveform: np.ndarray,
        carrier_freq: Optional[float] = None
    ) -> np.ndarray:
        """
        Upconvert baseband waveform to RF frequency
        
        Args:
            baseband_waveform: Complex baseband signal
            carrier_freq: RF frequency (uses self.carrier_freq if None)
            
        Returns:
            Real RF signal (I + j*Q modulated to carrier)
        """
        
        if carrier_freq is None:
            carrier_freq = self.carrier_freq
        
        t = np.arange(len(baseband_waveform)) / self.sample_rate
        
        # Complex exponential upconversion
        carrier = np.exp(2j * np.pi * carrier_freq * t)
        rf_signal = baseband_waveform * carrier
        
        logger.info(f'Upconverted to {carrier_freq/1e9:.2f} GHz')
        
        return rf_signal

# ================================================================
# MODULATION SYNTHESIS UTILITIES
# ================================================================

class ModulationSynthesizer:
    """Generate modulated symbols"""
    
    @staticmethod
    def generate_symbols(
        num_symbols: int,
        modulation: str,
        seed: int = None
    ) -> np.ndarray:
        """Generate modulated symbols"""
        
        if seed is not None:
            np.random.seed(seed)
        
        if modulation == 'BPSK':
            return np.exp(1j * np.pi * np.random.randint(0, 2, num_symbols))
        
        elif modulation == 'QPSK':
            bits = np.random.randint(0, 4, num_symbols)
            return np.exp(1j * np.pi * bits / 2)
        
        elif modulation == '16QAM':
            bits = np.random.randint(0, 16, num_symbols)
            real = 2 * (bits % 4) - 3
            imag = 2 * ((bits // 4) % 4) - 3
            return (real + 1j * imag) / np.sqrt(10)
        
        elif modulation == '64QAM':
            bits = np.random.randint(0, 64, num_symbols)
            real = 2 * (bits % 8) - 7
            imag = 2 * ((bits // 8) % 8) - 7
            return (real + 1j * imag) / np.sqrt(42)
        
        else:
            return np.exp(1j * 2 * np.pi * np.random.random(num_symbols))

# ================================================================
# MAIN API INTEGRATION
# ================================================================

async def amc_classify_from_iq(iq_data: np.ndarray) -> Dict:
    """Classify modulation from raw IQ data using AMC"""
    classifier = ModulationClassifier()
    return classifier.classify(iq_data)

async def generate_modulated_waveform(
    num_symbols: int,
    modulation: str,
    waveform_type: str = 'ofdm',
    sample_rate: float = 1e6
) -> Dict:
    """Generate modulated waveform (OFDM/OTFS)"""
    
    # Synthesize symbols
    symbols = ModulationSynthesizer.generate_symbols(num_symbols, modulation)
    
    # Generate waveform
    engine = DifferentiableWaveformEngine(sample_rate=sample_rate)
    
    if waveform_type == 'ofdm':
        waveform = engine.generate_ofdm(symbols, num_subcarriers=64, modulation=modulation)
    elif waveform_type == 'otfs':
        waveform = engine.generate_otfs(symbols, num_subcarriers=64, modulation=modulation)
    else:
        waveform = symbols
    
    # Apply pulse shaping
    waveform = engine.apply_pulse_shaping(waveform, filter_type='rrc')
    
    # Upconvert
    rf_waveform = engine.upconvert_to_rf(waveform)
    
    return {
        'success': True,
        'waveform_type': waveform_type,
        'modulation': modulation,
        'num_symbols': num_symbols,
        'num_samples': len(waveform),
        'baseband_iq': waveform.tolist()[:1000],  # First 1000 samples
        'rf_signal': rf_waveform.tolist()[:1000],
        'peak_power': float(np.max(np.abs(rf_waveform)) ** 2),
    }

if __name__ == '__main__':
    # Example: Classify signal
    test_iq = np.random.randn(1024, 2) + 1j * np.random.randn(1024, 2)
    classifier = ModulationClassifier()
    result = classifier.classify(test_iq)
    print(f"Classified as: {result['modulation']} ({result['confidence']:.2%})")
    
    # Example: Generate OFDM waveform
    engine = DifferentiableWaveformEngine()
    symbols = ModulationSynthesizer.generate_symbols(128, 'QPSK')
    ofdm_waveform = engine.generate_ofdm(symbols)
    print(f"Generated OFDM: {len(ofdm_waveform)} samples")
