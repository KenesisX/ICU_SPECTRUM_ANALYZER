# STRIKEBACK SDR ANALYSIS PLATFORM
## Full-Stack Architecture & Implementation Guide

---

## PROJECT OVERVIEW
Professional RF signal analysis platform integrating multiple SDR hardware backends, real-time visualization, signal demodulation, geolocation mapping, and capture logging.

### Supported Hardware
- **RTL-SDR V4** (primary) — 24 MHz – 1.7 GHz, ~3M samples/sec
- **ADALM Pluto** (FPGA) — 325 MHz – 3.8 GHz, ~61M samples/sec
- **HackRF One** — 1 MHz – 6 GHz, 20M samples/sec, TX capable
- **ESP32 + CC1101** — 300-928 MHz (band-selectable)
- **ESP32 + NRF24** — 2.4 GHz (WiFi/BLE overlap)
- **Smartphone + KVMP/RF dongle** — Mobile SDR via USB-C/3.5mm jack

---

## SYSTEM ARCHITECTURE

### Tier 1: HARDWARE ABSTRACTION LAYER (HAL)
```
[Device Drivers] → [HAL Interface] → [Unified API]
   ├─ rtlsdr_driver.py
   ├─ pluto_driver.py
   ├─ hackrf_driver.py
   ├─ esp32_ble_driver.py
   ├─ esp32_cc1101_driver.py
   ├─ esp32_nrf24_driver.py
   └─ kvmp_mobile_driver.py
```

### Tier 2: SIGNAL PROCESSING ENGINE
```
[Raw IQ Data] → [FFT] → [Filter Bank] → [Demodulator Chain]
     ↓
[Feature Extraction] → [Modulation Classification] → [Geolocation]
```

### Tier 3: BACKEND API (Flask/FastAPI)
- WebSocket server for real-time streaming
- REST API for control commands
- Database (PostgreSQL) for captures, signals, locations
- Job queue (Celery) for async processing

### Tier 4: FRONTEND (Web UI + Mobile)
- Real-time visualization panels
- Interactive controls
- Geospatial mapping
- Capture library browser

---

## DETAILED COMPONENT BREAKDOWN

### HARDWARE DRIVERS

#### 1. RTL-SDR V4 Driver (`rtlsdr_driver.py`)
```python
import rtlsdr
import numpy as np

class RTLSDRDriver:
    def __init__(self, device_index=0):
        self.sdr = rtlsdr.RtlSdr(device_index)
        self.sdr.sample_rate = 2.4e6  # 2.4 MSps
        self.sdr.center_freq = 100e6  # 100 MHz start
        self.sdr.gain = 'auto'
    
    def set_frequency(self, freq_hz):
        """Set center frequency"""
        self.sdr.center_freq = freq_hz
    
    def set_sample_rate(self, rate_sps):
        """Set sample rate (24MHz-3.2MHz)"""
        self.sdr.sample_rate = rate_sps
    
    def read_samples(self, num_samples=262144):
        """Read IQ samples, return as numpy complex array"""
        return self.sdr.read_samples(num_samples)
    
    def get_bandwidth(self):
        return self.sdr.sample_rate
    
    def close(self):
        self.sdr.close()
```

#### 2. ADALM Pluto Driver (`pluto_driver.py`)
```python
import iio

class PlutoDriver:
    def __init__(self):
        self.ctx = iio.local_context()
        self.phy = self.ctx.find_device('ad9361-phy')
        self.dev = self.ctx.find_device('cf-ad9361-lpc')
        
        # RX channel setup
        self.rx = self.dev.find_channel('voltage0', False)
        self.rx_lo = self.phy.find_channel('altvoltage0', True)
        
        # Set defaults
        self.rx_lo.frequency = int(1e9)  # 1 GHz
        self.rx.attrs['rf_port_select'].value = 'A_BALANCED'
        self.rx.attrs['gain_control_mode'].value = 'fast_attack'
    
    def set_frequency(self, freq_hz):
        self.rx_lo.frequency = int(freq_hz)
    
    def set_sample_rate(self, rate_sps):
        self.rx.sample_rate = int(rate_sps)
    
    def read_samples(self, num_samples=16384):
        """Read from Pluto buffer"""
        samples = self.rx.read(num_samples * 4)  # 2 bytes I, 2 bytes Q
        iq = np.frombuffer(samples, dtype=np.int16).astype(np.float32)
        return iq[::2] + 1j * iq[1::2]
    
    def transmit_samples(self, samples):
        """TX capability"""
        self.dev.find_channel('voltage0', True).write(samples)
```

#### 3. HackRF One Driver (`hackrf_driver.py`)
```python
import hackrf

class HackRFDriver:
    def __init__(self):
        self.device = hackrf.HackRF()
        self.device.sample_rate = 20e6  # 20 MSps max
        self.device.center_freq = 100e6
        self.device.lna_gain = 40
        self.device.vga_gain = 40
        self.device.antenna_enable = False
    
    def set_frequency(self, freq_hz):
        self.device.center_freq = freq_hz
    
    def set_sample_rate(self, rate_sps):
        self.device.sample_rate = rate_sps
    
    def read_samples(self, num_samples=262144):
        return self.device.read(num_samples)
    
    def transmit_samples(self, samples):
        self.device.write(samples)
    
    def set_tx_vga(self, gain_db):
        """TX gain 0-47 dB"""
        self.device.txvga_gain = gain_db
```

#### 4. ESP32 + CC1101 Driver (`esp32_cc1101_driver.py`)
```python
import serial
import json

class ESP32CC1101Driver:
    def __init__(self, port='/dev/ttyUSB0', baud=921600):
        self.serial = serial.Serial(port, baud, timeout=2)
        self.freq_range = [300e6, 928e6]  # 300-928 MHz
        self.current_freq = 433e6
        self.bandwidth = 200e3
    
    def set_frequency(self, freq_hz):
        """Set CC1101 frequency"""
        if self.freq_range[0] <= freq_hz <= self.freq_range[1]:
            cmd = {'cmd': 'setFreq', 'freq': int(freq_hz)}
            self.serial.write(json.dumps(cmd).encode() + b'\n')
            self.current_freq = freq_hz
    
    def set_modulation(self, mod='FSK'):
        """FSK, GFSK, ASK, OOK"""
        cmd = {'cmd': 'setMod', 'mod': mod}
        self.serial.write(json.dumps(cmd).encode() + b'\n')
    
    def read_signal_strength(self):
        """RSSI reading"""
        cmd = {'cmd': 'getRSSI'}
        self.serial.write(json.dumps(cmd).encode() + b'\n')
        response = self.serial.readline().decode()
        return json.loads(response)
    
    def capture_iq(self, duration_ms=1000):
        """Capture raw IQ from CC1101 ADC"""
        cmd = {'cmd': 'captureIQ', 'duration': duration_ms}
        self.serial.write(json.dumps(cmd).encode() + b'\n')
        # Firmware streams IQ data back
        iq_data = b''
        while len(iq_data) < (duration_ms * 4000):  # ~4k samples/ms
            iq_data += self.serial.read(4096)
        return np.frombuffer(iq_data, dtype=np.complex64)
```

#### 5. ESP32 + NRF24 Driver (`esp32_nrf24_driver.py`)
```python
class ESP32NRF24Driver:
    def __init__(self, port='/dev/ttyUSB0', baud=921600):
        self.serial = serial.Serial(port, baud, timeout=2)
        self.center_freq = 2.4e9
        self.channels = list(range(0, 126))  # 0-125 (2.4 GHz channels)
        self.current_channel = 0
    
    def set_channel(self, channel):
        """Set NRF24 channel (2400 + channel MHz)"""
        if 0 <= channel <= 125:
            cmd = {'cmd': 'setChannel', 'ch': channel}
            self.serial.write(json.dumps(cmd).encode() + b'\n')
            self.current_channel = channel
    
    def scan_channels(self, dwell_ms=50):
        """Scan all 126 channels for signal activity"""
        cmd = {'cmd': 'scanChannels', 'dwell': dwell_ms}
        self.serial.write(json.dumps(cmd).encode() + b'\n')
        # Returns energy map across all channels
        response = self.serial.readline().decode()
        return json.loads(response)  # {'channels': [rssi_0, rssi_1, ...]}
    
    def sniff_packets(self, duration_sec=10):
        """Sniff BLE/WiFi packets on current channel"""
        cmd = {'cmd': 'sniff', 'duration': duration_sec}
        self.serial.write(json.dumps(cmd).encode() + b'\n')
        packets = []
        while True:
            try:
                line = self.serial.readline().decode().strip()
                if line:
                    packets.append(json.loads(line))
            except:
                break
        return packets
```

#### 6. KVMP Mobile Driver (`kvmp_mobile_driver.py`)
```python
class KVMPMobileDriver:
    """
    Smartphone RF dongle via WebSocket
    (Android app streams IQ data to backend)
    """
    def __init__(self, websocket_url='ws://localhost:8000/kvmp'):
        self.ws_url = websocket_url
        self.connected = False
        self.buffer = []
    
    def connect(self):
        """Connect to mobile client"""
        import asyncio
        import websockets
        asyncio.run(self._connect_async())
    
    async def _connect_async(self):
        async with websockets.connect(self.ws_url) as ws:
            self.connected = True
            while True:
                msg = await ws.recv()
                # msg = JSON with freq, rssi, iq_data
                self.buffer.append(json.loads(msg))
    
    def read_samples(self):
        if self.buffer:
            return self.buffer.pop(0)
        return None
```

---

## SIGNAL PROCESSING ENGINE

### FFT & Waterfall Generation
```python
import numpy as np
from scipy import signal

class SpectrumAnalyzer:
    def __init__(self, sample_rate=2.4e6, fft_size=2048):
        self.fs = sample_rate
        self.fft_size = fft_size
        self.window = signal.get_window('hann', fft_size)
    
    def compute_fft(self, iq_samples):
        """FFT with windowing and power calculation"""
        windowed = iq_samples[:self.fft_size] * self.window
        fft = np.fft.fft(windowed)
        power_db = 10 * np.log10(np.abs(fft) ** 2 + 1e-10)
        freqs = np.fft.fftfreq(self.fft_size, 1/self.fs)
        return freqs, np.fft.fftshift(power_db)
    
    def compute_waterfall(self, samples_list, num_rows=100):
        """Stack FFT results for waterfall display"""
        waterfall = np.zeros((num_rows, self.fft_size))
        for i, samples in enumerate(samples_list[-num_rows:]):
            _, power = self.compute_fft(samples)
            waterfall[i] = power
        return waterfall
    
    def detect_peaks(self, power_spectrum, threshold_db=-80):
        """Find signal peaks above threshold"""
        peaks, _ = signal.find_peaks(power_spectrum, height=threshold_db)
        return peaks
```

### IQ Scatterplot Analysis
```python
class IQAnalyzer:
    def __init__(self):
        pass
    
    def compute_iq_scatter(self, samples, decimation=10):
        """Decimate samples for scatterplot"""
        return samples[::decimation]
    
    def estimate_modulation(self, samples):
        """
        Classify modulation type:
        - QPSK: Constellation with 4 points
        - QAM: 8/16/32/64/128/256-ary
        - PSK: N points on circle
        - FSK: Frequency deviation
        - AM: Amplitude modulation
        - CW: Single point
        """
        # Normalize and compute constellation statistics
        normalized = samples / (np.max(np.abs(samples)) + 1e-10)
        
        # K-means clustering to count points
        from sklearn.cluster import KMeans
        X = np.column_stack([normalized.real, normalized.imag])
        
        mod_classes = {}
        for k in [1, 2, 4, 8, 16, 32, 64]:
            kmeans = KMeans(n_clusters=k, n_init=10)
            labels = kmeans.fit_predict(X)
            silhouette = sklearn.metrics.silhouette_score(X, labels)
            mod_classes[k] = silhouette
        
        best_k = max(mod_classes, key=mod_classes.get)
        mod_map = {
            1: 'CW', 2: 'BPSK', 4: 'QPSK', 8: 'PSK8',
            16: 'QAM16', 32: 'QAM32', 64: 'QAM64'
        }
        return mod_map.get(best_k, 'UNKNOWN')
```

### Demodulator Chain
```python
class DemodulatorChain:
    def __init__(self):
        pass
    
    def demod_fm(self, samples, sample_rate=2.4e6, audio_rate=48e3):
        """FM demodulation"""
        # Discriminator approach
        phase = np.unwrap(np.angle(samples))
        instantaneous_freq = np.diff(phase) * sample_rate / (2 * np.pi)
        audio = scipy.signal.resample(instantaneous_freq, int(len(instantaneous_freq) * audio_rate / sample_rate))
        return audio / np.max(np.abs(audio))
    
    def demod_am(self, samples):
        """AM demodulation"""
        envelope = np.abs(samples)
        # Low-pass filter to extract modulation
        b, a = scipy.signal.butter(5, 0.1)
        audio = scipy.signal.filtfilt(b, a, envelope)
        return audio / np.max(np.abs(audio))
    
    def demod_fsk(self, samples, sample_rate=2.4e6, mark_freq=1200, space_freq=2200):
        """FSK demodulation (e.g., RTTY)"""
        # Matched filter for mark and space
        t = np.arange(0, len(samples)) / sample_rate
        mark_filter = np.exp(2j * np.pi * mark_freq * t)
        space_filter = np.exp(2j * np.pi * space_freq * t)
        
        mark_corr = np.correlate(samples, mark_filter, mode='same')
        space_corr = np.correlate(samples, space_filter, mode='same')
        
        return (np.abs(mark_corr) > np.abs(space_corr)).astype(int)
    
    def demod_psk(self, samples, num_points=4):
        """PSK demodulation"""
        # Recover carrier phase
        phase = np.unwrap(np.angle(samples))
        # Estimate phase error
        from scipy.signal import lfilter
        phase_error = np.diff(phase)
        phase_corrected = np.cumsum(phase_error)
        corrected = samples * np.exp(-1j * phase_corrected[:len(samples)-1])
        # Symbol decision
        symbols = np.round(corrected * 2) / 2
        return symbols
```

### Geolocation & Mapping
```python
class GeolocEngine:
    def __init__(self):
        self.signal_samples = []
    
    def triangulate_tdoa(self, signal_arrivals):
        """
        Time Difference of Arrival (TDOA) triangulation
        Requires: Multiple receiver locations + arrival times
        """
        # signal_arrivals = [
        #   {'lat': 40.123, 'lon': -105.456, 'timestamp': 1234567890.1},
        #   {'lat': 40.124, 'lon': -105.457, 'timestamp': 1234567890.15},
        # ]
        from scipy.optimize import minimize
        
        def residual(pos):
            distances = []
            for arrival in signal_arrivals:
                d = np.sqrt((pos[0] - arrival['lat'])**2 + (pos[1] - arrival['lon'])**2)
                distances.append(d)
            return np.sum(np.diff(distances) ** 2)
        
        initial_guess = [40.1, -105.4]
        result = minimize(residual, initial_guess)
        return {'lat': result.x[0], 'lon': result.x[1], 'confidence': 1/result.fun}
    
    def triangulate_rss(self, signal_strengths):
        """
        Received Signal Strength (RSS) triangulation
        Requires: RSSI from multiple known tx locations
        """
        # signal_strengths = [
        #   {'lat': 40.1, 'lon': -105.4, 'rssi': -65},
        #   {'lat': 40.15, 'lon': -105.45, 'rssi': -80},
        # ]
        def path_loss_model(distance, rssi_ref=-50, distance_ref=1):
            """Free space path loss"""
            path_loss = rssi_ref - 20 * np.log10(distance / distance_ref)
            return path_loss
        
        def residual(pos):
            error = 0
            for signal in signal_strengths:
                expected_distance = distance_from_rssi(signal['rssi'])
                actual_distance = np.sqrt((pos[0] - signal['lat'])**2 + (pos[1] - signal['lon'])**2)
                error += (expected_distance - actual_distance) ** 2
            return error
        
        initial_guess = [40.1, -105.4]
        result = minimize(residual, initial_guess)
        return {'lat': result.x[0], 'lon': result.x[1]}
    
    def wardriving_scan(self, vehicle_position, scan_results):
        """
        Log signal detections with GPS position
        wardriving_scan({lat, lon, heading}, {signals: [...]})
        """
        scan_log = {
            'timestamp': time.time(),
            'vehicle': vehicle_position,
            'signals_detected': [],
        }
        for signal in scan_results:
            scan_log['signals_detected'].append({
                'freq': signal['frequency'],
                'rssi': signal['strength'],
                'modulation': signal['mod'],
                'location': vehicle_position,
                'bearing_to_source': calculate_bearing(signal)
            })
        return scan_log
```

### Specialized Decoders
```python
class SpecializedDecoders:
    def __init__(self):
        pass
    
    def decode_ads_b(self, bit_stream):
        """ADS-B aircraft tracking"""
        # ADS-B is 1090 MHz with Mode-S envelope
        # 112-bit messages: DF (5) + AA (24) + Data (56) + PI (24)
        if len(bit_stream) < 112:
            return None
        
        df = int(''.join(map(str, bit_stream[:5])), 2)
        if df != 11 and df != 17 and df != 18:
            return None  # Not ADS-B
        
        aircraft_addr = ''.join(map(str, bit_stream[8:32]))
        
        # Decode position data (for DF 17/18)
        if df in [17, 18]:
            tc = int(''.join(map(str, bit_stream[32:37])), 2)
            # ... complex position decoding ...
            return {
                'aircraft_id': aircraft_addr,
                'typecode': tc,
                'altitude': 0,  # Placeholder
                'latitude': 0,
                'longitude': 0,
                'speed': 0,
            }
    
    def decode_ais(self, bit_stream):
        """AIS ship tracking (VHF)"""
        if len(bit_stream) < 168:
            return None
        
        msg_type = int(''.join(map(str, bit_stream[0:6])), 2)
        mmsi = int(''.join(map(str, bit_stream[8:38])), 2)
        
        if msg_type == 1:  # Position Report Class A
            lon_raw = int(''.join(map(str, bit_stream[57:85])), 2)
            lat_raw = int(''.join(map(str, bit_stream[85:112])), 2)
            # Convert to actual lat/lon...
            return {
                'msg_type': msg_type,
                'mmsi': mmsi,
                'latitude': lat_raw / 600000.0,
                'longitude': lon_raw / 600000.0,
            }
    
    def decode_aprs(self, packet_data):
        """APRS amateur radio positioning"""
        # APRS format: "SSID>APRS,path: data"
        return {
            'callsign': packet_data.split('>')[0],
            'position': parse_aprs_position(packet_data),
            'altitude': parse_aprs_altitude(packet_data),
            'comment': parse_aprs_comment(packet_data),
        }
    
    def decode_satellite_telemetry(self, bit_stream):
        """ISS/satellite telemetry"""
        # CubeSat format: sync + ID + counter + data
        return {
            'satellite_id': bit_stream[0:8],
            'sequence': bit_stream[8:16],
            'temperature': int(''.join(map(str, bit_stream[16:24])), 2),
            'voltage': int(''.join(map(str, bit_stream[24:32])), 2),
        }
```

---

## BACKEND API (Flask/FastAPI)

### Core Endpoints
```
POST   /api/sdr/start              - Start capture session
POST   /api/sdr/stop               - Stop capture
GET    /api/sdr/status             - Get device status
POST   /api/sdr/setFreq            - Set center frequency
POST   /api/sdr/setRate            - Set sample rate
GET    /api/spectrum/live          - WebSocket: Live spectrum
GET    /api/iq/scatter             - WebSocket: IQ constellation
GET    /api/signals/detect         - Get detected signals
POST   /api/signals/decode         - Decode specific signal
GET    /api/map/signals            - Geospatial signal map
GET    /api/captures/list          - List saved captures
POST   /api/captures/save          - Save capture session
GET    /api/captures/:id/iq        - Download IQ data
POST   /api/demod/:type            - Demodulate (FM, AM, FSK, etc.)
GET    /api/tracking/adsb          - ADS-B aircraft list
GET    /api/tracking/ais           - AIS vessel list
GET    /api/tracking/satellite     - Satellite positions
POST   /api/warmdriving/start      - Start wardriving session
GET    /api/wardriving/results     - Get wardriving heatmap
```

### WebSocket Streams
```
/ws/spectrum              - Real-time power spectrum
/ws/waterfall             - Scrolling waterfall
/ws/iq_constellation      - Live IQ plot
/ws/time_domain           - Audio/baseband waveform
/ws/signal_detections     - Alert stream for new signals
/ws/geolocation           - Position updates
```

---

## DATABASE SCHEMA (PostgreSQL)

```sql
CREATE TABLE captures (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    created_at TIMESTAMP,
    center_freq BIGINT,
    sample_rate BIGINT,
    duration_seconds FLOAT,
    hardware_type VARCHAR(50),
    file_path TEXT,
    file_size BIGINT,
    modulation VARCHAR(50),
    notes TEXT
);

CREATE TABLE signals (
    id SERIAL PRIMARY KEY,
    capture_id INT REFERENCES captures(id),
    frequency BIGINT,
    bandwidth INT,
    power_dbm FLOAT,
    rssi FLOAT,
    snr_db FLOAT,
    modulation VARCHAR(50),
    timestamp TIMESTAMP,
    lat FLOAT,
    lon FLOAT,
    confidence FLOAT
);

CREATE TABLE decodings (
    id SERIAL PRIMARY KEY,
    signal_id INT REFERENCES signals(id),
    decoder_type VARCHAR(50),
    decoded_data JSONB,
    timestamp TIMESTAMP
);

CREATE TABLE wardriving_logs (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(255),
    timestamp TIMESTAMP,
    lat FLOAT,
    lon FLOAT,
    heading FLOAT,
    speed FLOAT,
    signals_detected JSONB
);

CREATE TABLE antenna_config (
    id SERIAL PRIMARY KEY,
    hardware_id VARCHAR(50),
    antenna_type VARCHAR(50),
    gain_db FLOAT,
    frequency_range_min BIGINT,
    frequency_range_max BIGINT,
    polarization VARCHAR(20),
    notes TEXT
);

CREATE TABLE adsb_aircraft (
    icao_addr VARCHAR(6) PRIMARY KEY,
    callsign VARCHAR(8),
    last_seen TIMESTAMP,
    lat FLOAT,
    lon FLOAT,
    altitude_ft INT,
    velocity_kts FLOAT,
    track_history JSONB[]
);

CREATE TABLE ais_vessels (
    mmsi INT PRIMARY KEY,
    vessel_name VARCHAR(120),
    last_seen TIMESTAMP,
    lat FLOAT,
    lon FLOAT,
    course FLOAT,
    speed_kts FLOAT,
    track_history JSONB[]
);
```

---

## DEPLOYMENT & INSTALLATION

### Requirements
```
Python 3.10+
PostgreSQL 14+
RTL-SDR library (librtlsdr-dev)
GNU Radio (for advanced processing)
FFTW3 (fast FFT)
libiio (Pluto support)
libhackrf (HackRF support)
```

### Docker Deployment
```dockerfile
FROM ubuntu:22.04
RUN apt-get update && apt-get install -y \
    python3-pip \
    librtlsdr-dev \
    libfftw3-dev \
    postgresql-client \
    libiio0 \
    libhackrf0

COPY requirements.txt /app/
RUN pip install -r /app/requirements.txt
COPY . /app
WORKDIR /app
CMD ["python3", "backend/main.py"]
```

### Hardware Calibration
- RTL-SDR: PPM offset calibration against known FM station
- Pluto: I/Q imbalance compensation
- HackRF: TX/RX switching delay compensation
- ESP32: Frequency offset trim

---

## OPERATIONAL WORKFLOW

### Example: Full Signal Capture & Analysis
```
1. Connect RTL-SDR V4
2. Tune to 433.92 MHz (ISM band)
3. Capture 30 seconds of data @ 2.4 MSps
4. Compute FFT waterfall
5. Detect peaks above -80 dBm
6. Decimate IQ data for constellation plot
7. Estimate modulation (GFSK, FSK, etc.)
8. Demodulate audio/data stream
9. Store in PostgreSQL
10. Visualize in web UI with geographic coordinates
11. Export to CSV/WAV for offline analysis
```

---

## NEXT STEPS
1. ✅ Implement HAL drivers (in progress)
2. ⚠️ Build Flask API backend
3. ⚠️ Create React web frontend
4. ⚠️ Integrate WebSocket for real-time
5. ⚠️ Build Cordova/Flutter app for mobile
6. ⚠️ Implement SDR signal libraries
7. ⚠️ Deploy with Docker/K8s
