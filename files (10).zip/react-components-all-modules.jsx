// ================================================================
// REACT COMPONENT ARCHITECTURE - STRIKEBACK 2.0
// All 23 modules with Redux state management
// ================================================================

// File: frontend/src/store/slices/modules.js

import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// ================================================================
// ASYNC THUNKS FOR API CALLS
// ================================================================

export const fetchEngagements = createAsyncThunk(
  'modules/fetchEngagements',
  async ({ status, page }, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/v1/engagements?status=${status}&page=${page}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchFindings = createAsyncThunk(
  'modules/fetchFindings',
  async ({ engagementId, severity }, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/v1/findings/engagement/${engagementId}?severity=${severity || ''}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchOSINT = createAsyncThunk(
  'modules/fetchOSINT',
  async ({ query, source }, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/v1/osint/${source}/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ query }),
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchNetworkTopology = createAsyncThunk(
  'modules/fetchNetworkTopology',
  async ({ engagementId }, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/v1/network/topology/${engagementId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchSDRSignals = createAsyncThunk(
  'modules/fetchSDRSignals',
  async ({ engagementId }, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/v1/sdr/signals/${engagementId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchTeams = createAsyncThunk(
  'modules/fetchTeams',
  async (_, { rejectWithValue }) => {
    try {
      const response = await fetch('/api/v1/teams', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchDashboard = createAsyncThunk(
  'modules/fetchDashboard',
  async (_, { rejectWithValue }) => {
    try {
      const response = await fetch('/api/v1/dashboard', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      });
      return response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// ================================================================
// REDUX SLICE
// ================================================================

const modulesSlice = createSlice({
  name: 'modules',
  initialState: {
    // Module 1: Dashboard Hub
    dashboard: { data: null, loading: false, error: null },

    // Module 2: Team Collaboration
    teams: { data: [], loading: false, error: null },
    messages: { data: [], loading: false, error: null },

    // Module 3: Compliance
    complianceRules: { data: [], loading: false },
    complianceChecks: { data: [], loading: false },

    // Module 5: OSINT
    osintResults: { data: [], loading: false, error: null },

    // Module 6: Network Topology
    networkTopology: { nodes: [], links: [], loading: false },
    networkNodes: { data: [], loading: false },

    // Module 9-12: SDR
    sdrDevices: { data: [], loading: false },
    sdrSignals: { data: [], loading: false },
    signalClassification: { data: null, loading: false },

    // Module 13-16: Pentesting
    findings: { data: [], loading: false, error: null },
    vulnerabilities: { data: [], loading: false },
    exploits: { data: [], loading: false },
    physicalSecurity: { locks: [], accessPoints: [], loading: false },

    // Module 17-19: Automation
    scripts: { data: [], loading: false },
    reportJobs: { data: [], loading: false },

    // Module 22-23: Dark Web & Search
    darkwebFindings: { data: [], loading: false },
    searchResults: { data: {}, loading: false },
  },

  extraReducers: (builder) => {
    // Dashboard
    builder
      .addCase(fetchDashboard.pending, (state) => {
        state.dashboard.loading = true;
      })
      .addCase(fetchDashboard.fulfilled, (state, action) => {
        state.dashboard.data = action.payload;
        state.dashboard.loading = false;
      })
      .addCase(fetchDashboard.rejected, (state, action) => {
        state.dashboard.error = action.payload;
        state.dashboard.loading = false;
      });

    // Teams
    builder
      .addCase(fetchTeams.pending, (state) => {
        state.teams.loading = true;
      })
      .addCase(fetchTeams.fulfilled, (state, action) => {
        state.teams.data = action.payload;
        state.teams.loading = false;
      })
      .addCase(fetchTeams.rejected, (state) => {
        state.teams.loading = false;
      });

    // Findings
    builder
      .addCase(fetchFindings.pending, (state) => {
        state.findings.loading = true;
      })
      .addCase(fetchFindings.fulfilled, (state, action) => {
        state.findings.data = action.payload;
        state.findings.loading = false;
      })
      .addCase(fetchFindings.rejected, (state, action) => {
        state.findings.error = action.payload;
        state.findings.loading = false;
      });

    // OSINT
    builder
      .addCase(fetchOSINT.pending, (state) => {
        state.osintResults.loading = true;
      })
      .addCase(fetchOSINT.fulfilled, (state, action) => {
        state.osintResults.data = action.payload;
        state.osintResults.loading = false;
      })
      .addCase(fetchOSINT.rejected, (state, action) => {
        state.osintResults.error = action.payload;
        state.osintResults.loading = false;
      });

    // Network Topology
    builder
      .addCase(fetchNetworkTopology.pending, (state) => {
        state.networkTopology.loading = true;
      })
      .addCase(fetchNetworkTopology.fulfilled, (state, action) => {
        state.networkTopology.nodes = action.payload.nodes;
        state.networkTopology.links = action.payload.links;
        state.networkTopology.loading = false;
      })
      .addCase(fetchNetworkTopology.rejected, (state) => {
        state.networkTopology.loading = false;
      });

    // SDR Signals
    builder
      .addCase(fetchSDRSignals.pending, (state) => {
        state.sdrSignals.loading = true;
      })
      .addCase(fetchSDRSignals.fulfilled, (state, action) => {
        state.sdrSignals.data = action.payload;
        state.sdrSignals.loading = false;
      })
      .addCase(fetchSDRSignals.rejected, (state) => {
        state.sdrSignals.loading = false;
      });
  },
});

export default modulesSlice.reducer;

// ================================================================
// REACT COMPONENTS - SAMPLE IMPLEMENTATIONS
// ================================================================

// File: frontend/src/components/Dashboard.jsx
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDashboard } from '../store/slices/modules';

const Dashboard = () => {
  const dispatch = useDispatch();
  const { data, loading } = useSelector((state) => state.modules.dashboard);

  useEffect(() => {
    dispatch(fetchDashboard());
  }, [dispatch]);

  if (loading) return <div>Loading dashboard...</div>;

  return (
    <div className="dashboard">
      <h1>STRIKEBACK 2.0 Dashboard</h1>
      {data && (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <h3>Active Engagements</h3>
              <p className="stat-value">{data.engagements.active}</p>
            </div>
            <div className="stat-card">
              <h3>Critical Findings</h3>
              <p className="stat-value critical">{data.findings.critical}</p>
            </div>
            <div className="stat-card">
              <h3>Team Members</h3>
              <p className="stat-value">{data.teams.total}</p>
            </div>
          </div>

          <div className="recent-activity">
            <h2>Recent Activity</h2>
            {data.recent_activity.map((item, idx) => (
              <div key={idx} className="activity-item">
                {item.action}: {item.resource_type}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

// File: frontend/src/components/Findings.jsx
const Findings = ({ engagementId }) => {
  const dispatch = useDispatch();
  const { data: findings, loading } = useSelector((state) => state.modules.findings);

  useEffect(() => {
    if (engagementId) {
      dispatch(fetchFindings({ engagementId }));
    }
  }, [engagementId, dispatch]);

  return (
    <div className="findings-module">
      <h2>Findings</h2>
      {loading ? (
        <div>Loading findings...</div>
      ) : (
        <div className="findings-list">
          {findings.map((finding) => (
            <div key={finding.id} className={`finding-item severity-${finding.severity}`}>
              <h3>{finding.title}</h3>
              <p>{finding.description}</p>
              <div className="finding-meta">
                <span className={`severity badge severity-${finding.severity}`}>{finding.severity}</span>
                <span className="status">{finding.status}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// File: frontend/src/components/OSINTHub.jsx
const OSINTHub = () => {
  const [query, setQuery] = React.useState('');
  const [source, setSource] = React.useState('shodan');
  const dispatch = useDispatch();
  const { data: results, loading } = useSelector((state) => state.modules.osintResults);

  const handleSearch = () => {
    dispatch(fetchOSINT({ query, source }));
  };

  return (
    <div className="osint-hub">
      <h2>OSINT Intelligence Hub</h2>
      <div className="search-panel">
        <input
          type="text"
          placeholder="Enter search query..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select value={source} onChange={(e) => setSource(e.target.value)}>
          <option value="shodan">Shodan</option>
          <option value="vt">VirusTotal</option>
          <option value="censys">Censys</option>
          <option value="otx">OTX</option>
        </select>
        <button onClick={handleSearch} disabled={loading}>
          {loading ? 'Searching...' : 'Search'}
        </button>
      </div>

      {results.length > 0 && (
        <div className="results">
          {results.map((result) => (
            <div key={result.id} className="result-item">
              {JSON.stringify(result, null, 2)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// File: frontend/src/components/NetworkTopology.jsx
import L from 'leaflet';

const NetworkTopology = ({ engagementId }) => {
  const dispatch = useDispatch();
  const { nodes, links, loading } = useSelector((state) => state.modules.networkTopology);

  useEffect(() => {
    if (engagementId) {
      dispatch(fetchNetworkTopology({ engagementId }));
    }
  }, [engagementId, dispatch]);

  return (
    <div className="network-topology">
      <h2>Network Topology</h2>
      {loading ? (
        <div>Loading network...</div>
      ) : (
        <div className="topology-container">
          {/* Use D3.js or Cytoscape for visualization */}
          <div className="nodes-list">
            {nodes.map((node) => (
              <div key={node.id} className="node-item">
                <strong>{node.ip_address}</strong> - {node.device_type}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export { Dashboard, Findings, OSINTHub, NetworkTopology };
