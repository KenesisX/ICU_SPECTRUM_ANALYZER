# ICU — Privacy Policy

Last updated: FILL_IN_DATE

## What this app does
ICU is a client for a server you run yourself (on your own Raspberry Pi or other host). You enter
that server's address, sign in with credentials you created on that server, and the app connects to
it over a WebSocket to show device status and send a small set of commands.

## What the app collects
The app itself collects nothing and sends nothing to any server operated by us or any third party.

- **Login credentials** you enter are sent only to the server address you provide, to authenticate
  you on your own server. They are not stored by the app beyond the active session and are not sent
  anywhere else.
- **Device status data** (online/offline, signal strength, uptime, temperature) is read from your
  own server and displayed in the app. It is not transmitted elsewhere.
- **No analytics, advertising, or crash-reporting SDKs are included.** The app makes no network
  requests other than to the server address you configure.

## Permissions used
- `INTERNET` — to connect to the server address you provide.
- `ACCESS_NETWORK_STATE` — to detect whether the device has connectivity before attempting to connect.

No location, camera, microphone, contacts, storage, or other sensitive permissions are requested.

## Data sharing
We do not operate a backend for this app and do not receive, store, or share any data from it.
All data stays between your device and the server you configure.

## Children
This app is not directed at children and is not designed to collect data from anyone.

## Changes
If this policy changes, the updated version will be posted at this same URL with a new date above.

## Contact
FILL_IN_CONTACT_EMAIL
