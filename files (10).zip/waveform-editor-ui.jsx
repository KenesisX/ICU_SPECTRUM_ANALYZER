/**
 * ================================================================
 * INTERACTIVE WAVEFORM EDITOR UI
 * Drag-and-drop signal editing, frequency analysis, peak manipulation
 * ================================================================
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Line, ComposedChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';

// ================================================================
// WAVEFORM EDITOR MAIN COMPONENT
// ================================================================

export const WaveformEditor = () => {
  // ================================================================
  // STATE MANAGEMENT
  // ================================================================
  
  const canvasRef = useRef(null);
  const [signal, setSignal] = useState([]);
  const [originalSignal, setOriginalSignal] = useState([]);
  const [peaks, setPeaks] = useState([]);
  const [troughs, setTroughs] = useState([]);
  const [draggedPoint, setDraggedPoint] = useState(null);
  
  // Analysis results
  const [frequencyDomain, setFrequencyDomain] = useState([]);
  const [envelope, setEnvelope] = useState([]);
  const [dominantFrequencies, setDominantFrequencies] = useState([]);
  
  // Control parameters
  const [frequencyShift, setFrequencyShift] = useState(0);
  const [wavelengthStretch, setWavelengthStretch] = useState(1.0);
  const [phaseShift, setPhaseShift] = useState(0);
  const [activeTab, setActiveTab] = useState('waveform');  // waveform, frequency, analysis
  const [zoom, setZoom] = useState(1.0);
  const [panning, setPanning] = useState(0);
  
  // Edit history
  const [editHistory, setEditHistory] = useState([]);
  const [editIndex, setEditIndex] = useState(-1);
  
  // ================================================================
  // GENERATE TEST SIGNAL
  // ================================================================
  
  const generateTestSignal = useCallback(() => {
    const sampleRate = 1e6;
    const duration = 0.001;  // 1 ms
    const numSamples = Math.floor(sampleRate * duration);
    
    const t = Array.from({length: numSamples}, (_, i) => i / sampleRate);
    const newSignal = t.map(ti =>
      0.5 * Math.sin(2 * Math.PI * 100e3 * ti) +  // 100 kHz
      0.3 * Math.sin(2 * Math.PI * 250e3 * ti) +  // 250 kHz
      0.05 * (Math.random() - 0.5)  // Noise
    );
    
    setOriginalSignal([...newSignal]);
    setSignal([...newSignal]);
    detectPeaksAndTroughs(newSignal);
    analyzeFrequencyDomain(newSignal);
    extractEnvelope(newSignal);
    
    // Clear edit history
    setEditHistory([]);
    setEditIndex(-1);
  }, []);
  
  // ================================================================
  // SIGNAL ANALYSIS FUNCTIONS (SIMULATED)
  // These would call Python backend in production
  // ================================================================
  
  const detectPeaksAndTroughs = (sig) => {
    const threshold = 0.3;
    const newPeaks = [];
    const newTroughs = [];
    
    for (let i = 1; i < sig.length - 1; i++) {
      if (sig[i] > sig[i-1] && sig[i] > sig[i+1] && sig[i] > threshold) {
        newPeaks.push({index: i, value: sig[i], time: i / 1000});
      }
      if (sig[i] < sig[i-1] && sig[i] < sig[i+1] && sig[i] < -threshold) {
        newTroughs.push({index: i, value: sig[i], time: i / 1000});
      }
    }
    
    setPeaks(newPeaks);
    setTroughs(newTroughs);
  };
  
  const analyzeFrequencyDomain = (sig) => {
    // Simulated FFT result
    const freqs = Array.from({length: 100}, (_, i) => ({
      frequency: i * 10,
      magnitude: Math.exp(-i / 20) * (Math.random() * 0.2 + 0.8)
    }));
    
    setFrequencyDomain(freqs);
    
    // Find dominant frequencies
    const sorted = [...freqs].sort((a, b) => b.magnitude - a.magnitude);
    setDominantFrequencies(sorted.slice(0, 5));
  };
  
  const extractEnvelope = (sig) => {
    // Simulated envelope (smooth curve through peaks)
    const envSamples = sig.length;
    const env = Array.from({length: envSamples}, (_, i) =>
      Math.exp(-i / (envSamples * 0.1)) * 0.8
    );
    setEnvelope(env);
  };
  
  // ================================================================
  // WAVEFORM EDITING FUNCTIONS
  // ================================================================
  
  const handlePeakDrag = (peakIndex, newValue) => {
    const newSignal = [...signal];
    const peak = peaks[peakIndex];
    
    // Clamp value
    const clamped = Math.max(-1, Math.min(1, newValue));
    
    // Update with smoothing
    const smoothRange = 5;
    newSignal[peak.index] = clamped;
    
    for (let i = 1; i <= smoothRange; i++) {
      if (peak.index - i >= 0) {
        const blend = (smoothRange - i) / smoothRange;
        newSignal[peak.index - i] = blend * clamped + (1 - blend) * signal[peak.index - i];
      }
      if (peak.index + i < newSignal.length) {
        const blend = (smoothRange - i) / smoothRange;
        newSignal[peak.index + i] = blend * clamped + (1 - blend) * signal[peak.index + i];
      }
    }
    
    setSignal(newSignal);
    detectPeaksAndTroughs(newSignal);
    
    // Record edit
    addEdit({
      type: 'peak',
      index: peakIndex,
      new_value: clamped,
    });
  };
  
  const handleFrequencyShift = (shiftAmount) => {
    setFrequencyShift(shiftAmount);
    
    // Simulated frequency shift
    const newSignal = signal.map((val, i) => {
      const phase = (2 * Math.PI * shiftAmount * i) / 1000;
      return val * Math.cos(phase);
    });
    
    setSignal(newSignal);
    detectPeaksAndTroughs(newSignal);
    analyzeFrequencyDomain(newSignal);
    
    addEdit({
      type: 'frequency_shift',
      amount: shiftAmount,
    });
  };
  
  const handleWavelengthStretch = (stretchFactor) => {
    setWavelengthStretch(stretchFactor);
    
    // Interpolation-based stretching
    const newSignal = [];
    for (let i = 0; i < signal.length; i++) {
      const origIdx = i / stretchFactor;
      const lo = Math.floor(origIdx);
      const hi = Math.ceil(origIdx);
      const frac = origIdx - lo;
      
      if (hi < signal.length) {
        newSignal[i] = signal[lo] * (1 - frac) + signal[hi] * frac;
      } else {
        newSignal[i] = signal[Math.min(lo, signal.length - 1)];
      }
    }
    
    setSignal(newSignal);
    detectPeaksAndTroughs(newSignal);
    analyzeFrequencyDomain(newSignal);
    
    addEdit({
      type: 'wavelength',
      factor: stretchFactor,
    });
  };
  
  const handlePhaseShift = (shiftAmount) => {
    setPhaseShift(shiftAmount);
    
    const newSignal = signal.map((val, i) => {
      const rotatedPhase = shiftAmount * (i / signal.length);
      return val * Math.cos(rotatedPhase);
    });
    
    setSignal(newSignal);
    detectPeaksAndTroughs(newSignal);
    
    addEdit({
      type: 'phase_shift',
      radians: shiftAmount,
    });
  };
  
  // ================================================================
  // EDIT HISTORY
  // ================================================================
  
  const addEdit = (edit) => {
    const newHistory = editHistory.slice(0, editIndex + 1);
    newHistory.push(edit);
    setEditHistory(newHistory);
    setEditIndex(newHistory.length - 1);
  };
  
  const undo = () => {
    if (editIndex > 0) {
      setEditIndex(editIndex - 1);
      // Recompute signal from edits
      replayEdits(editHistory.slice(0, editIndex));
    }
  };
  
  const redo = () => {
    if (editIndex < editHistory.length - 1) {
      setEditIndex(editIndex + 1);
      replayEdits(editHistory.slice(0, editIndex + 2));
    }
  };
  
  const replayEdits = (edits) => {
    // Replay edits from original signal
    let current = [...originalSignal];
    // Would apply edits sequentially
    setSignal(current);
  };
  
  const reset = () => {
    setSignal([...originalSignal]);
    setEditHistory([]);
    setEditIndex(-1);
    setFrequencyShift(0);
    setWavelengthStretch(1.0);
    setPhaseShift(0);
    detectPeaksAndTroughs(originalSignal);
    analyzeFrequencyDomain(originalSignal);
  };
  
  // ================================================================
  // INITIALIZATION
  // ================================================================
  
  useEffect(() => {
    generateTestSignal();
  }, [generateTestSignal]);
  
  // ================================================================
  // RENDER FUNCTIONS
  // ================================================================
  
  const renderWaveformTab = () => (
    <div style={{width: '100%', height: 400}}>
      <h3>Waveform Editor</h3>
      
      {/* Canvas-based rendering for performance */}
      <canvas
        ref={canvasRef}
        width={800}
        height={300}
        style={{
          border: '1px solid #ccc',
          cursor: 'crosshair',
          marginBottom: '20px',
          background: '#f9f9f9',
        }}
        onMouseMove={(e) => {
          // Handle dragging peaks/troughs
        }}
      />
      
      {/* Signal Graph with Peaks/Troughs */}
      <div style={{marginTop: 20}}>
        <ResponsiveContainer width="100%" height={250}>
          <ComposedChart data={signal.map((val, i) => ({x: i, value: val}))}>
            <CartesianGrid />
            <XAxis dataKey="x" />
            <YAxis domain={[-1, 1]} />
            <Tooltip />
            
            {/* Waveform */}
            <Line
              type="monotone"
              dataKey="value"
              stroke="#2196F3"
              dot={false}
              isAnimationActive={false}
              strokeWidth={2}
            />
            
            {/* Envelope */}
            {envelope.length > 0 && (
              <Line
                data={envelope.map((val, i) => ({x: i, value: val}))}
                type="monotone"
                dataKey="value"
                stroke="#FFC107"
                dot={false}
                strokeWidth={1}
                strokeDasharray="5,5"
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      
      {/* Peak/Trough Visualization */}
      <div style={{marginTop: 20, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20}}>
        <div>
          <h4>Peaks ({peaks.length})</h4>
          <div style={{maxHeight: 150, overflowY: 'auto', fontSize: 12}}>
            {peaks.map((p, i) => (
              <div key={i} style={{padding: 8, background: '#e3f2fd', marginBottom: 4, borderRadius: 4}}>
                <div>Index: {p.index}</div>
                <div>Value: {p.value.toFixed(4)}</div>
                <input
                  type="range"
                  min="-1"
                  max="1"
                  step="0.01"
                  value={p.value}
                  onChange={(e) => handlePeakDrag(i, parseFloat(e.target.value))}
                  style={{width: '100%'}}
                />
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h4>Troughs ({troughs.length})</h4>
          <div style={{maxHeight: 150, overflowY: 'auto', fontSize: 12}}>
            {troughs.map((t, i) => (
              <div key={i} style={{padding: 8, background: '#fce4ec', marginBottom: 4, borderRadius: 4}}>
                <div>Index: {t.index}</div>
                <div>Value: {t.value.toFixed(4)}</div>
                <input
                  type="range"
                  min="-1"
                  max="1"
                  step="0.01"
                  value={t.value}
                  onChange={(e) => handlePeakDrag(i, parseFloat(e.target.value))}
                  style={{width: '100%'}}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderFrequencyTab = () => (
    <div style={{width: '100%', height: 400}}>
      <h3>Frequency Analysis & Editing</h3>
      
      {/* Frequency Domain Graph */}
      <div style={{marginBottom: 20}}>
        <h4>Frequency Spectrum</h4>
        <ResponsiveContainer width="100%" height={250}>
          <ComposedChart
            data={frequencyDomain}
            margin={{top: 20, right: 30, left: 0, bottom: 0}}
          >
            <CartesianGrid />
            <XAxis dataKey="frequency" label={{value: 'Frequency (kHz)', position: 'insideBottomRight', offset: -5}} />
            <YAxis label={{value: 'Magnitude (dB)', angle: -90, position: 'insideLeft'}} />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="magnitude"
              stroke="#4CAF50"
              dot={false}
              strokeWidth={2}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      
      {/* Frequency Controls */}
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20}}>
        <div>
          <label>Frequency Shift (kHz): {frequencyShift / 1000}</label>
          <input
            type="range"
            min="-500"
            max="500"
            step="10"
            value={frequencyShift / 1000}
            onChange={(e) => handleFrequencyShift(parseFloat(e.target.value) * 1000)}
            style={{width: '100%'}}
          />
        </div>
        
        <div>
          <label>Phase Shift (degrees): {(phaseShift * 180 / Math.PI).toFixed(1)}</label>
          <input
            type="range"
            min="-180"
            max="180"
            step="5"
            value={phaseShift * 180 / Math.PI}
            onChange={(e) => handlePhaseShift(parseFloat(e.target.value) * Math.PI / 180)}
            style={{width: '100%'}}
          />
        </div>
      </div>
      
      {/* Dominant Frequencies */}
      <div style={{marginTop: 20}}>
        <h4>Dominant Frequencies</h4>
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10}}>
          {dominantFrequencies.map((freq, i) => (
            <div key={i} style={{
              padding: 10,
              background: '#fff3e0',
              borderRadius: 4,
              textAlign: 'center',
              fontSize: 12,
            }}>
              <div style={{fontWeight: 'bold'}}>{freq.frequency} kHz</div>
              <div>Mag: {freq.magnitude.toFixed(2)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
  
  const renderAnalysisTab = () => (
    <div style={{width: '100%'}}>
      <h3>Signal Analysis</h3>
      
      {/* Wavelength Control */}
      <div style={{marginBottom: 20}}>
        <label>Wavelength Stretch Factor: {wavelengthStretch.toFixed(2)}x</label>
        <input
          type="range"
          min="0.5"
          max="2.0"
          step="0.05"
          value={wavelengthStretch}
          onChange={(e) => handleWavelengthStretch(parseFloat(e.target.value))}
          style={{width: '100%'}}
        />
        <small>Stretch &gt; 1 = lower frequency, Stretch &lt; 1 = higher frequency</small>
      </div>
      
      {/* Edit History */}
      <div>
        <h4>Edit History ({editIndex + 1}/{editHistory.length})</h4>
        <div style={{display: 'flex', gap: 10, marginBottom: 10}}>
          <button onClick={undo} disabled={editIndex <= 0}>↶ Undo</button>
          <button onClick={redo} disabled={editIndex >= editHistory.length - 1}>↷ Redo</button>
          <button onClick={reset}>Reset</button>
        </div>
        
        {editHistory.length > 0 && (
          <div style={{background: '#f5f5f5', padding: 10, borderRadius: 4, fontSize: 12}}>
            {editHistory.map((edit, i) => (
              <div
                key={i}
                style={{
                  padding: 5,
                  background: i <= editIndex ? '#e8f5e9' : '#f0f0f0',
                  marginBottom: 4,
                  borderRadius: 2,
                  cursor: 'pointer',
                  opacity: i <= editIndex ? 1 : 0.6,
                }}
                onClick={() => setEditIndex(i)}
              >
                {i + 1}. {edit.type} {edit.value ? `(${edit.value.toFixed(3)})` : ''}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
  
  // ================================================================
  // MAIN RENDER
  // ================================================================
  
  return (
    <div style={{padding: 20, maxWidth: 1000, margin: '0 auto', fontFamily: 'system-ui'}}>
      <h1>🌊 Interactive Waveform Editor</h1>
      <p>Capture signals → Break down into components → Drag peaks/troughs → Modify frequency/wavelength → Replay</p>
      
      {/* Tabs */}
      <div style={{display: 'flex', gap: 10, marginBottom: 20, borderBottom: '2px solid #ddd'}}>
        <button
          onClick={() => setActiveTab('waveform')}
          style={{
            padding: '10px 20px',
            border: 'none',
            background: activeTab === 'waveform' ? '#2196F3' : '#f0f0f0',
            color: activeTab === 'waveform' ? 'white' : 'black',
            cursor: 'pointer',
            fontSize: 14,
            fontWeight: activeTab === 'waveform' ? 'bold' : 'normal',
          }}
        >
          Waveform
        </button>
        <button
          onClick={() => setActiveTab('frequency')}
          style={{
            padding: '10px 20px',
            border: 'none',
            background: activeTab === 'frequency' ? '#2196F3' : '#f0f0f0',
            color: activeTab === 'frequency' ? 'white' : 'black',
            cursor: 'pointer',
            fontSize: 14,
            fontWeight: activeTab === 'frequency' ? 'bold' : 'normal',
          }}
        >
          Frequency
        </button>
        <button
          onClick={() => setActiveTab('analysis')}
          style={{
            padding: '10px 20px',
            border: 'none',
            background: activeTab === 'analysis' ? '#2196F3' : '#f0f0f0',
            color: activeTab === 'analysis' ? 'white' : 'black',
            cursor: 'pointer',
            fontSize: 14,
            fontWeight: activeTab === 'analysis' ? 'bold' : 'normal',
          }}
        >
          Analysis
        </button>
      </div>
      
      {/* Tab Content */}
      {activeTab === 'waveform' && renderWaveformTab()}
      {activeTab === 'frequency' && renderFrequencyTab()}
      {activeTab === 'analysis' && renderAnalysisTab()}
      
      {/* Signal Stats */}
      <div style={{marginTop: 40, padding: 20, background: '#f5f5f5', borderRadius: 4}}>
        <h4>Signal Statistics</h4>
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 15}}>
          <div>
            <div style={{fontSize: 12, color: '#666'}}>Peak</div>
            <div style={{fontSize: 18, fontWeight: 'bold'}}>
              {Math.max(...signal).toFixed(3)}
            </div>
          </div>
          <div>
            <div style={{fontSize: 12, color: '#666'}}>Trough</div>
            <div style={{fontSize: 18, fontWeight: 'bold'}}>
              {Math.min(...signal).toFixed(3)}
            </div>
          </div>
          <div>
            <div style={{fontSize: 12, color: '#666'}}>RMS</div>
            <div style={{fontSize: 18, fontWeight: 'bold'}}>
              {Math.sqrt(signal.reduce((sum, val) => sum + val * val, 0) / signal.length).toFixed(3)}
            </div>
          </div>
          <div>
            <div style={{fontSize: 12, color: '#666'}}>Samples</div>
            <div style={{fontSize: 18, fontWeight: 'bold'}}>
              {signal.length}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WaveformEditor;
