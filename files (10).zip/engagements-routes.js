// ================================================================
// ENGAGEMENT & OPERATION ROUTES
// Module 1: Dashboard Hub
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// ENGAGEMENTS - CRUD
// ================================================================

// GET /api/v1/engagements
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { status, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;

    let query = 'SELECT * FROM engagements WHERE 1=1';
    const params = [];

    if (status) {
      query += ' AND status = $1';
      params.push(status);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);

    const result = await db.query(query, params);

    // Get count
    let countQuery = 'SELECT COUNT(*) FROM engagements WHERE 1=1';
    if (status) countQuery += ' AND status = $1';
    const countResult = await db.query(countQuery, status ? [status] : []);

    res.json({
      engagements: result.rows,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      limit: parseInt(limit),
    });
  } catch (error) {
    logger.error('Get engagements error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/v1/engagements
router.post('/', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const {
      name, client, scope, start_date, end_date, authorization_doc_url,
    } = req.body;

    const result = await db.query(
      `INSERT INTO engagements 
        (name, client, scope, start_date, end_date, authorization_doc_url, team_lead_id, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [name, client, JSON.stringify(scope), start_date, end_date, authorization_doc_url, req.user.id, req.user.id],
    );

    logger.info('Engagement created', { engagementId: result.rows[0].id, createdBy: req.user.id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create engagement error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/v1/engagements/:id
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM engagements WHERE id = $1',
      [req.params.id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Engagement not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Get engagement error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// PUT /api/v1/engagements/:id
router.put('/:id', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const { name, client, scope, status, end_date } = req.body;

    const result = await db.query(
      `UPDATE engagements 
       SET name = COALESCE($1, name), 
           client = COALESCE($2, client),
           scope = COALESCE($3, scope),
           status = COALESCE($4, status),
           end_date = COALESCE($5, end_date),
           updated_at = NOW()
       WHERE id = $6
       RETURNING *`,
      [name, client, scope ? JSON.stringify(scope) : null, status, end_date, req.params.id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Engagement not found' });
    }

    logger.info('Engagement updated', { engagementId: req.params.id, updatedBy: req.user.id });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Update engagement error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DELETE /api/v1/engagements/:id
router.delete('/:id', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const result = await db.query(
      'DELETE FROM engagements WHERE id = $1 RETURNING id',
      [req.params.id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Engagement not found' });
    }

    logger.info('Engagement deleted', { engagementId: req.params.id, deletedBy: req.user.id });

    res.json({ message: 'Engagement deleted' });
  } catch (error) {
    logger.error('Delete engagement error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// OPERATIONS - CRUD
// ================================================================

// GET /api/v1/engagements/:engagement_id/operations
router.get('/:engagement_id/operations', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM operations 
       WHERE engagement_id = $1 
       ORDER BY start_time DESC`,
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get operations error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/v1/engagements/:engagement_id/operations
router.post('/:engagement_id/operations', authMiddleware, async (req, res) => {
  try {
    const { name, type, description, start_time } = req.body;

    const result = await db.query(
      `INSERT INTO operations (engagement_id, name, type, description, start_time, created_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [req.params.engagement_id, name, type, description, start_time, req.user.id],
    );

    logger.info('Operation created', { operationId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create operation error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// PUT /api/v1/engagements/:engagement_id/operations/:operation_id
router.put('/:engagement_id/operations/:operation_id', authMiddleware, async (req, res) => {
  try {
    const { status, end_time } = req.body;

    const result = await db.query(
      `UPDATE operations 
       SET status = COALESCE($1, status), 
           end_time = COALESCE($2, end_time),
           updated_at = NOW()
       WHERE id = $3 AND engagement_id = $4
       RETURNING *`,
      [status, end_time, req.params.operation_id, req.params.engagement_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Operation not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Update operation error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
