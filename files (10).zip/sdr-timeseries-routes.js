// ================================================================
// SDR CONTROL, AI SIGNAL CLASSIFICATION & TIME-SERIES ANALYTICS
// Modules 9-12: SDR Control, AI Classification, Advanced Decoding, Time-Series Analytics
// ================================================================

const express = require('express');
const db = require('../config/database');
const cache = require('../config/redis-config');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// SDR DEVICE CONTROL & MANAGEMENT
// ================================================================

router.post('/devices', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      device_type, // RTL-SDR, USRP, HackRF, etc
      model,
      serial_number,
      firmware_version,
      status,
    } = req.body;

    const result = await db.query(
      `INSERT INTO sdr_devices 
       (engagement_id, device_type, model, serial_number, firmware_version, status, registered_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [engagement_id, device_type, model, serial_number, firmware_version, status, req.user.id],
    );

    logger.info('SDR device registered', { deviceId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Register SDR device error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/devices/:device_id/firmware-flash', authMiddleware, async (req, res) => {
  try {
    const { firmware_url, firmware_version } = req.body;

    const result = await db.query(
      `UPDATE sdr_devices 
       SET firmware_version = $1, status = $2, updated_at = NOW()
       WHERE id = $3
       RETURNING *`,
      [firmware_version, 'flashing', req.params.device_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }

    // Log firmware flash
    await db.query(
      `INSERT INTO audit_log (user_id, action, resource_type, resource_id, details)
       VALUES ($1, $2, $3, $4, $5)`,
      [
        req.user.id,
        'firmware_flash',
        'sdr_device',
        req.params.device_id,
        JSON.stringify({ version: firmware_version, url: firmware_url }),
      ],
    );

    logger.info('Firmware flash initiated', { deviceId: req.params.device_id, version: firmware_version });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Firmware flash error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/devices/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM sdr_devices WHERE engagement_id = $1 ORDER BY created_at DESC',
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get SDR devices error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// SIGNAL CAPTURE & RECORDING
// ================================================================

router.post('/signals/capture', authMiddleware, async (req, res) => {
  try {
    const {
      device_id,
      frequency_start,
      frequency_end,
      sample_rate,
      gain,
      duration,
      modulation_type,
    } = req.body;

    const result = await db.query(
      `INSERT INTO signal_captures 
       (device_id, frequency_start, frequency_end, sample_rate, gain, duration, modulation_type, status, initiated_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        device_id,
        frequency_start,
        frequency_end,
        sample_rate,
        gain,
        duration,
        modulation_type,
        'recording',
        req.user.id,
      ],
    );

    logger.info('Signal capture started', { captureId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Start signal capture error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/signals/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const { limit = 100 } = req.query;

    const result = await db.query(
      `SELECT sc.*, sd.device_type, sd.model 
       FROM signal_captures sc
       LEFT JOIN sdr_devices sd ON sc.device_id = sd.id
       WHERE sd.engagement_id = $1
       ORDER BY sc.created_at DESC
       LIMIT $2`,
      [req.params.engagement_id, limit],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get signals error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// AI SIGNAL CLASSIFICATION (TensorFlow/PyTorch)
// ================================================================

router.post('/classification/predict', authMiddleware, async (req, res) => {
  try {
    const { signal_data, frequency, modulation_candidates } = req.body;

    // Call Python backend for ML inference
    const response = await fetch('http://strikeback-backend:8000/api/v1/signal/classify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        signal_data,
        frequency,
        modulation_candidates,
      }),
    });

    const classification = await response.json();

    // Store classification result
    const dbResult = await db.query(
      `INSERT INTO signal_classifications 
       (signal_data_hash, predicted_modulation, confidence, alternate_predictions)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [
        require('crypto').createHash('md5').update(signal_data).digest('hex'),
        classification.modulation,
        classification.confidence,
        JSON.stringify(classification.alternates),
      ],
    );

    res.json(dbResult.rows[0]);
  } catch (error) {
    logger.error('Signal classification error', { error: error.message });
    res.status(500).json({ error: 'Classification failed' });
  }
});

// ================================================================
// ADVANCED DECODING
// ================================================================

router.post('/decoding/decode', authMiddleware, async (req, res) => {
  try {
    const { signal_id, decoder_type, parameters } = req.body;

    // Supported decoders: FSK, AM, FM, BPSK, QPSK, QAM, etc
    const response = await fetch('http://strikeback-backend:8000/api/v1/signal/decode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        signal_id,
        decoder_type,
        parameters,
      }),
    });

    const decoded = await response.json();

    const result = await db.query(
      `INSERT INTO decoded_signals 
       (signal_id, decoder_type, decoded_data, decoded_text, success_rate)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        signal_id,
        decoder_type,
        JSON.stringify(decoded.data),
        decoded.text,
        decoded.success_rate,
      ],
    );

    logger.info('Signal decoded', { signalId: signal_id, decoderType: decoder_type });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Signal decoding error', { error: error.message });
    res.status(500).json({ error: 'Decoding failed' });
  }
});

// ================================================================
// TIME-SERIES ANALYTICS
// ================================================================

router.post('/timeseries/record', authMiddleware, async (req, res) => {
  try {
    const { signal_id, timestamp, frequency, power, phase } = req.body;

    const result = await db.query(
      `INSERT INTO signal_timeseries 
       (signal_id, timestamp, frequency, power, phase)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [signal_id, timestamp, frequency, power, phase],
    );

    // Cache in Redis for real-time dashboard
    const key = `timeseries:${signal_id}:latest`;
    await cache.set(key, JSON.stringify(result.rows[0]), 3600);

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Record timeseries error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/timeseries/:signal_id', authMiddleware, async (req, res) => {
  try {
    const { start_time, end_time, resolution = 'raw' } = req.query;

    let query = `
      SELECT timestamp, frequency, power, phase 
      FROM signal_timeseries 
      WHERE signal_id = $1
    `;
    const params = [req.params.signal_id];

    if (start_time && end_time) {
      query += ` AND timestamp BETWEEN $2 AND $3`;
      params.push(start_time, end_time);
    }

    // Aggregate if requested
    if (resolution === '1min') {
      query = `
        SELECT 
          time_bucket('1 minute', timestamp) as time,
          avg(power) as avg_power,
          max(power) as max_power,
          min(power) as min_power
        FROM signal_timeseries
        WHERE signal_id = $1
        ${start_time && end_time ? 'AND timestamp BETWEEN $2 AND $3' : ''}
        GROUP BY time
        ORDER BY time DESC
      `;
    }

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get timeseries error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// FREQUENCY ALMANAC & THREAT DATABASE
// ================================================================

router.get('/frequencies/almanac', authMiddleware, async (req, res) => {
  try {
    const { region, band, limit = 100 } = req.query;

    let query = 'SELECT * FROM frequency_almanac WHERE 1=1';
    const params = [];

    if (region) {
      query += ' AND region = $1';
      params.push(region);
    }

    if (band) {
      query += ` AND band = $${params.length + 1}`;
      params.push(band);
    }

    query += ` ORDER BY frequency ASC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get frequency almanac error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
