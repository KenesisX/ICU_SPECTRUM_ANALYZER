package com.icu.platform

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : Exception(message)

/** REST calls to the ICU API. Blocking: call from a background dispatcher. */
class ICUApi(
    private val baseUrl: String,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val jsonType = "application/json".toMediaType()

    fun login(username: String, password: String): String {
        val body = JSONObject().put("username", username).put("password", password)
            .toString().toRequestBody(jsonType)
        val req = Request.Builder().url("$baseUrl/api/v1/auth/login").post(body).build()
        return http.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, errorText(text, "login failed"))
            JSONObject(text).getString("token")
        }
    }

    fun post(token: String, path: String, payload: JSONObject): JSONObject {
        val req = Request.Builder().url(baseUrl + path)
            .header("Authorization", "Bearer $token")
            .post(payload.toString().toRequestBody(jsonType))
            .build()
        return http.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, errorText(text, "request failed"))
            JSONObject(text)
        }
    }

    private fun errorText(body: String, fallback: String): String =
        runCatching { JSONObject(body).optString("error", fallback) }.getOrDefault(fallback)
}

/** Live WebSocket to /ws/android. Callbacks run on OkHttp's thread. */
class LiveLink(
    private val http: OkHttpClient,
    private val url: String,
    private val onJson: (JSONObject) -> Unit,
    private val onState: (String) -> Unit
) {
    private var socket: WebSocket? = null

    fun open() {
        socket = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onState("Live")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching { onJson(JSONObject(text)) }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onState("Offline (${t.message ?: "error"})")
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onState("Offline")
            }
        })
    }

    fun send(obj: JSONObject): Boolean = socket?.send(obj.toString()) ?: false

    fun close() {
        socket?.close(1000, "bye")
        socket = null
    }
}
