// ================================================================
// DATABASE CONFIGURATION
// PostgreSQL connection pool
// ================================================================

const { Pool } = require('pg');
const logger = require('../utils/logger');

const pool = new Pool({
  user: process.env.DB_USER || 'strikeback',
  password: process.env.DB_PASSWORD || 'strikeback',
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'strikeback_2_0',
  max: process.env.DB_POOL_MAX || 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
  logger.error('Unexpected error on idle client', { error: err });
});

// Test connection on startup
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    logger.error('Database connection failed', { error: err });
  } else {
    logger.info('Database connection successful', { time: res.rows[0].now });
  }
});

// Helper for parameterized queries
const query = (text, params = []) => {
  const start = Date.now();
  return pool.query(text, params).then((res) => {
    const duration = Date.now() - start;
    if (duration > 1000) {
      logger.warn('Slow query detected', { text, duration, params });
    }
    return res;
  });
};

module.exports = {
  query,
  pool,
  getClient: () => pool.connect(),
};
