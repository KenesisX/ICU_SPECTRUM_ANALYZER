// ================================================================
// AUTHENTICATION & AUTHORIZATION MIDDLEWARE
// ================================================================

const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

// ================================================================
// JWT VERIFICATION MIDDLEWARE
// ================================================================
const authMiddleware = (req, res, next) => {
  try {
    const authHeader = req.get('Authorization');

    if (!authHeader) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Authorization header is missing',
      });
    }

    const token = authHeader.replace('Bearer ', '');

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = decoded;
      return next();
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({
          error: 'Token expired',
          message: 'Your session has expired. Please log in again.',
        });
      }
      return res.status(401).json({
        error: 'Invalid token',
        message: 'The provided token is invalid or malformed',
      });
    }
  } catch (error) {
    logger.error('Auth middleware error', { error: error.message });
    return res.status(500).json({
      error: 'Internal server error',
      message: 'An unexpected error occurred',
    });
  }
};

// ================================================================
// ROLE-BASED ACCESS CONTROL
// ================================================================
const requireRole = (...allowedRoles) => (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Authentication required',
    });
  }

  if (!allowedRoles.includes(req.user.role)) {
    logger.warn('Access denied - insufficient permissions', {
      userId: req.user.id,
      userRole: req.user.role,
      requiredRoles: allowedRoles,
      path: req.path,
    });

    return res.status(403).json({
      error: 'Forbidden',
      message: 'You do not have permission to access this resource',
    });
  }

  return next();
};

// ================================================================
// PERMISSION-BASED ACCESS
// ================================================================
const requirePermission = (permission) => (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Authentication required',
    });
  }

  // Admin always has all permissions
  if (req.user.role === 'admin') {
    return next();
  }

  // Check specific permission (would need to fetch from DB)
  // This is a simplified version - in production, fetch from users table
  const rolePermissions = {
    lead: ['engagement_management', 'team_oversight', 'report_generation'],
    operator: ['operation_execution', 'findings_entry', 'evidence_capture'],
    analyst: ['read_all', 'analysis', 'reporting'],
    guest: ['read_only'],
  };

  const userPermissions = rolePermissions[req.user.role] || [];

  if (!userPermissions.includes(permission)) {
    logger.warn('Permission denied', {
      userId: req.user.id,
      permission: permission,
      path: req.path,
    });

    return res.status(403).json({
      error: 'Forbidden',
      message: 'You do not have permission for this action',
    });
  }

  return next();
};

// ================================================================
// OPTIONAL AUTH (allows unauthenticated access but provides user if token exists)
// ================================================================
const optionalAuth = (req, res, next) => {
  try {
    const authHeader = req.get('Authorization');

    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
      } catch (err) {
        // Token is invalid, but we don't fail - just continue without user
        logger.debug('Optional auth token validation failed', { error: err.message });
      }
    }

    return next();
  } catch (error) {
    logger.error('Optional auth middleware error', { error: error.message });
    return next(); // Continue even on error
  }
};

module.exports = {
  authMiddleware,
  requireRole,
  requirePermission,
  optionalAuth,
};
