# 🌍 STRIKEBACK LIVE MAP INTEGRATION GUIDE

## Overview
The unified command center now includes a **real-time operational map** powered by **Leaflet + OpenStreetMap**. All operational data streams into a single GIS interface:

- 🚗 War-driving GPS trails (signal strength heatmap)
- ✈️ ADS-B aircraft tracking (1090 MHz)
- 🚢 AIS vessel positions (VHF maritime)
- 📡 RF signal detections (frequency, RSSI, location)

---

## Map Features

### Visualization Layers
1. **War-Driving GPS** — Circular markers color-coded by signal strength
   - Green: Strong (-50 dBm+)
   - Yellow: Medium (-80 dBm)
   - Red: Weak (-100 dBm)

2. **ADS-B Aircraft** — Blue plane icons with callsign, altitude, speed
   - Click to see full flight details
   - Real-time position updates

3. **AIS Vessels** — Ship icons with MMSI, course, speed
   - VHF maritime signals
   - Interactive popups

4. **RF Signals** — Square grid overlays showing detections
   - Color by frequency/modulation
   - Click for frequency, RSSI, coordinates

### Controls
- **Layer Toggles** — Show/hide any data type
- **Signal Threshold Slider** — Filter RF detections by dBm
- **Center Button** — Jump to ops center (Denver, CO 39.7392°N, -104.9903°W)
- **Export GeoJSON** — Download all map data as geospatial JSON

### Stats Panel
Real-time counters:
- GPS Points Logged
- Aircraft Tracked
- Vessels Detected
- RF Detections
- WebSocket Packets Received

---

## WebSocket Integration (Your Backend)

### Current Implementation
The app currently **simulates** WebSocket data using JavaScript intervals:

```javascript
// GPS trail simulation (every 2 seconds)
setInterval(() => {
  addGPSPoint(lat, lon, rssi);
}, 2000);

// ADS-B blips (every 5 seconds)
setInterval(() => {
  addAircraft(callsign, lat, lon, altitude, speed);
}, 5000);

// AIS vessels (every 6 seconds)
setInterval(() => {
  addVessel(mmsi, lat, lon, course, speed);
}, 6000);

// RF signals (every 1.5 seconds)
setInterval(() => {
  addRFSignal(freq, lat, lon, rssi);
}, 1500);
```

### To Replace with Real Backend

#### Option 1: Native WebSocket
```javascript
// Replace simulation with real WebSocket
const ws = new WebSocket('ws://localhost:5000/ws/map');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  
  if (data.type === 'gps') {
    addGPSPoint(data.lat, data.lon, data.rssi);
  }
  if (data.type === 'adsb') {
    addAircraft(data.callsign, data.lat, data.lon, data.altitude, data.speed);
  }
  if (data.type === 'ais') {
    addVessel(data.mmsi, data.lat, data.lon, data.course, data.speed);
  }
  if (data.type === 'rf_signal') {
    addRFSignal(data.freq, data.lat, data.lon, data.rssi);
  }
};
```

#### Option 2: Socket.IO
```javascript
const socket = io('http://localhost:5000');

socket.on('gps_point', (data) => {
  addGPSPoint(data.lat, data.lon, data.rssi);
});

socket.on('aircraft', (data) => {
  addAircraft(data.callsign, data.lat, data.lon, data.altitude, data.speed);
});

socket.on('vessel', (data) => {
  addVessel(data.mmsi, data.lat, data.lon, data.course, data.speed);
});

socket.on('rf_signal', (data) => {
  addRFSignal(data.freq, data.lat, data.lon, data.rssi);
});
```

---

## Data Format Specifications

### GPS Point (War-Driving)
```json
{
  "type": "gps",
  "lat": 39.7392,
  "lon": -104.9903,
  "rssi": -75.5,
  "frequency": 100.1,
  "modulation": "FM",
  "timestamp": "2026-09-23T14:32:10Z",
  "gps_accuracy": 5.2
}
```

### ADS-B Aircraft
```json
{
  "type": "adsb",
  "callsign": "N123AB",
  "lat": 39.8456,
  "lon": -104.8234,
  "altitude": 35000,
  "speed": 450,
  "course": 270,
  "timestamp": "2026-09-23T14:32:10Z"
}
```

### AIS Vessel
```json
{
  "type": "ais",
  "mmsi": "369704980",
  "vessel_name": "CARGO VESSEL 1",
  "lat": 39.6234,
  "lon": -104.7891,
  "course": 245,
  "speed": 12,
  "heading": 245,
  "timestamp": "2026-09-23T14:32:10Z"
}
```

### RF Signal Detection
```json
{
  "type": "rf_signal",
  "frequency": 433.92,
  "lat": 39.7500,
  "lon": -104.9800,
  "rssi": -85.3,
  "modulation": "GFSK",
  "bandwidth": 50000,
  "timestamp": "2026-09-23T14:32:10Z"
}
```

---

## Backend Requirements

### Flask/Python Backend Example

```python
from flask import Flask, jsonify
from flask_socketio import SocketIO, emit
from threading import Thread
import json
import time

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    
@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

# Stream GPS points
def gps_stream():
    while True:
        gps_data = {
            "type": "gps",
            "lat": 39.7392 + (random() - 0.5) * 0.05,
            "lon": -104.9903 + (random() - 0.5) * 0.05,
            "rssi": -80 + random() * 30,
            "timestamp": datetime.utcnow().isoformat()
        }
        socketio.emit('gps_point', gps_data, broadcast=True)
        time.sleep(2)

# Stream ADS-B data
def adsb_stream():
    while True:
        adsb_data = {
            "type": "adsb",
            "callsign": f"N{randint(10000, 99999)}",
            "lat": 39.7392 + (random() - 0.5) * 0.15,
            "lon": -104.9903 + (random() - 0.5) * 0.15,
            "altitude": 5000 + random() * 30000,
            "speed": 200 + random() * 400,
            "timestamp": datetime.utcnow().isoformat()
        }
        socketio.emit('aircraft', adsb_data, broadcast=True)
        time.sleep(5)

# Start background threads
Thread(target=gps_stream, daemon=True).start()
Thread(target=adsb_stream, daemon=True).start()

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
```

---

## Customization

### Change Center Location
In JavaScript, find:
```javascript
mapInstance = L.map(mapContainer).setView([39.7392, -104.9903], 11);
```
Replace with your coordinates:
```javascript
mapInstance = L.map(mapContainer).setView([YOUR_LAT, YOUR_LON], 11);
```

### Add Custom Basemap
Replace the OpenStreetMap tile layer:
```javascript
// Dark mode
L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(mapInstance);

// Satellite
L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}').addTo(mapInstance);

// Terrain
L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png').addTo(mapInstance);
```

### Modify Marker Styles
```javascript
// Change aircraft icon
html: `<div style="color: #3498db; font-size: 2em;">✈️</div>`

// Change vessel icon
html: `<div style="color: #2c3e50; font-size: 2em;">⛴️</div>`

// Change GPS trail color
const color = strength > 0.7 ? '#27ae60' : strength > 0.4 ? '#f39c12' : '#c0392b';
```

---

## Export Formats

### GeoJSON Export
Click **"EXPORT"** to download all map data as GeoJSON:
```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [-104.9903, 39.7392]
      },
      "properties": {
        "type": "gps",
        "rssi": -75.5,
        "frequency": 100.1
      }
    }
  ]
}
```

Compatible with:
- QGIS (open in QGIS for analysis)
- Google Earth Pro
- Leaflet/Folium
- ArcGIS
- Any standard GIS tool

---

## Performance Tips

1. **Limit markers** — For 1000+ points, use clustering:
   ```javascript
   L.markerClusterGroup().addLayer(wardrivingLayer).addTo(mapInstance);
   ```

2. **Throttle updates** — Reduce WebSocket emission frequency for high-traffic scenarios

3. **Use heatmap layer** — For dense RF signal data, switch to heatmap visualization

4. **Prune old data** — Keep only recent 500 GPS points; archive older data

---

## Troubleshooting

**Map not showing?**
- Check browser console for Leaflet errors
- Verify Leaflet CSS/JS loaded (CDN)
- Ensure map container has height: 600px

**WebSocket not connecting?**
- Check backend is running on correct port (5000)
- Verify CORS settings in Flask
- Check browser console for connection errors

**Markers not appearing?**
- Verify lat/lon values are within valid range (±90/-180)
- Check layer visibility toggles are checked
- Inspect browser DevTools → Network tab

---

## Next Steps

1. **Stand up backend** (Flask + Socket.IO recommended)
2. **Connect real data sources**:
   - GPS from war-driving device (serial/HTTP)
   - ADS-B from dump1090
   - AIS from AIS receiver
   - RF signals from SDR backend
3. **Replace simulation code** with WebSocket handlers
4. **Deploy** to production with HTTPS/WSS

---

**Questions?** Check the frontend code inline comments for detailed function docs.
