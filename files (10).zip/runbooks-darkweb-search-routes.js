// ================================================================
// RUNBOOKS, DARK WEB MONITORING & ADVANCED SEARCH
// Modules 8: Cheat Sheets/Runbooks, 22: Dark Web Monitoring, 23: Advanced Filtering & Search
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// RUNBOOKS & CHEAT SHEETS
// ================================================================

router.post('/runbooks', authMiddleware, async (req, res) => {
  try {
    const {
      title,
      category, // networking, wireless, pentest, sdr, etc
      description,
      steps,
      tools_required,
      common_issues,
      references,
    } = req.body;

    const result = await db.query(
      `INSERT INTO runbooks 
       (title, category, description, steps, tools_required, common_issues, references, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        title,
        category,
        description,
        JSON.stringify(steps),
        JSON.stringify(tools_required),
        JSON.stringify(common_issues),
        JSON.stringify(references),
        req.user.id,
      ],
    );

    logger.info('Runbook created', { runbookId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create runbook error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/runbooks', authMiddleware, async (req, res) => {
  try {
    const { category, search, limit = 100 } = req.query;

    let query = 'SELECT * FROM runbooks WHERE 1=1';
    const params = [];

    if (category) {
      query += ' AND category = $1';
      params.push(category);
    }

    if (search) {
      query += ` AND (title ILIKE $${params.length + 1} OR description ILIKE $${params.length + 1})`;
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ` ORDER BY category, title ASC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get runbooks error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/runbooks/:runbook_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM runbooks WHERE id = $1',
      [req.params.runbook_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Runbook not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Get runbook error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// DARK WEB MONITORING (Tor Integration)
// ================================================================

router.post('/darkweb/monitor', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      search_terms,
      monitoring_type, // marketplace, forum, paste, leak, etc
      frequency, // hourly, daily, weekly
    } = req.body;

    const result = await db.query(
      `INSERT INTO darkweb_monitors 
       (engagement_id, search_terms, monitoring_type, frequency, status, last_scan)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        engagement_id,
        JSON.stringify(search_terms),
        monitoring_type,
        frequency,
        'active',
        new Date(),
      ],
    );

    logger.info('Dark web monitor created', { monitorId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create dark web monitor error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/darkweb/results/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const { limit = 100 } = req.query;

    const result = await db.query(
      `SELECT * FROM darkweb_findings 
       WHERE engagement_id = $1 
       ORDER BY discovered_at DESC 
       LIMIT $2`,
      [req.params.engagement_id, limit],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get dark web findings error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/darkweb/findings/log', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      finding_type, // credential, data, mention, etc
      source_url,
      content,
      severity,
      action_taken,
    } = req.body;

    const result = await db.query(
      `INSERT INTO darkweb_findings 
       (engagement_id, finding_type, source_url, content, severity, action_taken, discovered_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        engagement_id,
        finding_type,
        source_url,
        content,
        severity,
        action_taken,
        req.user.id,
      ],
    );

    logger.info('Dark web finding logged', { findingId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Log dark web finding error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// ADVANCED FILTERING & SEARCH
// ================================================================

router.post('/search', authMiddleware, async (req, res) => {
  try {
    const {
      query,
      resource_types, // findings, intelligence, vulnerabilities, networks, etc
      filters, // dynamic filters object
      sort_by,
      page = 1,
      limit = 50,
    } = req.body;

    const offset = (page - 1) * limit;

    // Build dynamic query based on resource_types
    const results = {};

    // Search findings
    if (resource_types.includes('findings')) {
      let findingsQuery = `
        SELECT id, title, severity, status, created_at, 'finding' as resource_type 
        FROM findings 
        WHERE title ILIKE $1 OR description ILIKE $1
      `;
      const params = [`%${query}%`];

      if (filters.severity) {
        findingsQuery += ` AND severity = $${params.length + 1}`;
        params.push(filters.severity);
      }

      if (filters.engagement_id) {
        findingsQuery += ` AND engagement_id = $${params.length + 1}`;
        params.push(filters.engagement_id);
      }

      findingsQuery += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
      params.push(limit, offset);

      const findingsResult = await db.query(findingsQuery, params);
      results.findings = findingsResult.rows;
    }

    // Search intelligence reports
    if (resource_types.includes('intelligence')) {
      let intelQuery = `
        SELECT id, title, type, threat_level, created_at, 'intelligence' as resource_type 
        FROM intelligence_reports 
        WHERE title ILIKE $1 OR description ILIKE $1
      `;
      const params = [`%${query}%`];

      if (filters.threat_level) {
        intelQuery += ` AND threat_level = $${params.length + 1}`;
        params.push(filters.threat_level);
      }

      intelQuery += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
      params.push(limit, offset);

      const intelResult = await db.query(intelQuery, params);
      results.intelligence = intelResult.rows;
    }

    // Search vulnerabilities
    if (resource_types.includes('vulnerabilities')) {
      let vulnQuery = `
        SELECT id, cve_id as title, cvss_score, description, 'vulnerability' as resource_type 
        FROM vulnerabilities 
        WHERE cve_id ILIKE $1 OR description ILIKE $1
      `;
      const params = [`%${query}%`];

      if (filters.min_cvss) {
        vulnQuery += ` AND cvss_score >= $${params.length + 1}`;
        params.push(filters.min_cvss);
      }

      vulnQuery += ` ORDER BY cvss_score DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
      params.push(limit, offset);

      const vulnResult = await db.query(vulnQuery, params);
      results.vulnerabilities = vulnResult.rows;
    }

    // Search network nodes
    if (resource_types.includes('networks')) {
      let networkQuery = `
        SELECT id, ip_address as title, hostname, device_type, 'network' as resource_type 
        FROM network_nodes 
        WHERE ip_address ILIKE $1 OR hostname ILIKE $1
      `;
      const params = [`%${query}%`];

      if (filters.engagement_id) {
        networkQuery += ` AND engagement_id = $${params.length + 1}`;
        params.push(filters.engagement_id);
      }

      networkQuery += ` ORDER BY ip_address LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
      params.push(limit, offset);

      const networkResult = await db.query(networkQuery, params);
      results.networks = networkResult.rows;
    }

    res.json({
      query,
      total_results: Object.values(results).reduce((sum, r) => sum + (r ? r.length : 0), 0),
      results,
      page,
    });
  } catch (error) {
    logger.error('Search error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/saved-searches', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM saved_searches WHERE created_by = $1 ORDER BY created_at DESC`,
      [req.user.id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get saved searches error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/saved-searches', authMiddleware, async (req, res) => {
  try {
    const { name, query, resource_types, filters } = req.body;

    const result = await db.query(
      `INSERT INTO saved_searches 
       (name, query, resource_types, filters, created_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        name,
        query,
        JSON.stringify(resource_types),
        JSON.stringify(filters),
        req.user.id,
      ],
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Save search error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
