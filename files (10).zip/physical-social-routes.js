// ================================================================
// PHYSICAL SECURITY & SOCIAL ENGINEERING TOOLKIT
// Modules 14: Physical Security Module, 15: Social Engineering Toolkit
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// PHYSICAL SECURITY - LOCK DATABASE
// ================================================================

router.post('/locks/register', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      location,
      lock_type, // deadbolt, electronic, keypad, biometric, etc
      model,
      manufacturer,
      vulnerabilities,
      bypass_methods,
      estimated_time_to_bypass,
    } = req.body;

    const result = await db.query(
      `INSERT INTO lock_database 
       (engagement_id, location, lock_type, model, manufacturer, vulnerabilities, bypass_methods, estimated_time_to_bypass, added_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        engagement_id,
        location,
        lock_type,
        model,
        manufacturer,
        JSON.stringify(vulnerabilities),
        JSON.stringify(bypass_methods),
        estimated_time_to_bypass,
        req.user.id,
      ],
    );

    logger.info('Lock registered', { lockId: result.rows[0].id, lockType: lock_type });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Register lock error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/locks/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM lock_database WHERE engagement_id = $1 ORDER BY location, lock_type',
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get locks error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// PHYSICAL SECURITY - ACCESS POINTS & ENTRY METHODS
// ================================================================

router.post('/access-points', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      location,
      access_type, // door, window, roof, utility, etc
      security_level,
      guard_presence,
      cctv_coverage,
      alarm_system,
      entry_difficulty,
    } = req.body;

    const result = await db.query(
      `INSERT INTO access_points 
       (engagement_id, location, access_type, security_level, guard_presence, cctv_coverage, alarm_system, entry_difficulty)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        engagement_id,
        location,
        access_type,
        security_level,
        guard_presence,
        cctv_coverage,
        alarm_system,
        entry_difficulty,
      ],
    );

    logger.info('Access point recorded', { pointId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Add access point error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// SOCIAL ENGINEERING TOOLKIT
// ================================================================

router.post('/phishing/campaigns', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const {
      engagement_id,
      campaign_name,
      target_group,
      email_template,
      landing_page_url,
      sender_info,
      scheduling,
    } = req.body;

    const result = await db.query(
      `INSERT INTO phishing_campaigns 
       (engagement_id, campaign_name, target_group, email_template, landing_page_url, sender_info, scheduling, status, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        engagement_id,
        campaign_name,
        target_group,
        email_template,
        landing_page_url,
        JSON.stringify(sender_info),
        JSON.stringify(scheduling),
        'draft',
        req.user.id,
      ],
    );

    logger.info('Phishing campaign created', { campaignId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create phishing campaign error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/phishing/campaigns/:campaign_id/launch', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const result = await db.query(
      `UPDATE phishing_campaigns 
       SET status = $1, launched_at = NOW(), updated_at = NOW()
       WHERE id = $2
       RETURNING *`,
      ['launched', req.params.campaign_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    logger.info('Phishing campaign launched', { campaignId: req.params.campaign_id });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Launch campaign error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/phishing/campaigns/:campaign_id/results', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM phishing_clicks WHERE campaign_id = $1 ORDER BY clicked_at DESC`,
      [req.params.campaign_id],
    );

    // Calculate stats
    const stats = {
      total_targets: result.rows.length,
      clicked: result.rows.filter((r) => r.clicked_at).length,
      credentials_entered: result.rows.filter((r) => r.credentials_submitted).length,
      click_rate: result.rows.length > 0
        ? ((result.rows.filter((r) => r.clicked_at).length / result.rows.length) * 100).toFixed(2)
        : 0,
    };

    res.json({
      stats,
      clicks: result.rows,
    });
  } catch (error) {
    logger.error('Get campaign results error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// SOCIAL ENGINEERING PRETEXTS & SCRIPTS
// ================================================================

router.post('/pretexts', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      pretext_type, // phone, impersonation, badge, etc
      scenario,
      script,
      expected_responses,
      difficulty_level,
    } = req.body;

    const result = await db.query(
      `INSERT INTO se_pretexts 
       (engagement_id, pretext_type, scenario, script, expected_responses, difficulty_level, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        engagement_id,
        pretext_type,
        scenario,
        script,
        JSON.stringify(expected_responses),
        difficulty_level,
        req.user.id,
      ],
    );

    logger.info('SE pretext created', { pretextId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create pretext error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/pretexts/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM se_pretexts WHERE engagement_id = $1 ORDER BY difficulty_level, created_at DESC`,
      [req.params.engagement_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get pretexts error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// SOCIAL ENGINEERING TEST RESULTS
// ================================================================

router.post('/se-tests/results', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      test_type,
      target,
      success,
      technique,
      notes,
      evidence_url,
    } = req.body;

    const result = await db.query(
      `INSERT INTO se_test_results 
       (engagement_id, test_type, target, success, technique, notes, evidence_url, tested_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [engagement_id, test_type, target, success, technique, notes, evidence_url, req.user.id],
    );

    logger.info('SE test result recorded', { testId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Record SE test result error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/se-tests/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM se_test_results WHERE engagement_id = $1 ORDER BY created_at DESC`,
      [req.params.engagement_id],
    );

    const stats = {
      total_tests: result.rows.length,
      successful: result.rows.filter((r) => r.success).length,
      success_rate: result.rows.length > 0
        ? ((result.rows.filter((r) => r.success).length / result.rows.length) * 100).toFixed(2)
        : 0,
    };

    res.json({ stats, results: result.rows });
  } catch (error) {
    logger.error('Get SE tests error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
