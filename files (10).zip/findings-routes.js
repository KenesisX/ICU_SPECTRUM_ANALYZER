// ================================================================
// FINDINGS, VULNERABILITIES & EXPLOIT DATABASE
// Modules 13: Advanced Pentesting Tools, 16: Vulnerability & Exploit DB
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// CVSS severity levels
const SEVERITIES = ['critical', 'high', 'medium', 'low', 'info'];

// ================================================================
// FINDINGS MANAGEMENT
// ================================================================

router.post('/', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      title,
      description,
      severity,
      impact,
      remediation,
      evidence_urls,
      affected_systems,
    } = req.body;

    const result = await db.query(
      `INSERT INTO findings 
       (engagement_id, reported_by, title, description, severity, impact, remediation, evidence_urls, affected_systems, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [
        engagement_id,
        req.user.id,
        title,
        description,
        severity,
        impact,
        remediation,
        JSON.stringify(evidence_urls),
        JSON.stringify(affected_systems),
        'open',
      ],
    );

    logger.info('Finding created', { findingId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create finding error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/engagement/:engagement_id', authMiddleware, async (req, res) => {
  try {
    const { severity, status, limit = 100 } = req.query;

    let query = 'SELECT * FROM findings WHERE engagement_id = $1';
    const params = [req.params.engagement_id];

    if (severity) {
      query += ` AND severity = $${params.length + 1}`;
      params.push(severity);
    }

    if (status) {
      query += ` AND status = $${params.length + 1}`;
      params.push(status);
    }

    query += ` ORDER BY severity DESC, created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get findings error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:finding_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM findings WHERE id = $1',
      [req.params.finding_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Finding not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Get finding error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.put('/:finding_id', authMiddleware, async (req, res) => {
  try {
    const { title, description, severity, status, remediation, evidence_urls } = req.body;

    const result = await db.query(
      `UPDATE findings 
       SET title = COALESCE($1, title),
           description = COALESCE($2, description),
           severity = COALESCE($3, severity),
           status = COALESCE($4, status),
           remediation = COALESCE($5, remediation),
           evidence_urls = COALESCE($6, evidence_urls),
           updated_at = NOW()
       WHERE id = $7
       RETURNING *`,
      [
        title,
        description,
        severity,
        status,
        remediation,
        evidence_urls ? JSON.stringify(evidence_urls) : null,
        req.params.finding_id,
      ],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Finding not found' });
    }

    logger.info('Finding updated', { findingId: req.params.finding_id });

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Update finding error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// VULNERABILITY DATABASE
// ================================================================

router.post('/vulnerabilities/register', authMiddleware, async (req, res) => {
  try {
    const {
      cve_id,
      cvss_score,
      description,
      affected_versions,
      exploits,
      patch_url,
      disclosed_date,
    } = req.body;

    const result = await db.query(
      `INSERT INTO vulnerabilities 
       (cve_id, cvss_score, description, affected_versions, exploits, patch_url, disclosed_date, discovered_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        cve_id,
        cvss_score,
        description,
        JSON.stringify(affected_versions),
        JSON.stringify(exploits),
        patch_url,
        disclosed_date,
        req.user.id,
      ],
    );

    logger.info('Vulnerability registered', { cveId: cve_id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Register vulnerability error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/vulnerabilities', authMiddleware, async (req, res) => {
  try {
    const { search, min_cvss = 0, limit = 100 } = req.query;

    let query = 'SELECT * FROM vulnerabilities WHERE cvss_score >= $1';
    const params = [min_cvss];

    if (search) {
      query += ` AND (cve_id ILIKE $${params.length + 1} OR description ILIKE $${params.length + 1})`;
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ` ORDER BY cvss_score DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get vulnerabilities error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/vulnerabilities/:cve_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM vulnerabilities WHERE cve_id = $1',
      [req.params.cve_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'CVE not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Get CVE error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// EXPLOIT DATABASE
// ================================================================

router.post('/exploits/register', authMiddleware, requireRole('admin', 'lead'), async (req, res) => {
  try {
    const {
      name,
      type,
      cve_ids,
      description,
      code_url,
      proof_of_concept,
      difficulty,
      impact,
    } = req.body;

    const result = await db.query(
      `INSERT INTO exploits 
       (name, type, cve_ids, description, code_url, proof_of_concept, difficulty, impact, registered_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        name,
        type,
        JSON.stringify(cve_ids),
        description,
        code_url,
        proof_of_concept,
        difficulty,
        impact,
        req.user.id,
      ],
    );

    logger.info('Exploit registered', { exploitId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Register exploit error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/exploits', authMiddleware, async (req, res) => {
  try {
    const { type, difficulty, limit = 50 } = req.query;

    let query = 'SELECT * FROM exploits WHERE 1=1';
    const params = [];

    if (type) {
      query += ' AND type = $1';
      params.push(type);
    }

    if (difficulty) {
      query += ` AND difficulty = $${params.length + 1}`;
      params.push(difficulty);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get exploits error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// TEST RESULTS & EVIDENCE
// ================================================================

router.post('/:finding_id/evidence', authMiddleware, async (req, res) => {
  try {
    const { evidence_type, description, data_url } = req.body;

    const result = await db.query(
      `INSERT INTO evidence (finding_id, evidence_type, description, data_url, uploaded_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [req.params.finding_id, evidence_type, description, data_url, req.user.id],
    );

    logger.info('Evidence uploaded', { evidenceId: result.rows[0].id });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Upload evidence error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:finding_id/evidence', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM evidence WHERE finding_id = $1 ORDER BY created_at DESC',
      [req.params.finding_id],
    );

    res.json(result.rows);
  } catch (error) {
    logger.error('Get evidence error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
