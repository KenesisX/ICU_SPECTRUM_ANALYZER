#!/bin/bash -e
# Copies the Node API (api/ directory, placed in files/app/ before build) into the image.
install -d -m 755 "${ROOTFS_DIR}/opt/icu"
cp -r files/app/. "${ROOTFS_DIR}/opt/icu/"
on_chroot <<CHROOT
chown -R icu:icu /opt/icu
CHROOT
