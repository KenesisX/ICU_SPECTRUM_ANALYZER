// ================================================================
// CUSTOM SCRIPTING ENGINE, AUTOMATED REPORTS & HARDWARE INTEGRATION
// Modules 17-19: Scripting, Report Generation, Hardware Integration
// ================================================================

const express = require('express');
const db = require('../config/database');
const { authMiddleware, requireRole } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// ================================================================
// CUSTOM SCRIPTING ENGINE (Lua / Python)
// ================================================================

router.post('/scripts/create', authMiddleware, async (req, res) => {
  try {
    const {
      name,
      description,
      language, // lua or python
      code,
      trigger_type, // manual, scheduled, event
      parameters,
      permissions,
    } = req.body;

    const result = await db.query(
      `INSERT INTO custom_scripts 
       (name, description, language, code, trigger_type, parameters, permissions, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        name,
        description,
        language,
        code,
        trigger_type,
        JSON.stringify(parameters),
        JSON.stringify(permissions),
        req.user.id,
      ],
    );

    logger.info('Custom script created', { scriptId: result.rows[0].id, language });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Create script error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/scripts/:script_id/execute', authMiddleware, async (req, res) => {
  try {
    const { parameters, engagement_id } = req.body;

    // Get script
    const scriptResult = await db.query(
      'SELECT * FROM custom_scripts WHERE id = $1',
      [req.params.script_id],
    );

    if (scriptResult.rows.length === 0) {
      return res.status(404).json({ error: 'Script not found' });
    }

    const script = scriptResult.rows[0];

    // Send to Python backend for execution
    const response = await fetch('http://strikeback-backend:8000/api/v1/scripts/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        script_id: script.id,
        language: script.language,
        code: script.code,
        parameters: parameters || JSON.parse(script.parameters || '{}'),
        engagement_id,
      }),
    });

    const execution = await response.json();

    // Log execution
    const logResult = await db.query(
      `INSERT INTO script_executions 
       (script_id, status, output, error, execution_time, executed_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        script.id,
        execution.success ? 'success' : 'failed',
        JSON.stringify(execution.output),
        execution.error || null,
        execution.execution_time,
        req.user.id,
      ],
    );

    logger.info('Script executed', { scriptId: script.id, status: execution.success ? 'success' : 'failed' });

    res.json(logResult.rows[0]);
  } catch (error) {
    logger.error('Execute script error', { error: error.message });
    res.status(500).json({ error: 'Script execution failed' });
  }
});

router.get('/scripts', authMiddleware, async (req, res) => {
  try {
    const { language, limit = 50 } = req.query;

    let query = 'SELECT id, name, description, language, trigger_type, created_by, created_at FROM custom_scripts WHERE 1=1';
    const params = [];

    if (language) {
      query += ' AND language = $1';
      params.push(language);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    logger.error('Get scripts error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// AUTOMATED REPORT GENERATION (PDF/DOCX/Excel)
// ================================================================

router.post('/reports/generate', authMiddleware, async (req, res) => {
  try {
    const {
      engagement_id,
      report_type, // executive, technical, compliance, pentest
      format, // pdf, docx, xlsx
      include_sections,
      include_findings,
      include_evidence,
    } = req.body;

    const result = await db.query(
      `INSERT INTO report_jobs 
       (engagement_id, report_type, format, include_sections, include_findings, include_evidence, status, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        engagement_id,
        report_type,
        format,
        JSON.stringify(include_sections),
        include_findings,
        include_evidence,
        'queued',
        req.user.id,
      ],
    );

    const jobId = result.rows[0].id;

    // Send to report generation service
    fetch('http://strikeback-backend:8000/api/v1/reports/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        job_id: jobId,
        engagement_id,
        report_type,
        format,
        include_sections,
      }),
    }).catch((err) => logger.error('Report generation backend error', { error: err.message }));

    logger.info('Report generation queued', { jobId, format: format });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Queue report error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/reports/:job_id', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM report_jobs WHERE id = $1',
      [req.params.job_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Report job not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Get report error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/reports/:job_id/download', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM report_jobs WHERE id = $1',
      [req.params.job_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }

    const job = result.rows[0];

    if (job.status !== 'completed') {
      return res.status(400).json({ error: 'Report not ready for download' });
    }

    // Retrieve generated file from storage
    res.json({
      download_url: `/api/v1/reports/${job.id}/file`,
      format: job.format,
      generated_at: job.completed_at,
    });
  } catch (error) {
    logger.error('Download report error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ================================================================
// HARDWARE INTEGRATION (WebSerial, USB)
// ================================================================

router.post('/hardware/serial/connect', authMiddleware, async (req, res) => {
  try {
    const { port_name, baud_rate, device_type } = req.body;

    const result = await db.query(
      `INSERT INTO hardware_connections 
       (port_name, baud_rate, device_type, status, connected_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [port_name, baud_rate, device_type, 'connected', req.user.id],
    );

    logger.info('Hardware connected', { deviceType: device_type, port: port_name });

    res.status(201).json(result.rows[0]);
  } catch (error) {
    logger.error('Hardware connection error', { error: error.message });
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/hardware/:connection_id/send', authMiddleware, async (req, res) => {
  try {
    const { data, wait_for_response } = req.body;

    const connectionResult = await db.query(
      'SELECT * FROM hardware_connections WHERE id = $1',
      [req.params.connection_id],
    );

    if (connectionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Connection not found' });
    }

    const connection = connectionResult.rows[0];

    // Send via Python backend
    const response = await fetch('http://strikeback-backend:8000/api/v1/hardware/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connection_id: connection.id,
        port_name: connection.port_name,
        data,
        wait_for_response,
      }),
    });

    const result = await response.json();

    // Log hardware command
    await db.query(
      `INSERT INTO hardware_logs 
       (connection_id, command, response)
       VALUES ($1, $2, $3)`,
      [req.params.connection_id, data, result.response || null],
    );

    res.json(result);
  } catch (error) {
    logger.error('Hardware send error', { error: error.message });
    res.status(500).json({ error: 'Hardware communication failed' });
  }
});

router.get('/hardware/:connection_id/read', authMiddleware, async (req, res) => {
  try {
    const connectionResult = await db.query(
      'SELECT * FROM hardware_connections WHERE id = $1',
      [req.params.connection_id],
    );

    if (connectionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Connection not found' });
    }

    const connection = connectionResult.rows[0];

    // Read from Python backend
    const response = await fetch('http://strikeback-backend:8000/api/v1/hardware/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        port_name: connection.port_name,
        timeout: 5000,
      }),
    });

    const data = await response.json();

    res.json(data);
  } catch (error) {
    logger.error('Hardware read error', { error: error.message });
    res.status(500).json({ error: 'Hardware read failed' });
  }
});

module.exports = router;
