# STRIKEBACK SDR ANALYSIS PLATFORM
## Complete Deployment Guide

---

## TABLE OF CONTENTS
1. [System Requirements](#system-requirements)
2. [Quick Start (Docker)](#quick-start-docker)
3. [Manual Installation](#manual-installation)
4. [Hardware Configuration](#hardware-configuration)
5. [Database Setup](#database-setup)
6. [Web Interface Access](#web-interface-access)
7. [Troubleshooting](#troubleshooting)
8. [Advanced Configuration](#advanced-configuration)
9. [Operational Workflows](#operational-workflows)

---

## SYSTEM REQUIREMENTS

### Minimum Hardware
- **CPU:** Quad-core 2.0 GHz (Intel/AMD)
- **RAM:** 8 GB (16 GB recommended for heavy SDR processing)
- **Storage:** 50 GB SSD (for IQ captures & DB)
- **Network:** Gigabit Ethernet

### Operating System
- **Primary:** Ubuntu 22.04 LTS or later
- **Alternative:** Debian 12 (Bookworm)
- **Docker:** Docker 20.10+ & Docker Compose 2.0+

### SDR Hardware (at least one)
- RTL-SDR V4 (cheapest, ~$30)
- ADALM Pluto (best value, ~$150)
- HackRF One (TX capable, ~$300)
- ESP32 + CC1101 (budget option, ~$10)

---

## QUICK START (DOCKER)

### 1. Prerequisites
```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt-get install docker-compose-plugin

# Add user to docker group (avoid sudo)
sudo usermod -aG docker $USER
newgrp docker
```

### 2. Clone/Download Files
```bash
mkdir -p ~/strikeback_sdr
cd ~/strikeback_sdr

# Copy all project files:
# - docker-compose.yml
# - Dockerfile.backend
# - sdr_backend_main.py
# - sdr_frontend_app.html
# - requirements.txt
# - init_db.sql
```

### 3. Database Initialization
Create `init_db.sql`:
```sql
CREATE TABLE IF NOT EXISTS captures (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    center_freq BIGINT,
    sample_rate BIGINT,
    duration_seconds FLOAT,
    hardware_type VARCHAR(50),
    file_path TEXT,
    file_size BIGINT,
    modulation VARCHAR(50),
    notes TEXT
);

CREATE TABLE IF NOT EXISTS signals (
    id SERIAL PRIMARY KEY,
    capture_id INT REFERENCES captures(id) ON DELETE CASCADE,
    frequency BIGINT,
    bandwidth INT,
    power_dbm FLOAT,
    rssi FLOAT,
    snr_db FLOAT,
    modulation VARCHAR(50),
    timestamp TIMESTAMP DEFAULT NOW(),
    lat FLOAT,
    lon FLOAT,
    confidence FLOAT
);

CREATE TABLE IF NOT EXISTS decodings (
    id SERIAL PRIMARY KEY,
    signal_id INT REFERENCES signals(id) ON DELETE CASCADE,
    decoder_type VARCHAR(50),
    decoded_data JSONB,
    timestamp TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wardriving_logs (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(255),
    timestamp TIMESTAMP DEFAULT NOW(),
    lat FLOAT,
    lon FLOAT,
    heading FLOAT,
    speed FLOAT,
    signals_detected JSONB
);

CREATE TABLE IF NOT EXISTS adsb_aircraft (
    icao_addr VARCHAR(6) PRIMARY KEY,
    callsign VARCHAR(8),
    last_seen TIMESTAMP,
    lat FLOAT,
    lon FLOAT,
    altitude_ft INT,
    velocity_kts FLOAT,
    track_history JSONB
);

CREATE TABLE IF NOT EXISTS ais_vessels (
    mmsi INT PRIMARY KEY,
    vessel_name VARCHAR(120),
    last_seen TIMESTAMP,
    lat FLOAT,
    lon FLOAT,
    course FLOAT,
    speed_kts FLOAT,
    track_history JSONB
);
```

### 4. Start Services
```bash
docker-compose up -d

# Verify containers are running
docker-compose ps

# Check logs
docker-compose logs -f backend
```

### 5. Access Web Interface
```
http://localhost (via Nginx proxy)
or
http://localhost:5000 (direct backend)
or
http://localhost:80 (default HTTP)
```

---

## MANUAL INSTALLATION

### 1. System Setup
```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install dependencies
sudo apt-get install -y \
    python3.10 python3-pip python3-dev \
    postgresql postgresql-contrib \
    redis-server \
    librtlsdr-dev libfftw3-dev libiio-dev libhackrf-dev \
    build-essential cmake git pkg-config \
    libusb-1.0-0-dev
```

### 2. Install Python Dependencies
```bash
python3 -m venv ~/sdr_env
source ~/sdr_env/bin/activate
pip install -r requirements.txt
```

### 3. PostgreSQL Setup
```bash
# Start PostgreSQL
sudo systemctl start postgresql

# Create database and user
sudo -u postgres psql <<EOF
CREATE DATABASE strikeback_sdr;
CREATE USER sdr_user WITH PASSWORD 'secure_password_here';
ALTER ROLE sdr_user SET client_encoding TO 'utf8';
ALTER ROLE sdr_user SET default_transaction_isolation TO 'read committed';
ALTER ROLE sdr_user SET default_transaction_deferrable TO on;
ALTER ROLE sdr_user SET default_transaction_isolation TO 'read committed';
GRANT ALL PRIVILEGES ON DATABASE strikeback_sdr TO sdr_user;
EOF

# Initialize schema
psql -U sdr_user -d strikeback_sdr -f init_db.sql
```

### 4. Start Backend Server
```bash
# Set environment variables
export DB_HOST=localhost
export DB_NAME=strikeback_sdr
export DB_USER=sdr_user
export DB_PASS=secure_password_here

# Run backend
python3 sdr_backend_main.py
```

### 5. Serve Frontend
```bash
# Option A: Simple HTTP server
cd frontend
python3 -m http.server 8000

# Option B: Nginx
sudo cp sdr_frontend_app.html /usr/share/nginx/html/index.html
sudo systemctl start nginx
```

---

## HARDWARE CONFIGURATION

### RTL-SDR V4

#### 1. Install Drivers
```bash
sudo apt-get install -y rtl-sdr librtlsdr-dev librtlsdr0

# Blacklist DVB-T kernel module
echo "blacklist dvb_usb_rtl28xxu" | sudo tee /etc/modprobe.d/rtl-sdr.conf
sudo modprobe -r dvb_usb_rtl28xxu 2>/dev/null || true
```

#### 2. Hardware Permissions
```bash
# Add rules for non-sudo access
cat <<'EOF' | sudo tee /etc/udev/rules.d/22-rtl-sdr.rules
SUBSYSTEMS=="usb", ATTRS{idVendor}=="0bda", ATTRS{idProduct}=="2838", MODE:="0666"
EOF

sudo udevadm control --reload-rules
sudo udevadm trigger
```

#### 3. Test Connection
```bash
# Should detect RTL-SDR
rtl_test -t

# List devices
rtl_eeprom

# Test capture
rtl_sdr -f 100M -s 2400000 -n 1000000 test.raw
```

---

### ADALM Pluto

#### 1. Install libiio
```bash
git clone https://github.com/analogdevicesinc/libiio.git
cd libiio
mkdir build && cd build
cmake ..
make
sudo make install
```

#### 2. USB Configuration
```bash
# Connect Pluto via USB
# Identify device
lsusb | grep Analog

# Set IP (Pluto appears as virtual Ethernet interface)
ip addr show | grep 192.168.2

# SSH into Pluto (default password: analog)
ssh root@192.168.2.1
```

#### 3. Test Connection
```python
import iio

# Test in Python
ctx = iio.local_context()
dev = ctx.find_device('ad9361-phy')
print(dev)
```

---

### HackRF One

#### 1. Install Drivers
```bash
# Build from source (recommended)
git clone https://github.com/greatscottgadgets/hackrf.git
cd hackrf/host
mkdir build && cd build
cmake ..
make
sudo make install
sudo ldconfig

# Or install from package
sudo apt-get install -y libhackrf-dev libhackrf0
```

#### 2. Permissions
```bash
cat <<'EOF' | sudo tee /etc/udev/rules.d/20-hackrf.rules
SUBSYSTEMS=="usb", ATTRS{idVendor}=="1d50", ATTRS{idProduct}=="604b", MODE:="0666"
EOF

sudo udevadm control --reload-rules
sudo udevadm trigger
```

#### 3. Test
```bash
hackrf_info
hackrf_transfer -r test.raw -f 100000000 -s 20000000 -n 1000000
```

---

### ESP32 + CC1101

#### 1. Flash ESP32 Firmware
```bash
# Clone Arduino CC1101 library
git clone https://github.com/LSatan/SmartRC-CC1101-Driver-Lite.git

# Use Arduino IDE or PlatformIO to flash
# Example platformio.ini:
[env:esp32doit-devkit-v1]
platform = espressif32
board = esp32doit-devkit-v1
framework = arduino
lib_deps = 
    SmartRC-CC1101-Driver-Lite
```

#### 2. Serial Port Setup
```bash
# ESP32 appears as /dev/ttyUSB0
ls /dev/tty*

# Grant permissions
sudo usermod -aG dialout $USER

# Test serial connection
minicom -D /dev/ttyUSB0 -b 921600
```

#### 3. Configure CC1101
```python
import serial
import json

ser = serial.Serial('/dev/ttyUSB0', 921600)

# Set frequency to 433 MHz
cmd = {'cmd': 'setFreq', 'freq': 433000000}
ser.write(json.dumps(cmd).encode() + b'\n')
response = ser.readline().decode()
print(response)
```

---

### ESP32 + NRF24

#### 1. Wiring (SPI)
```
NRF24          ESP32
GND    ----    GND
VCC    ----    3.3V
CSN    ----    GPIO4 (CS)
SCK    ----    GPIO18 (CLK)
MOSI   ----    GPIO23 (MOSI)
MISO   ----    GPIO19 (MISO)
IRQ    ----    GPIO35 (INT)
```

#### 2. Install Library
```bash
# Arduino IDE: Sketch → Include Library → Manage Libraries
# Search: "RF24" by TMRh20
# Install version 1.4.8+
```

#### 3. Test Scanning
```python
ser = serial.Serial('/dev/ttyUSB0', 921600)

# Scan 2.4 GHz channels
cmd = {'cmd': 'scanChannels', 'dwell': 50}
ser.write(json.dumps(cmd).encode() + b'\n')
response = json.loads(ser.readline().decode())
print(response['channels'])  # Shows signal strength on each channel
```

---

### KVMP Mobile SDR

#### 1. Smartphone Requirements
- Android 10+ or iOS 14+
- USB-C or 3.5mm audio jack
- KVMP app installed

#### 2. Android Setup
```bash
# Install from Play Store or APK
# Launch KVMP app
# Set backend IP: 192.168.x.x:5000
# Click "Connect"
```

#### 3. Backend Webhook
```python
@app.route('/api/kvmp/register', methods=['POST'])
def register_mobile():
    """Mobile client registers for streaming"""
    client_id = request.json['client_id']
    client_ip = request.remote_addr
    
    # Start WebSocket listener for this device
    return jsonify({'status': 'registered', 'stream_url': f'ws://{client_ip}:5000/ws/kvmp'})
```

---

## WEB INTERFACE ACCESS

### URLs
```
Main UI:           http://localhost
Backend API:       http://localhost:5000/api/
API Docs:          http://localhost:5000/api/health
WebSocket Stream:  ws://localhost:5000/ws/spectrum
Grafana Dashboard: http://localhost:3000 (admin/admin)
```

### Key Web Endpoints

#### REST API
```
GET  /api/health                    - Server health check
GET  /api/sdr/devices               - List available devices
POST /api/sdr/start                 - Start capture
POST /api/sdr/stop                  - Stop capture
POST /api/sdr/setFreq               - Set frequency
GET  /api/spectrum/current          - Get current spectrum
GET  /api/iq/scatter                - Get IQ constellation
GET  /api/signals/detect            - Detect signals
POST /api/demod/<type>              - Demodulate (fm/am/lsb/fsk)
GET  /api/captures/list             - List saved captures
POST /api/captures/save             - Save capture
POST /api/tracking/adsb             - Get aircraft
POST /api/tracking/ais              - Get vessels
```

#### WebSocket Streams
```
ws://localhost:5000/ws/spectrum     - Real-time spectrum
ws://localhost:5000/ws/waterfall    - Waterfall display
ws://localhost:5000/ws/iq           - IQ constellation
ws://localhost:5000/ws/detections   - Signal alerts
```

---

## TROUBLESHOOTING

### "Device not found" / USB Permission Denied
```bash
# 1. Check device is visible
lsusb

# 2. Fix permissions (temporary)
sudo chmod 666 /dev/bus/usb/*/*

# 3. Fix permanently with udev rules (see Hardware Configuration)
```

### Database Connection Failed
```bash
# Check PostgreSQL
systemctl status postgresql

# Test connection
psql -h localhost -U sdr_user -d strikeback_sdr -c "SELECT 1"

# Check credentials
env | grep DB_
```

### WebSocket Connection Issues
```bash
# Check if backend is running
curl http://localhost:5000/api/health

# Monitor connections
netstat -an | grep 5000

# Check firewall
sudo ufw allow 5000
```

### High CPU Usage During Capture
```bash
# Reduce FFT size
# Reduce sample rate
# Disable waterfall display
# Use decimation on IQ data
```

### SDR Driver Conflicts
```bash
# Stop competing services
sudo systemctl stop gpsd
sudo systemctl stop rtl_433
sudo pkill -9 dump1090
sudo pkill -9 rtl_test
```

---

## ADVANCED CONFIGURATION

### Multi-Device Support
```python
# Run multiple backends on different ports
# Instance 1: RTL-SDR
PORT=5001 python3 sdr_backend_main.py

# Instance 2: Pluto
PORT=5002 python3 sdr_backend_main.py

# Instance 3: HackRF
PORT=5003 python3 sdr_backend_main.py

# Load balance with HAProxy
```

### Real-time Signal Logging
```bash
# Enable PostgreSQL WAL archiving for real-time replication
# Configure Elasticsearch for signal index
# Use Kibana for visualization
```

### GPU Acceleration
```bash
# CUDA support for FFT processing
# Install cuFFT library
sudo apt-get install libcufft-dev

# Update scipy to use cuFFT backend
pip install scipy[gpu]
```

### Persistent Waterfall Display
```bash
# Store waterfall frames in HDF5
# Browse historical waterfalls
# Replay captures with original spectrum
```

---

## OPERATIONAL WORKFLOWS

### Workflow 1: Basic Frequency Scanning
```
1. Connect RTL-SDR V4
2. Launch http://localhost
3. Set frequency to 100 MHz
4. Click "START"
5. Monitor spectrum panel
6. When signal detected:
   - Click signal in list
   - Select demodulation (FM/AM)
   - Click "DEMOD"
7. Click "SAVE" to log capture
```

### Workflow 2: ADS-B Aircraft Tracking
```
1. Tune to 1090 MHz
2. Select "ADS-B Decoder" from dropdown
3. Start capture
4. Aircraft list updates in real-time
5. Click aircraft to see track
6. Export CSV for analysis
```

### Workflow 3: Wardriving with GPS
```
1. Install GPS dongle on vehicle
2. Launch mobile app
3. Select wardriving mode
4. Drive route of interest
5. Platform logs signal locations
6. View heatmap when complete
7. Export for mapping software
```

### Workflow 4: Signal Capture & Offline Analysis
```
1. Capture 30 seconds IQ data at target frequency
2. Save to database (creates .iq file)
3. Download IQ file
4. Import into GNU Radio / GQRX for analysis
5. Or re-process in platform with different settings
```

---

## PERFORMANCE TUNING

### Optimize FFT Processing
- Increase FFT size for better frequency resolution
- Decrease FFT size for faster real-time updates
- Use sliding window FFT for continuous spectrum

### Database Optimization
```sql
-- Add indexes for common queries
CREATE INDEX idx_signals_freq ON signals(frequency);
CREATE INDEX idx_signals_time ON signals(timestamp);
CREATE INDEX idx_signals_capture ON signals(capture_id);
```

### Network Optimization
- Enable WebSocket compression
- Batch updates to reduce packet count
- Use delta encoding for spectrum data

---

## NEXT STEPS

1. ✅ Deploy platform using Docker
2. ⚠️ Connect RTL-SDR or Pluto hardware
3. ⚠️ Tune to target frequency
4. ⚠️ Configure demodulation chain
5. ⚠️ Integrate with external tools (GQRX, GNU Radio)
6. ⚠️ Setup geolocation with GPS
7. ⚠️ Deploy on remote server for autonomous monitoring

---

## SUPPORT & DOCUMENTATION

- **GitHub:** https://github.com/strikeback/sdr-platform
- **Wiki:** https://wiki.strikeback.tech/sdr
- **Issues:** Submit bug reports with `docker-compose logs`
- **Discord:** https://discord.gg/strikeback

---

*Last Updated: 2026-09-23*
*Version: 1.0.0 Alpha*
